/*
 * ShizuCallRecorder: FOSS Call recording powered through ADB/Shizuku!
 *  Copyright (C) 2026-present kitsumed (Med)
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package com.coolappstore.evercallrecorder.by.svhp.services.call

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import com.coolappstore.evercallrecorder.by.svhp.data.AppPreferences
import com.coolappstore.evercallrecorder.by.svhp.data.recordings.RecordingDirection
import com.coolappstore.evercallrecorder.by.svhp.data.recordings.RecordingMetadata
import com.coolappstore.evercallrecorder.by.svhp.services.recording.RecordingForegroundService
import com.coolappstore.evercallrecorder.by.svhp.system.permissions.PermissionChecks
import com.coolappstore.evercallrecorder.by.svhp.utils.AppLogger
import com.coolappstore.evercallrecorder.by.svhp.utils.PhoneNumberManager
import com.coolappstore.evercallrecorder.by.svhp.utils.PhoneNumberManager.Companion.normalisePhoneNumber
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * CallSessionManager role is to receive telephony state changes, determine call session information (like its direction and metadata),
 * and decide how to start the [RecordingForegroundService] based on user preferences and contact filtering.
 *
 * It is implemented as a singleton that should live until the app process itself die.
 */
class CallSessionManager private constructor(context: Context) {

    // Constants accessible globally
    companion object {
        private const val TAG = "SCR:CallSessionManager"

        // Singleton instance management
        @Volatile
        private var INSTANCE: CallSessionManager? = null

        /**
         * Provides a thread-safe singleton instance of [CallSessionManager].
         * The first call initializes the instance with the provided context, and subsequent calls return the same instance.
         */
        fun getInstance(context: Context): CallSessionManager {
            return INSTANCE ?: synchronized(this) {
                // We use applicationContext so we don't accidentally leak an Activity or Service context, causing memory leaks.
                val safeContext = context.applicationContext
                INSTANCE ?: CallSessionManager(safeContext).also { INSTANCE = it }
            }
        }

        // ── Debug broadcast action constants ────────────────────────────────────────────────
        const val ACTION_DEBUG_IDLE     = "com.coolappstore.evercallrecorder.by.svhp.action.DEBUG_IDLE"
        const val ACTION_DEBUG_RINGING  = "com.coolappstore.evercallrecorder.by.svhp.action.DEBUG_RINGING"
        const val ACTION_DEBUG_OFFHOOK  = "com.coolappstore.evercallrecorder.by.svhp.action.DEBUG_OFFHOOK"
    }

    /**
     * Encapsulates properties tied to a current call session.
     * We can verify if a session is active by checking [isSessionActive], which only happens after the first transition from [TelephonyManager.CALL_STATE_IDLE] (no ongoing call).
     */
    private inner class CallSessionState {
        /**
         * Tracks the metadata of the current continuous call session (including direction and phone number).
         * Also handle early initialization of the Shizuku server when enabled in user preferences.
         *
         * **This field is LOCKED on the very first non-IDLE (null) state transition**  Once set, it CANNOT be updated again until [clear] is called.
         * This prevents scenarios like receiving a new RINGING (incoming call) event while
         * already actively handling a call in OFFHOOK (outgoing) from accidentally overwriting the original
         * call direction and metadata.
         * 
         * The only exception is if the original phone number was null/blank and a new non-blank phone number is received for the same direction.
         */
        var currentMetadata: RecordingMetadata? = null
            set(value) {
                // Only allow updating settings when null, or to reset it back to null.
                if (field == null || value == null) {
                    // Save the direction temporarily to survive possible process death while waiting for the user to answer the call.
                    if (value != null) {
                        temporaryCache.save(value.direction)
                    }

                    field = value
                    return
                }

                val isSameCallDirection = field?.direction == value.direction
                // Verification Window: We had nothing, now we have a real number
                val isLateNumberDiscovery = field?.rawPhoneNumber.isNullOrBlank() && !value.rawPhoneNumber.isNullOrBlank()
                // Enrichment Bypass: It's the same number and call direction, just more data
                val isEnrichmentUpdate = field?.rawPhoneNumber == value.rawPhoneNumber && value.isEnriched
                // Multi-call update (2nd call added, or calls merged)
                val isMultiCallUpdate = value.isMultiCall || value.isMergedCall || !value.secondPhoneNumber.isNullOrBlank()

                if (isMultiCallUpdate) {
                    field = value
                } else if (isSameCallDirection && (isLateNumberDiscovery || isEnrichmentUpdate) && !wasRecordingServiceStartIntentSend) {
                    // We are in the same direction, but we previously had a blank/unknown number, and now we have a real number! This is part of the
                    // "Verification Window" flow, where we MAY first receive an anonymous/unknown number, then, WE MAY receive a real number within 500ms. In this case,
                    // it's the same call session, we want to allow updating the phone number. The only exception is if we already sent a start intent to
                    // the RecordingForegroundService, in that case we want to keep the original metadata for consistency between the two, even if it's anonymous.
                    field = value
                } else
                {
                    AppLogger.v(TAG, "Attempted to change ongoing session call metadata from ${field?.direction} to ${value.direction}. This is not allowed since the current session is already locked.")
                }
            }

        /**
         * Flag to track whether we've already sent an initial recording service intent (START or STANDBY)
         * for the current session. This helps prevent duplicate intents in edge dual-call cases.
         */
        var wasRecordingServiceStartIntentSend: Boolean = false

        /**
         * True once an ACTION_START_RECORDING intent has actually been sent for this session.
         * Unlike [wasRecordingServiceStartIntentSend], this stays false while we are holding a call
         * in standby (e.g. waiting for the call to be answered, see [answeredViaDialer]).
         */
        var isRecordingStarted: Boolean = false

        /**
         * True once the dialer app has reported that the call reached its "answered/connected" state
         * (outgoing: call timer started; incoming: accepted through this app's dialer). Used to gate
         * recording start when the "Record Only When Call Answered" preference is enabled.
         */
        var answeredViaDialer: Boolean = false

        /**
         * Indicates whether we are currently in an active call session (i.e., we've seen a non-IDLE state and haven't reset yet).
         * This also means that the [currentMetadata] field is locked until [clear] is called.
         */
        val isSessionActive: Boolean
            get() = currentMetadata != null

        /**
         * Resets all session state properties to their initial values.
         * This should be called when a call ends ([TelephonyManager.CALL_STATE_IDLE]) to ensure no stale data carries over to the next call session.
         */
        fun clear() {
            currentMetadata = null
            wasRecordingServiceStartIntentSend = false
            isRecordingStarted = false
            answeredViaDialer = false
            temporaryCache.clear()
        }
    }

    /**
     * Hold all the information for the current call session. Initialised only once, it can be managed and updated through its methods and properties.
     */
    private val session: CallSessionState = CallSessionState()
    private val appContext: Context = context.applicationContext
    private val preferences = AppPreferences(appContext)

    private val temporaryCache = CallSessionTemporaryCache(appContext)

    private val managerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /**
     * Holds a reference to a pending decision [Job] that is scheduled to run after the 500ms verification window when we receive a blank/anonymous number.
     */
    private var sessionJob: Job? = null


    init {
        AppLogger.d(TAG, "CallSessionManager initialised")
    }

    // Public API

    /**
     * Handles incoming telephony state changes to manage the recording session lifecycle.
     *
     * The process follows these steps:
     * 1. If the received state is IDLE, it means the call has ended. If a session was active, we stop recording and clear the session.
     * 2. If the received state is non-IDLE (RINGING or OFFHOOK), we determinate and lock the call direction (Incoming/Outgoing).
     * 3. When we receive an OFFHOOK state (phone is active) we check the phone number:
     *    - If we receive a state with a null/anonymous phone number, we delay processing by 500ms, this is the "Verification Window".
     *    - If another broadcast containing the real number arrive within 500ms, it takes priority, stops the "Verification Window" and processes immediately.
     *    - If the "Verification Window" expires without receiving a real number, we proceed with the recording using the anonymous number (null).
     *
     * **Call Waiting / Dual-Call Edge Case:**
     * If the user is already in a call and receives a second incoming call (whether accepted or ignored), we might receive
     * a RINGING followed by an OFFHOOK event (even if the user ignore the call! and the OFFHOOK event also contains the ignored phone number).
     * Because of this, we WILL ignore any follow-up OFFHOOK event to prevent editing the current call session metadata with wrong information until we receive a IDLE state.
     * This mean the recording (if started) will capture both calls in a single audio file under the metadata
     * of the initial call. I can't find any reliable way to fix this scenario with the permissions limitations android imposes on us.
     *
     * @param stateString The telephony state string (e.g., [TelephonyManager.EXTRA_STATE_RINGING]).
     * @param phoneNumber The phone number associated with the state change. Could be null, blank, or an OEM anonymous string.
     */
    @Synchronized
    fun handlePhoneState(stateString: String, phoneNumber: String?) {
        // Universal master switch: if the user hasn't turned call recording on, do nothing at
        // all — no session tracking, no metadata parsing, no service intents.
        if (!preferences.isCallRecordingEnabled()) return

        // When the user has opted into the InCallService detection method, that path (see
        // handleInCallServiceState) owns the session entirely — ignore phone-state broadcasts
        // so we never process the same call twice through two different pipelines.
        if (preferences.getCallDetectionMode() == AppPreferences.CallDetectionMode.IN_CALL_SERVICE) return

        val receivedCallState = when (stateString) {
            TelephonyManager.EXTRA_STATE_RINGING  -> TelephonyManager.CALL_STATE_RINGING
            TelephonyManager.EXTRA_STATE_OFFHOOK  -> TelephonyManager.CALL_STATE_OFFHOOK
            TelephonyManager.EXTRA_STATE_IDLE     -> TelephonyManager.CALL_STATE_IDLE
            else -> return
        }

        AppLogger.i(TAG, "Received new phone state: $stateString (TelephonyManagerINT:$receivedCallState) | Number: ${phoneNumber}")

        // 1. Handle IDLE (Stop, no longer in a call)
        if (receivedCallState == TelephonyManager.CALL_STATE_IDLE) {
            sessionJob?.cancel()
            if (session.isSessionActive) {
                AppLogger.d(TAG, "Phone state is now idle (call ended). Sending stop INTENT for ${session.currentMetadata?.direction} call to RecordingForegroundService.")
                sendServiceCommand(RecordingForegroundService.ACTION_STOP_RECORDING)
                session.clear()
            }
            return
        }

        // 2. Launch the Coroutine for RINGING or OFFHOOK
        // Canceling the previous job for the verification window logic
        sessionJob?.cancel()
        sessionJob = managerScope.launch {
            processSessionUpdate(receivedCallState, phoneNumber)
        }
    }

    /**
     * Processes the session update logic for RINGING and OFFHOOK states, including metadata parsing, session locking, and handling the verification window for anonymous numbers.
     */
    private suspend fun processSessionUpdate(state: Int, phoneNumber: String?) {
        // 1. Parse the metadata we received by the OS broadcast.
        val rawNumber: String? = PhoneNumberManager.sanitizeOemNumber(phoneNumber)
        val direction = RecordingDirection.fromCallStateOrNull(state)

        // 2. Previous metadata Restoration Logic (survive process death)
        // If the event is OFFHOOK, and we do not have any metadata in the session yet, it might be because the OS killed our process in the RINGING state,
        // this can happen when the user take too long to answer. It could also be the user making an outgoing call (directly goes to OFFHOOK).
        // NOTE: This is prone to very specific race conditions, but we don't have any solutions. In the future I would like to get rid of this whole file and use hidden api to fetch direction and phone numbers with Shizuku.
        if (state == TelephonyManager.CALL_STATE_OFFHOOK && !session.isSessionActive) {
            val restoredDirection = temporaryCache.restore()
            if (restoredDirection != null) {
                withContext(Dispatchers.Main) {
                    session.currentMetadata = RecordingMetadata(rawNumber, restoredDirection)
                }
            }
        }

        // 3. Try to save the parsed metadata (step 1) to the session if not already defined / locked.
        if (direction != null) {
            withContext(Dispatchers.Main) {
                // This is automatically locked after the first transition from IDLE. Only allow updating the phone number for the same direction.
                session.currentMetadata = RecordingMetadata(rawNumber, direction)
            }
        }

        // 4a. Handle RINGING — evaluate service start at ringing state
        if (state == TelephonyManager.CALL_STATE_RINGING) {
            val ringMetadata = session.currentMetadata
            if (ringMetadata != null) {
                AppLogger.d(TAG, "Evaluating service start at RINGING state.")
                withContext(Dispatchers.Main) { evaluateAndStartService(stillRingingUnanswered = true) }
            }
        }

        // 4. Handle OFFHOOK (now in a call) + The Verification Window (Non-blocking delay)
        if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
            // Handle anonymous and blank numbers (due to double broadcast behavior with one having no number)
            if (rawNumber.isNullOrBlank()) {
                AppLogger.d(TAG, "Number is blank or null. May be a anonymous call. Starting 500ms verification window.")
                delay(500)
            }

            val currentMetadata = session.currentMetadata ?: throw IllegalStateException("Current metadata should not be null at this point. There is a logic error in the flow.")
            val enrichedMetadata = RecordingMetadata.enrichMetadata(appContext, currentMetadata)

            withContext(Dispatchers.Main) {
                session.currentMetadata = enrichedMetadata
                evaluateAndStartService()
            }
        }
    }

    /**
     * Evaluates user preferences and contact filtering to decide whether to start recording immediately or go to standby mode,
     * then sends the appropriate command to the recording service.
     *
     * When the "Record Only When Call Answered" preference is enabled, a call that would otherwise auto-record is instead
     * held in standby until [notifyCallAnsweredInDialer] is called (outgoing: the dialer's call timer started;
     * incoming: the call was accepted through this app's dialer).
     */
    private fun evaluateAndStartService(stillRingingUnanswered: Boolean = false) {
        if (session.isRecordingStarted) {
            AppLogger.d(TAG, "Current call session is already recording. Skipping duplicate intent.")
            return
        }

        // If the user has never gone through the recorder's onboarding/disclaimer (e.g. a fresh
        // install where call recording hasn't been set up at all), or has every recording source
        // disabled, don't start the foreground service at all — not even in standby. Starting it
        // in that state has nothing to actually do and was the source of spurious "Error
        // recording" notifications appearing on calls the user never asked to be recorded.
        val recordingConfigured = preferences.isCallRecordingEnabled() && preferences.isDisclaimerAccepted()
        if (!recordingConfigured) {
            AppLogger.d(TAG, "Call recording has not been set up / is fully disabled. Not starting the recording service for this call.")
            return
        }

        val sessionMetadata = session.currentMetadata ?: throw IllegalStateException("Metadata should have been determined by now. There is a logic error.")

        val wantsAutoRecord = shouldAutoRecord(sessionMetadata)
        val waitingForDialerAnswer = wantsAutoRecord && preferences.isRecordOnAnswerEnabled() && !session.answeredViaDialer

        // The standby notification is purely informational (nothing is being recorded yet), so for
        // an incoming call that's still ringing/unanswered we start the service (to keep any
        // Shizuku pre-warming working) but suppress its visible notification. Otherwise the
        // "call recording" notification pops up on top of / racing with the incoming-call
        // answer/decline UI while the screen is on. Once the call is actually answered, a fresh
        // command (standby or start) is sent without this suppression and the notification shows normally.
        val suppressStandbyNotification = stillRingingUnanswered && sessionMetadata.direction == RecordingDirection.INCOMING

        if (waitingForDialerAnswer) {
            if (!session.wasRecordingServiceStartIntentSend) {
                AppLogger.i(TAG, "\"Record Only When Call Answered\" is enabled. Holding ${sessionMetadata.direction} call in standby until answered via the dialer.")
                sendServiceCommand(RecordingForegroundService.ACTION_STANDBY, sessionMetadata, suppressNotification = suppressStandbyNotification)
                session.wasRecordingServiceStartIntentSend = true
            }
            return
        }

        if (session.wasRecordingServiceStartIntentSend && !wantsAutoRecord) {
            // We already sent standby earlier, and preferences still say not to auto-record. Nothing further to do.
            return
        }

        if (wantsAutoRecord) {
            AppLogger.i(TAG, "Sending start INTENT for ${sessionMetadata.direction} call to RecordingForegroundService.")
            sendServiceCommand(RecordingForegroundService.ACTION_START_RECORDING, sessionMetadata, suppressNotification = suppressStandbyNotification)
            session.isRecordingStarted = true
        } else {
            AppLogger.i(TAG, "Sending standby INTENT for ${sessionMetadata.direction} call to RecordingForegroundService.")
            sendServiceCommand(RecordingForegroundService.ACTION_STANDBY, sessionMetadata, suppressNotification = suppressStandbyNotification)
        }
        session.wasRecordingServiceStartIntentSend = true
    }

    /**
     * Called by the dialer app when a call reaches its "answered/connected" state:
     * - Outgoing call: the call timer on the call screen has started.
     * - Incoming call: the call was accepted through this app's dialer.
     *
     * If a call session is active and is being held in standby because "Record Only When Call Answered"
     * is enabled, this re-evaluates and starts recording now.
     */
    @Synchronized
    fun notifyCallAnsweredInDialer() {
        if (!session.isSessionActive) {
            AppLogger.d(TAG, "notifyCallAnsweredInDialer() called but no active call session. Ignoring.")
            return
        }
        session.answeredViaDialer = true
        evaluateAndStartService()
    }

    /**
     * Updates ongoing recording session metadata when a second call is added (one held, one active)
     * or when calls are merged into a conference call.
     */
    @Synchronized
    fun updateMultiCall(secondNumber: String?, isMerged: Boolean) {
        val meta = session.currentMetadata
        if (meta != null) {
            val updated = meta.copy(
                secondPhoneNumber = secondNumber ?: meta.secondPhoneNumber,
                isMultiCall = true,
                isMergedCall = isMerged || meta.isMergedCall
            )
            session.currentMetadata = updated
            AppLogger.i(TAG, "updateMultiCall: secondNum=$secondNumber, isMerged=$isMerged")
        }
    }

    /**
     * Handles a call state event received from [AppInCallService] — the Telecom-API-based detection
     * path. Only takes effect when [AppPreferences.getCallDetectionMode] is
     * [AppPreferences.CallDetectionMode.IN_CALL_SERVICE].
     *
     * Unlike [handlePhoneState], the Telecom API already gives us the phone number and direction
     * immediately and reliably here, so there is no "Verification Window" delay needed.
     *
     * @param telecomState One of [android.telecom.Call.STATE_RINGING], [android.telecom.Call.STATE_DIALING],
     *   [android.telecom.Call.STATE_CONNECTING], [android.telecom.Call.STATE_ACTIVE],
     *   [android.telecom.Call.STATE_DISCONNECTED] or [android.telecom.Call.STATE_DISCONNECTING].
     * @param phoneNumber The raw phone number from the call's handle, or null/blank if unavailable (anonymous).
     */
    @Synchronized
    fun handleInCallServiceState(telecomState: Int, phoneNumber: String?) {
        if (!preferences.isCallRecordingEnabled()) return
        if (preferences.getCallDetectionMode() != AppPreferences.CallDetectionMode.IN_CALL_SERVICE) return

        AppLogger.i(TAG, "Received InCallService state: $telecomState | Number: $phoneNumber")

        when (telecomState) {
            android.telecom.Call.STATE_RINGING, android.telecom.Call.STATE_DIALING, android.telecom.Call.STATE_CONNECTING -> {
                sessionJob?.cancel()
                sessionJob = managerScope.launch {
                    processInCallServiceStart(telecomState, phoneNumber)
                }
            }
            android.telecom.Call.STATE_ACTIVE -> {
                if (session.isSessionActive) {
                    session.answeredViaDialer = true
                    evaluateAndStartService()
                }
            }
            android.telecom.Call.STATE_DISCONNECTED, android.telecom.Call.STATE_DISCONNECTING -> {
                sessionJob?.cancel()
                if (session.isSessionActive) {
                    AppLogger.d(TAG, "Call ended (InCallService). Sending stop INTENT to RecordingForegroundService.")
                    sendServiceCommand(RecordingForegroundService.ACTION_STOP_RECORDING)
                    session.clear()
                }
            }
        }
    }

    /**
     * Suspend counterpart of [handleInCallServiceState] for the RINGING/DIALING/CONNECTING states,
     * since [RecordingMetadata.enrichMetadata] must be called from a coroutine.
     */
    private suspend fun processInCallServiceStart(telecomState: Int, phoneNumber: String?) {
        if (!session.isSessionActive) {
            val direction = if (telecomState == android.telecom.Call.STATE_RINGING) RecordingDirection.INCOMING else RecordingDirection.OUTGOING
            val rawNumber = PhoneNumberManager.sanitizeOemNumber(phoneNumber)
            val enrichedMetadata = RecordingMetadata.enrichMetadata(appContext, RecordingMetadata(rawNumber, direction))
            withContext(Dispatchers.Main) {
                session.currentMetadata = enrichedMetadata
            }
        }
        AppLogger.d(TAG, "Evaluating service start at $telecomState state (InCallService).")
        withContext(Dispatchers.Main) {
            evaluateAndStartService(stillRingingUnanswered = telecomState == android.telecom.Call.STATE_RINGING)
        }
    }

    @Synchronized
    fun handleDebugAction(action: String) {
        if (!preferences.isDebugEnabled()) {
            AppLogger.w(TAG, "Received debug action '$action' but debug mode is disabled. Ignoring.")
            return
        }

        val debugPhoneNumber = preferences.getDebugCallerNumber()

        // Pass the action to handlePhoneState to simulate real call flow
        val telephonyExtState = when (action) {
            ACTION_DEBUG_IDLE     -> TelephonyManager.EXTRA_STATE_IDLE
            ACTION_DEBUG_RINGING  -> TelephonyManager.EXTRA_STATE_RINGING
            ACTION_DEBUG_OFFHOOK  -> TelephonyManager.EXTRA_STATE_OFFHOOK
            else -> return
        }

        AppLogger.i(TAG, "Handling debug action: '$action' ($telephonyExtState) with debug number: $debugPhoneNumber")
        handlePhoneState(telephonyExtState, debugPhoneNumber)
    }

    // Private helpers

    /**
     * Builds and fires an Intent to the [RecordingForegroundService].
     */
    private fun sendServiceCommand(action: String, metadata: RecordingMetadata? = null, suppressNotification: Boolean = false) {
        val intent = Intent(appContext, RecordingForegroundService::class.java).apply {
            this.action = action
            if (metadata != null) {
                putExtra(RecordingMetadata.EXTRA_METADATA, metadata)
            }
            if (suppressNotification) {
                putExtra(RecordingForegroundService.EXTRA_SUPPRESS_NOTIFICATION, true)
            }
        }
        if (action == RecordingForegroundService.ACTION_STOP_RECORDING) {
            // When Stopping, we use StartService as we assume the service is already running from startForegroundService. We only send it a new Intent that trigger cleanup.
            // we don't use stopService as it would give us a very short time to do any cleanup before the OS kill the service and prevent cleanup finalization.
            appContext.startService(intent)
        } else {
            appContext.startForegroundService(intent)
        }
    }

    /**
     * Determines whether the current call session should be automatically recorded based on user preferences.
     */
    private fun shouldAutoRecord(metadata: RecordingMetadata): Boolean {
        val rawNumber = metadata.rawPhoneNumber?.trim().orEmpty()
        val normalisedNumber = normalisePhoneNumber(rawNumber)
        val isAnonymous = normalisedNumber.isBlank()

        when (metadata.direction) {
            RecordingDirection.INCOMING -> {
                if (!preferences.isAutoRecordIncomingEnabled()) {
                    AppLogger.i(TAG, "Auto-record for incoming call is disabled")
                    return false
                }

                if (isAnonymous) {
                    if (preferences.isIgnoreAnonymousIncomingEnabled()) {
                        AppLogger.i(TAG, "Auto-record is ignoring incoming call since it's anonymous.")
                        return false
                    }
                }

                if (metadata.isCrossCountry && preferences.isIgnoreCrossCountryIncomingEnabled()) {
                    AppLogger.i(TAG, "Auto-record is ignoring incoming call since it's cross-country.")
                    return false
                }

                if (shouldIgnoreContact(normalisedNumber, preferences.getIgnoreContactsModeIncoming(), preferences.getIgnoredContactsIncoming())) {
                    AppLogger.i(TAG, "Auto-record is ignoring incoming call based on contact filtering.")
                    return false
                }

                AppLogger.i(TAG, "Auto-record is enabled for this incoming call.")
                return true
            }
            RecordingDirection.OUTGOING -> {
                if (!preferences.isAutoRecordOutgoingEnabled()) {
                    AppLogger.i(TAG, "Auto-record for outgoing call is disabled")
                    return false
                }

                if (metadata.isCrossCountry && preferences.isIgnoreCrossCountryOutgoingEnabled()) {
                    AppLogger.i(TAG, "Auto-record is ignoring outgoing call since it's cross-country.")
                    return false
                }

                if (shouldIgnoreContact(normalisedNumber, preferences.getIgnoreContactsModeOutgoing(), preferences.getIgnoredContactsOutgoing())) {
                    AppLogger.i(TAG, "Auto-record is ignoring outgoing call for based on contact filtering.")
                    return false
                }

                AppLogger.i(TAG, "Auto-record is enabled for this outgoing call.")
                return true
            }
        }
    }

    /**
     * Determines whether a call from/to a specific phone number should be ignored based on the user's contact filtering preferences.
     */
    private fun shouldIgnoreContact(normalisedNumber: String, mode: AppPreferences.IgnoreContactsMode, ignoredNumbers: Set<String>): Boolean {
        // Upstream fix (ShizuCallRecorder issue #95 / v1.3.3): a blank normalised number — e.g. from a
        // third-party app that puts non-numeric text in the phone number field, which gets stripped out
        // by normalisation — used to be encoded straight into the PhoneLookup URI below and queried
        // as-is, which could crash the content resolver. Bail out before building that URI at all.
        if (normalisedNumber.isBlank()) {
            AppLogger.i(TAG, "Cannot determine if contact should be ignored: phone number is blank, returning false")
            return false
        }

        val shouldIgnore = when (mode) {
            AppPreferences.IgnoreContactsMode.NONE  -> false
            AppPreferences.IgnoreContactsMode.ALL   -> {
                if (!PermissionChecks.hasContactsPermission(appContext)) {
                    false
                } else {
                    val lookupUri = Uri.withAppendedPath(
                        ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                        Uri.encode(normalisedNumber)
                    )

                    // Perform the query
                    val cursor = appContext.contentResolver.query(lookupUri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)

                    // Check if we got any results
                    cursor?.use {
                        // Basically, if we can find a contact, we return the object, so it's not null/false, else it's false.
                        it.moveToFirst()
                    } ?: false
                }
            }
            AppPreferences.IgnoreContactsMode.SELECTED ->
                ignoredNumbers.any { normalisePhoneNumber(it) == normalisedNumber }
        }

        return shouldIgnore
    }
}

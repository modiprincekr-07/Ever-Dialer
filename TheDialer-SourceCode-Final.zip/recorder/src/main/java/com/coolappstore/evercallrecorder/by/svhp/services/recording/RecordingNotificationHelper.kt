/*
 * ShizuCallRecorder: FOSS Call recording powered through ADB/Shizuku!
 *  Copyright (C) 2026-present kitsumed (Med)
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package com.coolappstore.evercallrecorder.by.svhp.services.recording

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationChannelGroup
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.coolappstore.evercallrecorder.by.svhp.R
import com.coolappstore.evercallrecorder.by.svhp.data.AppPreferences
import com.coolappstore.evercallrecorder.by.svhp.data.recordings.RecordingMetadata
import kotlin.random.Random

class RecordingNotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID_SERVICE = "recording_channel_service"
        const val CHANNEL_ID_ERROR = "recording_channel_error"
        const val CHANNEL_ID_POST_CALL = "recording_channel_post_call"
        const val CHANNEL_ID_SILENT_PLACEHOLDER = "recording_channel_silent_placeholder"

        const val SERVICE_NOTIFICATION_ID = 1
        const val ERROR_NOTIFICATION_ID = 2

        const val ACTION_DELETE_RECORDING = "com.coolappstore.evercallrecorder.by.svhp.action.DELETE_RECORDING"
        const val EXTRA_RECORDING_URI = "com.coolappstore.evercallrecorder.by.svhp.EXTRA_RECORDING_URI"
        const val EXTRA_NOTIFICATION_ID = "com.coolappstore.evercallrecorder.by.svhp.EXTRA_NOTIFICATION_ID"
    }

    /**
     * Creates the Android notification channel for recording notifications.
     */

    fun createNotificationChannels() {
        val manager = context.getSystemService(NotificationManager::class.java)
        val notificationsEnabled = AppPreferences(context).isRecordingNotificationsEnabled()

        val groupId = "recording_channel_group"
        val group = NotificationChannelGroup(groupId, "Recording Channel")
        manager.createNotificationChannelGroup(group)

        // Recreate the channels so importance changes take effect immediately when the
        // "Enable recording notifications" toggle is flipped (channel importance can't be
        // changed in-place once created).
        manager.deleteNotificationChannel(CHANNEL_ID_SERVICE)
        manager.deleteNotificationChannel(CHANNEL_ID_ERROR)

        val serviceImportance = if (notificationsEnabled) NotificationManager.IMPORTANCE_HIGH else NotificationManager.IMPORTANCE_MIN
        val serviceChannel = NotificationChannel(
            CHANNEL_ID_SERVICE, "Foreground Recording Service", serviceImportance
        ).apply {
            this.group = groupId
            // Alert channel should be visible but we handle vibration manually
            setSound(null, null)
            enableLights(false)
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = if (notificationsEnabled) NotificationCompat.VISIBILITY_PUBLIC else NotificationCompat.VISIBILITY_SECRET
        }
        manager.createNotificationChannel(serviceChannel)

        val errorImportance = if (notificationsEnabled) NotificationManager.IMPORTANCE_HIGH else NotificationManager.IMPORTANCE_MIN
        val errorChannel = NotificationChannel(
            CHANNEL_ID_ERROR, "Recording Errors", errorImportance
        ).apply {
            this.group = groupId
            enableVibration(false) // We handle vibration manually
            setShowBadge(notificationsEnabled)
            lockscreenVisibility = if (notificationsEnabled) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_SECRET
        }
        manager.createNotificationChannel(errorChannel)

        manager.deleteNotificationChannel(CHANNEL_ID_POST_CALL)
        val postCallImportance = if (notificationsEnabled) NotificationManager.IMPORTANCE_DEFAULT else NotificationManager.IMPORTANCE_MIN
        val postCallChannel = NotificationChannel(
            CHANNEL_ID_POST_CALL, "Recording Saved", postCallImportance
        ).apply {
            this.group = groupId
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = if (notificationsEnabled) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_SECRET
        }
        manager.createNotificationChannel(postCallChannel)

        // Always IMPORTANCE_MIN (never heads-up, no sound, no status bar icon), regardless of the
        // "Enable recording notifications" preference — this channel exists purely so the service
        // can call startForeground() (satisfying the OS's few-seconds requirement) at moments we
        // don't actually want anything visible to the user yet, e.g. an incoming call that's
        // still ringing/unanswered, so it never pops up on top of / races with the answer/decline UI.
        manager.deleteNotificationChannel(CHANNEL_ID_SILENT_PLACEHOLDER)
        val silentPlaceholderChannel = NotificationChannel(
            CHANNEL_ID_SILENT_PLACEHOLDER, "Preparing Recording (hidden)", NotificationManager.IMPORTANCE_MIN
        ).apply {
            this.group = groupId
            setSound(null, null)
            enableLights(false)
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = NotificationCompat.VISIBILITY_SECRET
        }
        manager.createNotificationChannel(silentPlaceholderChannel)
    }

    /**
     * A minimal, silent, IMPORTANCE_MIN notification used only to satisfy [android.app.Service.startForeground]'s
     * OS requirement without actually showing anything meaningful to the user. See [CHANNEL_ID_SILENT_PLACEHOLDER].
     */
    fun getSilentPlaceholderNotification(): Notification {
        return NotificationCompat.Builder(context, CHANNEL_ID_SILENT_PLACEHOLDER)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setSilent(true)
            .setOngoing(true)
            .setShowWhen(false)
            .build()
    }

    fun getNotification(state: RecordingServiceState): Notification {
        val titleRes: Int
        val contentRes: Int
        val actionIcon: Int?
        val actionText: String?
        val actionIntentAction: String?
        // We want to show the cross-country tip if we are unsure about the metadata, as it is better to be safe than sorry.
        val subRes: Int = if (state.metadata == null || state.metadata?.isCrossCountry == true) R.string.recording_notification_cross_country_tip else R.string.recording_notification_current_country_tip
        // "Record calls from apps" sessions show which app the call came from instead of the cross-country tip.
        val sourceApp = state.metadata?.sourceApp
        val subText = if (sourceApp != null) context.getString(R.string.recording_notification_via_app, sourceApp) else context.getString(subRes)

        when (state) {
            is RecordingServiceState.Starting -> {
                titleRes = R.string.recording_standby_notification_title
                contentRes = R.string.recording_notification_waiting_shizuku
                actionIcon = null
                actionText = null
                actionIntentAction = null
            }
            is RecordingServiceState.Active -> {
                if (state.isPaused) {
                    titleRes = R.string.recording_standby_notification_title
                    contentRes = R.string.recording_notification_press_to_resume
                    actionIcon = R.drawable.ic_stop
                    actionText = context.getString(R.string.general_resume)
                    actionIntentAction = RecordingForegroundService.ACTION_RESUME_RECORDING
                } else {
                    titleRes = R.string.recording_notification_title
                    contentRes = R.string.recording_notification_press_to_pause
                    actionIcon = R.drawable.ic_mic
                    actionText = context.getString(R.string.general_pause)
                    actionIntentAction = RecordingForegroundService.ACTION_PAUSE_RECORDING
                }
            }
            else -> {
                titleRes = R.string.recording_standby_notification_title
                contentRes = R.string.recording_notification_press_to_start
                actionIcon = R.drawable.ic_mic
                actionText = context.getString(R.string.general_record)
                actionIntentAction = RecordingForegroundService.ACTION_MANUAL_START
            }
        }

        // The delete intent is triggered when the user dismisses the notification (Thanks Android 14+).
        val deletePendingIntent = PendingIntent.getService(
            context, 99,
            Intent(context, RecordingForegroundService::class.java).apply {
                action = RecordingForegroundService.ACTION_NOTIFICATION_DISMISSED
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationsEnabled = AppPreferences(context).isRecordingNotificationsEnabled()

        val builder = NotificationCompat.Builder(context, CHANNEL_ID_SERVICE)
            .setSmallIcon(R.drawable.ic_mic)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher))
            .setContentTitle(context.getString(titleRes))
            .setContentText(context.getString(contentRes))
            .setSubText(subText)
            .setOngoing(true) // Almost useless starting Android 14+ :)
            .setDeleteIntent(deletePendingIntent) // Android 14+ workaround :)
            .setVisibility(if (notificationsEnabled) NotificationCompat.VISIBILITY_PUBLIC else NotificationCompat.VISIBILITY_SECRET)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setSilent(!notificationsEnabled || state is RecordingServiceState.Active || state is RecordingServiceState.Starting) // Don't do a screen-incursion if we are already recording.
            .setPriority(if (notificationsEnabled) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_MIN)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

        if (actionText != null && actionIntentAction != null && actionIcon != null) {
            val actionPendingIntent = PendingIntent.getService(
                context, 1,
                Intent(context, RecordingForegroundService::class.java).apply {
                    action = actionIntentAction
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(actionIcon, actionText, actionPendingIntent)
        }

        return builder.build()
    }

    /**
     * Handles showing toasts for state changes.  It determines a toast based on the old and new state.
     * @param oldState The previous state of the recording service.
     * @param newState The new state of the recording service.
     */
    fun handleStateChangeToasts(oldState: RecordingServiceState, newState: RecordingServiceState) {
        if (oldState == newState) return // Ignore duplicates

        when (newState) {
            is RecordingServiceState.Standby -> {
                if (newState.metadata == null) {
                    showToast(context.getString(R.string.recording_toast_ended))
                    vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), intArrayOf(0, 64, 0, 128), -1))
                } else if (oldState !is RecordingServiceState.Standby) {
                    val dirLabel = newState.metadata.direction.labelResId.let { context.getString(it) }
                    showToast(context.getString(R.string.recording_toast_standby, dirLabel))
                }
            }
            is RecordingServiceState.Active -> {
                val wasActive = oldState is RecordingServiceState.Active
                val wasPaused = wasActive && (oldState as RecordingServiceState.Active).isPaused

                if (newState.isPaused && (!wasActive || !wasPaused)) {
                    // Recording was paused
                    showToast(context.getString(R.string.recording_toast_paused))
                    vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), intArrayOf(0, 64, 0, 128), -1))
                } else if (!newState.isPaused && wasPaused) {
                    // Recording was resumed
                    showToast(context.getString(R.string.recording_toast_resumed))
                    vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), intArrayOf(0, 64, 0, 128), -1))
                } else if (!newState.isPaused && !wasActive) {
                    // Recording was started
                    showToast(context.getString(R.string.recording_started))
                    vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), intArrayOf(0, 64, 0, 128), -1))
                }
            }
            else -> {}
        }
    }

    /**
     * Shows a short Toast message on the UI thread.
     */
    fun showToast(message: String) {
        if (!AppPreferences(context).isShowToastsEnabled()) return

        Handler(Looper.getMainLooper()).post {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Posts an error notification visible.
     *
     * @param message Human-readable error description to show in the notification body.
     */
    fun showErrorNotification(message: String) {
        if (!AppPreferences(context).isRecordingNotificationsEnabled()) return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID_ERROR)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(context.getString(R.string.recording_error_title))
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(false)
            .setCategory(NotificationCompat.CATEGORY_ERROR)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(ERROR_NOTIFICATION_ID, notification)
        vibrate(VibrationEffect.createWaveform(longArrayOf(0, 100, 800), intArrayOf(0, 46, 184), -1))
    }

    /**
     * Posts a notification after a recording finishes, offering Open/Share/Delete quick actions
     * on the saved file. Gated by [AppPreferences.isPostRecordingFileActionsNotificationEnabled].
     *
     * @param recordingUri The content:// URI of the finished recording (SAF or private-storage FileProvider URI).
     * @param metadata The metadata for the call that was just recorded, used for the notification text.
     */
    fun showPostCallNotification(recordingUri: Uri, metadata: RecordingMetadata?) {
        if (!AppPreferences(context).isPostRecordingFileActionsNotificationEnabled()) return

        val mimeType = context.contentResolver.getType(recordingUri) ?: "audio/*"
        val notificationId = Random.nextInt(1000, Int.MAX_VALUE)

        val directionLabel = metadata?.direction?.labelResId?.let { context.getString(it) } ?: ""
        val bestNumber = metadata?.getBestNumber()?.takeIf { it.isNotBlank() }
        // Upstream improvement (v1.3.2): show the caller's contact name in the post-call
        // notification instead of just the bare number, when it can be resolved.
        val contactName = bestNumber?.let {
            com.coolappstore.evercallrecorder.by.svhp.utils.RecordingFileNameFormatter.getContactName(context, it)
        }
        val numberLabel = when {
            contactName != null && bestNumber != null -> "$contactName ($bestNumber)"
            contactName != null -> contactName
            bestNumber != null -> bestNumber
            else -> metadata?.sourceApp
        }
        val contentText = context.getString(
            R.string.post_recording_notification_text,
            listOfNotNull(numberLabel, directionLabel.ifBlank { null }).joinToString(" · ")
        )

        val openIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(recordingUri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context, notificationId, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, recordingUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooserIntent = Intent.createChooser(shareIntent, context.getString(R.string.general_share)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val sharePendingIntent = PendingIntent.getActivity(
            context, notificationId + 1, chooserIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val deleteIntent = Intent(context, PostRecordingActionReceiver::class.java).apply {
            action = ACTION_DELETE_RECORDING
            putExtra(EXTRA_RECORDING_URI, recordingUri)
            putExtra(EXTRA_NOTIFICATION_ID, notificationId)
        }
        val deletePendingIntent = PendingIntent.getBroadcast(
            context, notificationId + 2, deleteIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_POST_CALL)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(context.getString(R.string.post_recording_notification_title))
            .setContentText(contentText)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(openPendingIntent)
            .addAction(0, context.getString(R.string.general_open), openPendingIntent)
            .addAction(0, context.getString(R.string.general_share), sharePendingIntent)
            .addAction(0, context.getString(R.string.general_delete), deletePendingIntent)
            .build()

        context.getSystemService(NotificationManager::class.java).notify(notificationId, notification)
    }

    /**
     * Triggers a vibration if enabled in settings.
     */
    fun vibrate(effect: VibrationEffect) {
        if (!AppPreferences(context).isVibrationEnabled()) return

        if (Build.VERSION.SDK_INT >= 31) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            if (manager.defaultVibrator.hasVibrator()) {
                manager.defaultVibrator.vibrate(effect)
            }
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(effect)
            }
        }
    }
}

package com.modiprincekr.thedialer.view.components.tiles

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.findRootCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.modiprincekr.thedialer.view.theme.SettingsClickTracker
import com.modiprincekr.thedialer.view.components.RivoAvatar
import com.modiprincekr.thedialer.view.components.RivoDropdownMenu
import com.modiprincekr.thedialer.view.components.RivoDropdownMenuItem
import com.modiprincekr.thedialer.view.components.performAppHaptic
import org.koin.compose.koinInject

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SingleTile(
    title: String,
    modifier: Modifier = Modifier,
    titleMaxLines: Int = 1,
    subtitle: String? = null,
    photoUri: String? = null,
    icon: ImageVector? = null,
    iconContainerColor: Color? = null,
    trailingContent: (@Composable () -> Unit)? = null,
    supportingContent: (@Composable () -> Unit)? = null,
    titleTrailing: (@Composable () -> Unit)? = null,
    isMissedCall: Boolean = false,
    phoneNumber: String? = null,
    forcePersonIcon: Boolean = false,
    showAvatar: Boolean = true,
    onAvatarClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    isMenuOpen: Boolean = false,
    onSelectMode: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val haptic  = LocalHapticFeedback.current
    val prefs   = koinInject<PreferenceManager>()
    val settingsVer by prefs.settingsChanged.collectAsState()
    val circleIcons = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_CIRCLE_ICONS, false) }
    var showMenu              by remember { mutableStateOf(false) }
    // Sync with external isMenuOpen
    LaunchedEffect(isMenuOpen) { if (isMenuOpen) showMenu = true }
    var isPressed             by remember { mutableStateOf(false) }
    var horizontalDragDetected by remember { mutableStateOf(false) }

    var avatarCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var rowCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val recordAvatarClick: () -> Unit = {
        avatarCoords?.let { coords ->
            val center = coords.boundsInRoot().center
            val rootSize = coords.findRootCoordinates().size
            SettingsClickTracker.recordTap(
                center.x, center.y, rootSize.width.toFloat(), rootSize.height.toFloat()
            )
        } ?: rowCoords?.let { coords ->
            val bounds = coords.boundsInRoot()
            val rootSize = coords.findRootCoordinates().size
            SettingsClickTracker.recordTap(
                bounds.left + 38f, bounds.center.y, rootSize.width.toFloat(), rootSize.height.toFloat()
            )
        } ?: SettingsClickTracker.recordNormalized(0.12f, 0.5f)
    }

    val scale by animateFloatAsState(
        targetValue    = if (showMenu) 0.97f else if (isPressed) 0.95f else 1f,
        animationSpec  = spring(
            stiffness    = Spring.StiffnessLow,
            dampingRatio = Spring.DampingRatioMediumBouncy
        ),
        label = "TileScale"
    )

    val numberForMenu = phoneNumber ?: subtitle?.filter { it.isDigit() || it == '+' }
        ?.takeIf { it.length >= 5 } ?: subtitle

    Surface(
        color           = Color.Transparent,
        modifier        = modifier.fillMaxWidth().scale(scale),
        shadowElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .onGloballyPositioned { rowCoords = it }
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication        = null,
                    onClick           = {
                        if (prefs.getBoolean(PreferenceManager.KEY_APP_HAPTICS, true)) {
                            performAppHaptic(
                                context,
                                prefs.getString(PreferenceManager.KEY_APP_HAPTICS_STRENGTH, "light") ?: "light",
                                prefs.getFloat(PreferenceManager.KEY_HAPTICS_CUSTOM_INTENSITY, 0.5f)
                            )
                        }
                        recordAvatarClick()
                        onClick()
                    },
                    onLongClick       = onLongClick
                )
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        isPressed = true
                        horizontalDragDetected = false
                        do {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull()
                            if (change != null && change.pressed) {
                                val dragAmount = change.position - change.previousPosition
                                if (kotlin.math.abs(dragAmount.x) > kotlin.math.abs(dragAmount.y) && kotlin.math.abs(dragAmount.x) > 10f) {
                                    horizontalDragDetected = true
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (horizontalDragDetected && onSelectMode != null) {
                            if (prefs.getBoolean(PreferenceManager.KEY_APP_HAPTICS, true)) {
                                performAppHaptic(
                                    context,
                                    prefs.getString(PreferenceManager.KEY_APP_HAPTICS_STRENGTH, "light") ?: "light",
                                    prefs.getFloat(PreferenceManager.KEY_HAPTICS_CUSTOM_INTENSITY, 0.5f)
                                )
                            }
                            onSelectMode()
                        }
                        isPressed = false
                        horizontalDragDetected = false
                    }
                }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showAvatar) {
                RivoAvatar(
                    name               = title,
                    photoUri           = photoUri,
                    forcePersonIcon    = forcePersonIcon,
                    icon               = icon,
                    iconContainerColor = iconContainerColor,
                    modifier           = Modifier
                        .size(42.dp)
                        .onGloballyPositioned { avatarCoords = it }
                        .then(
                            if (onAvatarClick != null)
                                Modifier.combinedClickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = {
                                        if (prefs.getBoolean(PreferenceManager.KEY_APP_HAPTICS, true)) {
                                            performAppHaptic(
                                                context,
                                                prefs.getString(PreferenceManager.KEY_APP_HAPTICS_STRENGTH, "light") ?: "light",
                                                prefs.getFloat(PreferenceManager.KEY_HAPTICS_CUSTOM_INTENSITY, 0.5f)
                                            )
                                        }
                                        recordAvatarClick()
                                        onAvatarClick()
                                    }
                                )
                            else Modifier
                        ),
                    shape              = if (circleIcons) CircleShape else RoundedCornerShape(14.dp)
                )
            }

            Column(
                modifier            = Modifier.weight(1f).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text     = title,
                        style    = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color    = if (isMissedCall) MaterialTheme.colorScheme.error
                                   else MaterialTheme.colorScheme.onSurface,
                        maxLines = titleMaxLines,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (titleTrailing != null) {
                        titleTrailing()
                    }
                }
                if (supportingContent != null) {
                    supportingContent()
                } else if (subtitle != null) {
                    Text(
                        text     = subtitle,
                        style    = MaterialTheme.typography.bodyMedium,
                        color    = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (trailingContent != null) {
                Box(modifier = Modifier.padding(start = 8.dp)) {
                    trailingContent()
                }
            }
        }

        RivoDropdownMenu(
            expanded         = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            if (onSelectMode != null) {
                RivoDropdownMenuItem(
                    text     = "Select",
                    icon     = Icons.Default.CheckBox,
                    iconTint = Color(0xFF9C27B0),
                    onClick  = {
                        showMenu = false
                        onSelectMode()
                    }
                )
                HorizontalDivider(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    color    = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )
            }
            RivoDropdownMenuItem(
                text     = "Call",
                icon     = Icons.Default.Call,
                iconTint = Color(0xFF4CAF50),
                onClick  = {
                    showMenu = false
                    onClick()
                }
            )
            if (!numberForMenu.isNullOrEmpty()) {
                RivoDropdownMenuItem(
                    text     = "Copy number",
                    icon     = Icons.Default.ContentCopy,
                    iconTint = Color(0xFF2196F3),
                    onClick  = {
                        showMenu = false
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Phone number", numberForMenu))
                        Toast.makeText(context, "Number copied", Toast.LENGTH_SHORT).show()
                    }
                )
                RivoDropdownMenuItem(
                    text     = "Add to contacts",
                    icon     = Icons.Default.PersonAdd,
                    iconTint = Color(0xFF9C27B0),
                    onClick  = {
                        showMenu = false
                        val intent = Intent(Intent.ACTION_INSERT).apply {
                            type = ContactsContract.RawContacts.CONTENT_TYPE
                            putExtra(ContactsContract.Intents.Insert.PHONE, numberForMenu)
                        }
                        context.startActivity(intent)
                    }
                )
                RivoDropdownMenuItem(
                    text     = "Send SMS",
                    icon     = Icons.Default.Message,
                    iconTint = Color(0xFF009688),
                    onClick  = {
                        showMenu = false
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = android.net.Uri.parse("sms:$numberForMenu")
                        }
                        context.startActivity(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun TileGroup(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        color    = MaterialTheme.colorScheme.surfaceContainerLow,
        shape    = RoundedCornerShape(28.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp), content = content)
    }
}

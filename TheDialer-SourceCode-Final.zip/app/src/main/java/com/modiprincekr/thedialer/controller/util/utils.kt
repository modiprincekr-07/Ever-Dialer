package com.modiprincekr.thedialer.controller.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.text.format.DateUtils
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val tlCalendar = ThreadLocal.withInitial { Calendar.getInstance() }

private var cachedCurrentYear: Int = -1
private var cachedCurrentYearTimestamp: Long = 0L

private fun getCurrentYear(): Int {
    val now = System.currentTimeMillis()
    if (cachedCurrentYear == -1 || now - cachedCurrentYearTimestamp > 60_000L) {
        val cal = tlCalendar.get()
        cal.timeInMillis = now
        cachedCurrentYear = cal.get(Calendar.YEAR)
        cachedCurrentYearTimestamp = now
    }
    return cachedCurrentYear
}

private fun isYesterday(timestamp: Long): Boolean {
    return DateUtils.isToday(timestamp + DateUtils.DAY_IN_MILLIS)
}

private fun isTimestampInCurrentYear(timestamp: Long): Boolean {
    val cal = tlCalendar.get()
    cal.timeInMillis = timestamp
    return cal.get(Calendar.YEAR) == getCurrentYear()
}

private fun getRelativeDay(timestamp: Long): String? {
    return when {
        DateUtils.isToday(timestamp) -> "Today"
        isYesterday(timestamp) -> "Yesterday"
        else -> null
    }
}

// Thread-local formatters so we never allocate SimpleDateFormat on every call during scroll
private val tlTimeFormat12 = ThreadLocal.withInitial { SimpleDateFormat("h:mm a", Locale.getDefault()) }
private val tlTimeFormat24 = ThreadLocal.withInitial { SimpleDateFormat("HH:mm", Locale.getDefault()) }
private val tlHeaderSameYear = ThreadLocal.withInitial { SimpleDateFormat("MMMM d", Locale.getDefault()) }
private val tlHeaderDiffYear = ThreadLocal.withInitial { SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()) }
private val tlCallLogDateSameYear = ThreadLocal.withInitial { SimpleDateFormat("MMM d", Locale.getDefault()) }
private val tlCallLogDateDiffYear = ThreadLocal.withInitial { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
private val reusableDate = ThreadLocal.withInitial { Date() }

fun formatDateHeader(timestamp: Long): String {
    val relative = getRelativeDay(timestamp)
    if (relative != null) return relative

    val formatter = if (isTimestampInCurrentYear(timestamp)) tlHeaderSameYear.get() else tlHeaderDiffYear.get()
    val date = reusableDate.get()
    date.time = timestamp
    return formatter.format(date)
}

fun formatDate(timestamp: Long, use24Hour: Boolean = false): String {
    val relative = getRelativeDay(timestamp)
    val timeFormatter = if (use24Hour) tlTimeFormat24.get() else tlTimeFormat12.get()
    val date = reusableDate.get()
    date.time = timestamp
    val time = timeFormatter.format(date)
    return if (relative != null) "$relative, $time" else "${formatDateHeader(timestamp)}, $time"
}

/**
 * Formats just the time portion of a call log entry, respecting the
 * Settings → Appearance → "Call Time Format in call logs" preference
 * (12-hour "h:mm a" by default, or 24-hour "HH:mm" when [use24Hour] is true).
 */
fun formatTimeOnly(timestamp: Long, use24Hour: Boolean = false): String {
    val formatter = if (use24Hour) tlTimeFormat24.get() else tlTimeFormat12.get()
    val date = reusableDate.get()
    date.time = timestamp
    return formatter.format(date)
}

/**
 * Formats just the date portion of a call log entry when grouped by latest calls.
 * Displays "Today", "Yesterday", "MMM d" (current year), or "MMM d, yyyy" (other years).
 */
fun formatCallLogDate(timestamp: Long): String {
    val relative = getRelativeDay(timestamp)
    if (relative != null) return relative

    val formatter = if (isTimestampInCurrentYear(timestamp)) tlCallLogDateSameYear.get() else tlCallLogDateDiffYear.get()
    val date = reusableDate.get()
    date.time = timestamp
    return formatter.format(date)
}

fun formatDuration(durationSeconds: Long): String {
    return DateUtils.formatElapsedTime(durationSeconds)
}

/**
 * Metadata for a call-capable SIM or calling account.
 */
data class SimAccountInfo(
    val handle: PhoneAccountHandle,
    val slotIndex: Int, // 0 for SIM 1, 1 for SIM 2, -1 for other
    val displayName: String,
    val carrierName: String?,
    val number: String?,
    val isSimSubscription: Boolean,
    val colorInt: Int
)

/** Returns true if the device currently has 2 or more call-capable SIMs (dual/multi-SIM). */
fun hasDualSim(context: Context): Boolean {
    return try {
        val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (!hasPhoneState) return false
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val tmAccounts = telecomManager?.callCapablePhoneAccounts?.size ?: 0
        if (tmAccounts >= 2) return true
        val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? android.telephony.SubscriptionManager
        val subs = sm?.activeSubscriptionInfoList?.size ?: 0
        subs >= 2
    } catch (_: Exception) {
        false
    }
}

/** Resolves a telecom PhoneAccountHandle (as reported on the live Call object) to a
 *  0-based SIM slot index via SubscriptionManager and TelephonyManager, or -1 if it can't be determined.
 *  0 = SIM 1, 1 = SIM 2. */
fun getSimSlotForAccountHandle(context: Context, accountHandle: PhoneAccountHandle?): Int {
    if (accountHandle == null) return -1
    return try {
        val tm = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager
        val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? android.telephony.SubscriptionManager

        val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val phoneAccount = try { tm?.getPhoneAccount(accountHandle) } catch (_: Throwable) { null }

        // 1. Official Android 10+ (API 29+) API: TelephonyManager.getSubscriptionId(accountHandle)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q && hasPhoneState && telephonyManager != null && sm != null) {
            try {
                val subId = telephonyManager.getSubscriptionId(accountHandle)
                if (subId != android.telephony.SubscriptionManager.INVALID_SUBSCRIPTION_ID && subId > 0) {
                    val subInfo = sm.getActiveSubscriptionInfo(subId)
                    val slot = subInfo?.simSlotIndex
                    if (slot != null && slot in 0..1) return slot
                }
            } catch (_: Throwable) {}
        }

        // 2. Check PhoneAccount extras for explicit subscription ID or slot index
        phoneAccount?.extras?.let { extras ->
            val subIdExtra = listOf(
                "android.telephony.extra.SUBSCRIPTION_INDEX",
                "android.telecom.extra.SUBSCRIPTION_ID",
                "subscription_id",
                "sub_id"
            ).firstNotNullOfOrNull { key ->
                if (extras.containsKey(key)) extras.getInt(key, -1).takeIf { it > 0 } else null
            }
            if (subIdExtra != null && sm != null && hasPhoneState) {
                val slot = try { sm.getActiveSubscriptionInfo(subIdExtra)?.simSlotIndex } catch (_: Throwable) { null }
                if (slot != null && slot in 0..1) return slot
            }

            val slotExtra = listOf(
                "android.telephony.extra.SLOT_INDEX",
                "sim_slot",
                "slot",
                "simSlotIndex",
                "slot_index"
            ).firstNotNullOfOrNull { key ->
                if (extras.containsKey(key)) extras.getInt(key, -1).takeIf { it in 0..1 } else null
            }
            if (slotExtra != null) return slotExtra
        }

        // 3. Match against active subscriptions from SubscriptionManager
        if (hasPhoneState && sm != null) {
            val activeList = try { sm.activeSubscriptionInfoList } catch (_: Throwable) { null }
            if (!activeList.isNullOrEmpty()) {
                val handleId = accountHandle.id.orEmpty()

                // 3a. Handle ID as integer subId:
                val subIdFromHandle = handleId.toIntOrNull()
                if (subIdFromHandle != null && subIdFromHandle > 0) {
                    val matchedSub = activeList.firstOrNull { it.subscriptionId == subIdFromHandle }
                    if (matchedSub != null && matchedSub.simSlotIndex in 0..1) {
                        return matchedSub.simSlotIndex
                    }
                }

                // 3b. Match by ICCID
                val iccidMatch = activeList.firstOrNull { sub ->
                    !sub.iccId.isNullOrEmpty() && (handleId.equals(sub.iccId, ignoreCase = true) || handleId.contains(sub.iccId) || sub.iccId.contains(handleId))
                }
                if (iccidMatch != null && iccidMatch.simSlotIndex in 0..1) {
                    return iccidMatch.simSlotIndex
                }

                // 3c. Match by phone number (address)
                val accountAddress = phoneAccount?.address?.schemeSpecificPart?.filter { it.isDigit() }
                if (!accountAddress.isNullOrEmpty()) {
                    val numMatch = activeList.firstOrNull { sub ->
                        val subNum = sub.number?.filter { it.isDigit() }
                        !subNum.isNullOrEmpty() && (accountAddress.endsWith(subNum) || subNum.endsWith(accountAddress))
                    }
                    if (numMatch != null && numMatch.simSlotIndex in 0..1) {
                        return numMatch.simSlotIndex
                    }
                }

                // 3d. Check label / description matching carrier or slot
                val label = phoneAccount?.label?.toString().orEmpty()
                val desc = phoneAccount?.shortDescription?.toString().orEmpty()
                val textToScan = "$label $desc"
                if (textToScan.contains("SIM 1", ignoreCase = true) || textToScan.contains("Slot 1", ignoreCase = true)) return 0
                if (textToScan.contains("SIM 2", ignoreCase = true) || textToScan.contains("Slot 2", ignoreCase = true)) return 1

                val carrierMatch = activeList.firstOrNull { sub ->
                    val cName = sub.carrierName?.toString().orEmpty()
                    val dName = sub.displayName?.toString().orEmpty()
                    (cName.isNotBlank() && textToScan.contains(cName, ignoreCase = true)) ||
                    (dName.isNotBlank() && textToScan.contains(dName, ignoreCase = true))
                }
                if (carrierMatch != null && carrierMatch.simSlotIndex in 0..1) {
                    return carrierMatch.simSlotIndex
                }

                // 3e. If exactly 1 SIM is active, this account must belong to that slot
                if (activeList.size == 1) {
                    return activeList[0].simSlotIndex
                }
            }
        }

        // 4. Check PhoneAccount label as standalone
        val label = phoneAccount?.label?.toString().orEmpty()
        if (label.contains("SIM 1", ignoreCase = true) || label.contains("Slot 1", ignoreCase = true)) return 0
        if (label.contains("SIM 2", ignoreCase = true) || label.contains("Slot 2", ignoreCase = true)) return 1

        -1
    } catch (_: Exception) { -1 }
}

/** Resolves a live Call object to a 0-based SIM slot index (0 = SIM 1, 1 = SIM 2). */
fun getSimSlotForCall(context: Context, call: Call?): Int {
    if (call == null) return -1
    return try {
        val details = call.details
        // 1. Direct account handle check
        val handleSlot = getSimSlotForAccountHandle(context, details?.accountHandle)
        if (handleSlot in 0..1) return handleSlot

        // 2. Extras check (SLOT_INDEX, SUBSCRIPTION_ID, etc.)
        val extrasList = listOfNotNull(details?.extras, details?.intentExtras)
        val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? android.telephony.SubscriptionManager
        val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

        for (extras in extrasList) {
            val slot = listOf(
                "android.telephony.extra.SLOT_INDEX",
                "sim_slot",
                "slot",
                "simSlotIndex",
                "slot_index"
            ).firstNotNullOfOrNull { key ->
                if (extras.containsKey(key)) extras.getInt(key, -1).takeIf { it in 0..1 } else null
            }
            if (slot != null) return slot

            val subId = listOf(
                "android.telephony.extra.SUBSCRIPTION_INDEX",
                "android.telecom.extra.SUBSCRIPTION_ID",
                "subscription_id",
                "sub_id"
            ).firstNotNullOfOrNull { key ->
                if (extras.containsKey(key)) extras.getInt(key, -1).takeIf { it > 0 } else null
            }
            if (subId != null && sm != null && hasPhoneState) {
                val slotFromSub = sm.getActiveSubscriptionInfo(subId)?.simSlotIndex
                if (slotFromSub != null && slotFromSub in 0..1) return slotFromSub
            }
        }

        // 3. Fallback: if only 1 active SIM subscription exists
        if (hasPhoneState && sm != null) {
            val activeList = try { sm.activeSubscriptionInfoList } catch (_: Throwable) { null }
            if (activeList?.size == 1 && activeList[0].simSlotIndex in 0..1) {
                return activeList[0].simSlotIndex
            }
        }

        -1
    } catch (_: Exception) { -1 }
}

/**
 * Resolves the display or carrier name for a 0-based SIM slot index (0 = SIM 1, 1 = SIM 2).
 */
fun getSimCarrierName(context: Context, simSlot: Int): String {
    return try {
        val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE)
                as? android.telephony.SubscriptionManager
        val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (hasPhoneState && sm != null) {
            val list = try { sm.activeSubscriptionInfoList } catch (_: Throwable) { null }
            val sub = if (simSlot in 0..1) list?.firstOrNull { it.simSlotIndex == simSlot } else list?.firstOrNull()
            sub?.carrierName?.toString()?.takeIf { it.isNotBlank() }
                ?: sub?.displayName?.toString()?.takeIf { it.isNotBlank() }
                ?: if (simSlot == 1) "SIM 2" else "SIM 1"
        } else {
            if (simSlot == 1) "SIM 2" else "SIM 1"
        }
    } catch (_: Throwable) {
        if (simSlot == 1) "SIM 2" else "SIM 1"
    }
}

/**
 * Resolves a CallLog Calls.PHONE_ACCOUNT_ID string to its 0-based SIM slot index (0 = SIM 1, 1 = SIM 2).
 */
fun getSimSlotForPhoneAccountId(context: Context, phoneAccountId: String?): Int {
    if (phoneAccountId.isNullOrBlank()) return -1
    return try {
        val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE)
                as? android.telephony.SubscriptionManager
        val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (sm != null && hasPhoneState) {
            val subId = phoneAccountId.toIntOrNull()
            if (subId != null && subId > 0) {
                val info = sm.getActiveSubscriptionInfo(subId)
                if (info != null && info.simSlotIndex in 0..1) return info.simSlotIndex
            }
            val activeList = sm.activeSubscriptionInfoList
            if (!activeList.isNullOrEmpty()) {
                val iccidMatch = activeList.firstOrNull { sub ->
                    !sub.iccId.isNullOrEmpty() && (phoneAccountId.equals(sub.iccId, ignoreCase = true) || phoneAccountId.contains(sub.iccId) || sub.iccId.contains(phoneAccountId))
                }
                if (iccidMatch != null && iccidMatch.simSlotIndex in 0..1) {
                    return iccidMatch.simSlotIndex
                }
            }
        }

        val tm = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val accounts = try { tm?.callCapablePhoneAccounts } catch (_: Throwable) { null }
        val matchingHandle = accounts?.firstOrNull { it.id == phoneAccountId }
        if (matchingHandle != null) {
            val slot = getSimSlotForAccountHandle(context, matchingHandle)
            if (slot in 0..1) return slot
        }

        -1
    } catch (_: Exception) { -1 }
}

fun makeCall(context: Context, number: String, accountHandle: PhoneAccountHandle? = null, skipConfirm: Boolean = false) {
    val sanitized = number.trim().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    if (sanitized.isEmpty()) {
        android.util.Log.w("EverDialerCall", "makeCall: empty number after sanitizing '$number', aborting")
        return
    }

    if (!skipConfirm) {
        val prefs = context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean(PreferenceManager.KEY_CONFIRM_PLACING_CALL, false)) {
            val intent = Intent(context, com.modiprincekr.thedialer.view.screen.ConfirmCallActivity::class.java).apply {
                putExtra(com.modiprincekr.thedialer.view.screen.ConfirmCallActivity.EXTRA_NUMBER, sanitized)
                if (accountHandle != null) {
                    putExtra(com.modiprincekr.thedialer.view.screen.ConfirmCallActivity.EXTRA_ACCOUNT_HANDLE, accountHandle)
                }
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            try {
                context.startActivity(intent)
                return
            } catch (e: Throwable) {
                android.util.Log.e("EverDialerCall", "Failed to start ConfirmCallActivity", e)
            }
        }
    }

    val uri = Uri.fromParts("tel", sanitized, null)
    val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
    if (telecomManager == null) {
        val intent = Intent(Intent.ACTION_DIAL, uri).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        try { context.startActivity(intent) } catch (_: Throwable) {}
        return
    }
    val extras = Bundle()
    if (accountHandle != null) {
        extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, accountHandle)
        rememberLastUsedSim(context, telecomManager, accountHandle)
    }
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
        try {
            android.util.Log.d("EverDialerCall", "placeCall uri=$uri account=$accountHandle")
            telecomManager.placeCall(uri, extras)
        } catch (e: Throwable) {
            // placeCall() can throw if appops, per-user restrictions, or stale handle occurs
            android.util.Log.e("EverDialerCall", "placeCall threw exception, falling back to ACTION_DIAL", e)
            val intent = Intent(Intent.ACTION_DIAL, uri).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            try { context.startActivity(intent) } catch (_: Throwable) {}
        }
    } else {
        android.util.Log.w("EverDialerCall", "makeCall: CALL_PHONE not granted, falling back to ACTION_DIAL")
        val intent = Intent(Intent.ACTION_DIAL, uri).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        try { context.startActivity(intent) } catch (_: Throwable) {}
    }
}

/** Persists which SIM (1-based index: 1 = SIM 1, 2 = SIM 2) [accountHandle] corresponds to. */
private fun rememberLastUsedSim(context: Context, telecomManager: TelecomManager, accountHandle: PhoneAccountHandle) {
    try {
        val slot = getSimSlotForAccountHandle(context, accountHandle)
        if (slot in 0..1) {
            context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE).edit()
                .putInt(PreferenceManager.KEY_LAST_USED_SIM_GLOBAL, slot + 1)
                .apply()
        }
    } catch (_: Throwable) { /* best-effort only */ }
}

/** Resolves a 0-based SIM slot index (0 for SIM 1, 1 for SIM 2) to its PhoneAccountHandle from [accounts]. */
fun getPhoneAccountForSimSlot(context: Context, accounts: List<PhoneAccountHandle>, targetSlot: Int): PhoneAccountHandle? {
    if (accounts.isEmpty()) return null
    if (accounts.size == 1) return accounts.first()

    // 1. Direct slot match via getSimSlotForAccountHandle
    val matched = accounts.firstOrNull { getSimSlotForAccountHandle(context, it) == targetSlot }
    if (matched != null) return matched

    // 2. Relative deduction: if targetSlot == 0, find the one that is NOT slot 1; if targetSlot == 1, find the one that is NOT slot 0
    if (accounts.size == 2) {
        val otherSlot = if (targetSlot == 0) 1 else 0
        val otherAccount = accounts.firstOrNull { getSimSlotForAccountHandle(context, it) == otherSlot }
        if (otherAccount != null) {
            val remaining = accounts.firstOrNull { it != otherAccount }
            if (remaining != null) return remaining
        }
    }

    // 3. Match by label or description ("SIM 1" / "SIM 2")
    val tm = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
    val labelMatch = accounts.firstOrNull { handle ->
        val info = try { tm?.getPhoneAccount(handle) } catch (_: Throwable) { null }
        val label = info?.label?.toString().orEmpty()
        val desc = info?.shortDescription?.toString().orEmpty()
        val text = "$label $desc"
        if (targetSlot == 0) (text.contains("1") && !text.contains("2"))
        else (text.contains("2") && !text.contains("1"))
    }
    if (labelMatch != null) return labelMatch

    // 4. Fallback: index within list
    return accounts.getOrNull(targetSlot) ?: accounts.firstOrNull()
}

/**
 * Returns call-capable accounts sorted strictly: SIM 1 (slot 0) first, SIM 2 (slot 1) second,
 * followed by any non-SIM accounts.
 */
fun getOrderedSimAccounts(
    context: Context,
    availableAccounts: List<PhoneAccountHandle>? = null
): List<SimAccountInfo> {
    val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager ?: return emptyList()
    val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? android.telephony.SubscriptionManager
    val prefs = context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)

    val sim1Color = prefs.getInt(PreferenceManager.KEY_SIM1_COLOR, PreferenceManager.DEFAULT_SIM1_COLOR)
    val sim2Color = prefs.getInt(PreferenceManager.KEY_SIM2_COLOR, PreferenceManager.DEFAULT_SIM2_COLOR)

    val rawHandles: List<PhoneAccountHandle> = if (!availableAccounts.isNullOrEmpty()) {
        availableAccounts
    } else {
        try {
            telecomManager.callCapablePhoneAccounts ?: emptyList()
        } catch (_: Throwable) {
            emptyList()
        }
    }

    if (rawHandles.isEmpty()) return emptyList()

    val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
    val activeSubs = if (hasPhoneState && sm != null) {
        try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: Throwable) { emptyList() }
    } else emptyList()

    val result = mutableListOf<SimAccountInfo>()

    for (handle in rawHandles) {
        val phoneAccount = try { telecomManager.getPhoneAccount(handle) } catch (_: Throwable) { null }
        if (phoneAccount != null && !phoneAccount.isEnabled) continue

        val slot = getSimSlotForAccountHandle(context, handle)
        val isSimSubscription = phoneAccount?.hasCapabilities(android.telecom.PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true || slot in 0..1

        val subInfo = (if (slot in 0..1) activeSubs.firstOrNull { it.simSlotIndex == slot } else null)
            ?: activeSubs.firstOrNull { sub ->
                val handleId = handle.id.orEmpty()
                handleId == sub.subscriptionId.toString() ||
                (!sub.iccId.isNullOrEmpty() && (handleId.contains(sub.iccId) || sub.iccId.contains(handleId)))
            }

        val simDisplayName = subInfo?.displayName?.toString()?.takeIf { it.isNotBlank() }
            ?: subInfo?.carrierName?.toString()?.takeIf { it.isNotBlank() }
            ?: phoneAccount?.label?.toString()?.takeIf { it.isNotBlank() }

        val carrierName = subInfo?.carrierName?.toString()?.takeIf { it.isNotBlank() }
            ?: subInfo?.displayName?.toString()?.takeIf { it.isNotBlank() }
            ?: phoneAccount?.label?.toString()?.takeIf { it.isNotBlank() }

        val simNumber = subInfo?.number?.takeIf { it.isNotBlank() }
            ?: phoneAccount?.address?.schemeSpecificPart?.takeIf { it.isNotBlank() }
            ?: phoneAccount?.shortDescription?.toString()?.takeIf { it.isNotBlank() }

        val displayName = when {
            slot == 0 -> simDisplayName ?: "SIM 1"
            slot == 1 -> simDisplayName ?: "SIM 2"
            else -> phoneAccount?.label?.toString() ?: "Calling Account"
        }

        val colorInt = when (slot) {
            0 -> sim1Color
            1 -> sim2Color
            else -> sim1Color
        }

        result.add(
            SimAccountInfo(
                handle = handle,
                slotIndex = slot,
                displayName = displayName,
                carrierName = carrierName,
                number = simNumber,
                isSimSubscription = isSimSubscription,
                colorInt = colorInt
            )
        )
    }

    // Deduplicate any handles that point to the same slot
    val distinctAccounts = mutableListOf<SimAccountInfo>()
    val seenSlots = mutableSetOf<Int>()
    for (acc in result) {
        if (acc.slotIndex in 0..1) {
            if (seenSlots.add(acc.slotIndex)) {
                distinctAccounts.add(acc)
            }
        } else {
            distinctAccounts.add(acc)
        }
    }

    // Sort strictly: slot 0 (SIM 1) first, slot 1 (SIM 2) second, other accounts after
    return distinctAccounts.sortedWith(compareBy(
        { if (it.slotIndex in 0..1) it.slotIndex else 100 },
        { it.displayName }
    ))
}

/**
 * Places a call respecting the user's default SIM preference.
 * simPref: 0 = ask, 1 = SIM1 (slot 0), 2 = SIM2 (slot 1)
 * Returns true if a direct call was placed, false if sim picker should be shown.
 */
fun placeCallWithSimPreference(
    context: Context,
    number: String,
    simPref: Int,
    onShowSimPicker: () -> Unit
) {
    val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
    val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
    if (hasPhoneState && telecomManager != null) {
        val accounts = try { telecomManager.callCapablePhoneAccounts } catch (_: Throwable) { emptyList() }
        if (accounts.size > 1) {
            val useSimFromCallLog = context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)
                .getBoolean(PreferenceManager.KEY_USE_SIM_FROM_CALL_LOG, false)
            if (useSimFromCallLog || simPref == 3) {
                val slot = queryRecentSimSlot(context, number)
                if (slot != null) {
                    val handle = getPhoneAccountForSimSlot(context, accounts, slot)
                    if (handle != null) {
                        makeCall(context, number, handle)
                        return
                    }
                }
            }
            when {
                simPref == 1 && accounts.isNotEmpty() -> {
                    val handle = getPhoneAccountForSimSlot(context, accounts, 0)
                    if (handle != null) makeCall(context, number, handle) else onShowSimPicker()
                }
                simPref == 2 && accounts.size >= 2 -> {
                    val handle = getPhoneAccountForSimSlot(context, accounts, 1)
                    if (handle != null) makeCall(context, number, handle) else onShowSimPicker()
                }
                else -> onShowSimPicker()
            }
        } else {
            makeCall(context, number)
        }
    } else {
        makeCall(context, number)
    }
}

/**
 * Places a call for a specific contact, honoring that contact's "Choose Sim" preference
 * (Contact Info → Choose Sim) before falling back to the app-wide default SIM setting.
 *
 * [contactSimChoice] is one of the PreferenceManager.SIM_CHOICE_* constants.
 * [recentSimSlotForContact] is the 0-based SIM slot of this contact's most recent call log
 * entry (or null/unknown), used for the "last used SIM for this contact" option.
 * [globalSimPref] is the app-wide default-SIM setting (0 = ask, 1 = SIM1, 2 = SIM2), used when
 * the contact's own choice is "According to settings".
 */
fun queryRecentSimSlot(context: Context, number: String): Int? {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return null
    return try {
        val cr = context.contentResolver
        val uri = android.provider.CallLog.Calls.CONTENT_URI
        val cleanNumber = number.trim()
        val digits = cleanNumber.filter { it.isDigit() }
        if (digits.isEmpty()) return null

        cr.query(
            uri,
            arrayOf(android.provider.CallLog.Calls.PHONE_ACCOUNT_ID, android.provider.CallLog.Calls.NUMBER),
            "${android.provider.CallLog.Calls.PHONE_ACCOUNT_ID} IS NOT NULL",
            null,
            "${android.provider.CallLog.Calls.DATE} DESC LIMIT 50"
        )?.use { cursor ->
            val accountIdIdx = cursor.getColumnIndex(android.provider.CallLog.Calls.PHONE_ACCOUNT_ID)
            val numberIdx = cursor.getColumnIndex(android.provider.CallLog.Calls.NUMBER)
            while (cursor.moveToNext()) {
                val num = if (numberIdx >= 0) cursor.getString(numberIdx) else null
                if (num != null && numbersLikelyMatch(num, cleanNumber)) {
                    val accountId = if (accountIdIdx >= 0) cursor.getString(accountIdIdx) else null
                    val slot = getSimSlotForPhoneAccountId(context, accountId)
                    if (slot in 0..1) return slot
                }
            }
            null
        }
    } catch (_: Exception) { null }
}

fun placeCallWithContactSimPreference(
    context: Context,
    number: String,
    contactSimChoice: String,
    globalSimPref: Int,
    recentSimSlotForContact: Int?,
    onShowSimPicker: () -> Unit
) {
    val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
    val hasPhoneState = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
    if (!hasPhoneState || telecomManager == null) { makeCall(context, number); return }

    val accounts = try { telecomManager.callCapablePhoneAccounts } catch (_: Throwable) { emptyList() }
    if (accounts.size <= 1) { makeCall(context, number, accounts.firstOrNull()); return }

    when (contactSimChoice) {
        PreferenceManager.SIM_CHOICE_ASK -> onShowSimPicker()
        PreferenceManager.SIM_CHOICE_SIM1 -> {
            val handle = getPhoneAccountForSimSlot(context, accounts, 0)
            if (handle != null) makeCall(context, number, handle) else onShowSimPicker()
        }
        PreferenceManager.SIM_CHOICE_SIM2 -> {
            val handle = getPhoneAccountForSimSlot(context, accounts, 1)
            if (handle != null) makeCall(context, number, handle) else onShowSimPicker()
        }
        PreferenceManager.SIM_CHOICE_CALL_LOG,
        PreferenceManager.SIM_CHOICE_LAST_FOR_CONTACT -> {
            val slot = recentSimSlotForContact ?: queryRecentSimSlot(context, number)
            val handle = if (slot != null) getPhoneAccountForSimSlot(context, accounts, slot) else null
            if (handle != null) makeCall(context, number, handle)
            else onShowSimPicker()
        }
        PreferenceManager.SIM_CHOICE_LAST_IN_CALL -> {
            val lastIdx = context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)
                .getInt(PreferenceManager.KEY_LAST_USED_SIM_GLOBAL, 0)
            val handle = if (lastIdx in 1..2) getPhoneAccountForSimSlot(context, accounts, lastIdx - 1)
                         else if (lastIdx in 1..accounts.size) accounts[lastIdx - 1]
                         else null
            if (handle != null) makeCall(context, number, handle)
            else onShowSimPicker()
        }
        else -> {
            // SIM_CHOICE_SETTINGS: falls back to app-wide default SIM setting
            val useSimFromCallLog = context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)
                .getBoolean(PreferenceManager.KEY_USE_SIM_FROM_CALL_LOG, false)
            if (useSimFromCallLog || globalSimPref == 3) {
                val slot = recentSimSlotForContact ?: queryRecentSimSlot(context, number)
                val handle = if (slot != null) getPhoneAccountForSimSlot(context, accounts, slot) else null
                if (handle != null) {
                    makeCall(context, number, handle)
                    return
                }
            }
            placeCallWithSimPreference(context, number, globalSimPref, onShowSimPicker)
        }
    }
}

/**
 * Resolves and places a call honoring a specific contact's "Choose Sim" preference (Contact
 * Info → Choose Sim), falling back to the app-wide default SIM setting when the contact has no
 * override — the same resolution Contact Info itself uses, but reusable from any screen that
 * places calls (Favorites, Recents/Call Log, Dialpad, etc.) so the per-contact choice actually
 * applies everywhere a call to that contact can be started, not just from Contact Info.
 *
 * [contactKey] must match the keying used elsewhere (contact id for a saved contact, or the raw
 * phone number for an unsaved/unknown one) so the correct stored preference is looked up.
 */
fun placeCallHonoringContactSim(
    context: Context,
    prefs: PreferenceManager,
    contactKey: String,
    number: String,
    recentSimSlotForContact: Int? = null,
    onShowSimPicker: () -> Unit
) {
    val globalSimPref = prefs.getInt(PreferenceManager.KEY_DEFAULT_SIM, prefs.getDefaultSimIndexDefault())
    val contactSimChoice = prefs.getContactSimChoice(contactKey, number)
    placeCallWithContactSimPreference(context, number, contactSimChoice, globalSimPref, recentSimSlotForContact, onShowSimPicker)
}

/**
 * Strips everything except digits and a leading '+' so two differently-formatted
 * representations of the same number ("+1 (555) 123-4567" vs "5551234567") can be compared.
 */
fun normalizeNumberDigits(number: String): String =
    number.filter { it.isDigit() || it == '+' }

/**
 * The shortest digit length at which a suffix match is trusted. Below this, a short/partial
 * dialed number (e.g. a 3-digit short code like "787" or "875") must NOT be allowed to match
 * a saved contact just because the contact's full number happens to start with, end with, or
 * contain those same digits — that's what previously caused call-log entries for short codes
 * to incorrectly resolve to (and redirect to) an unrelated saved contact.
 */
private const val MIN_TRUSTED_SUFFIX_MATCH_LEN = 7

/**
 * Equality check for two phone numbers that correctly handles a contact being saved with a
 * country code (e.g. "+917875551234") while the call-log/dialed number is the plain national
 * number ("7875551234"), or vice versa — WITHOUT falling into the trap of a short number
 * (a 3-digit short code) matching against a much longer number that merely contains those
 * digits somewhere in it. Used to decide whether a call-log number belongs to a saved contact.
 */
fun numbersLikelyMatch(a: String, b: String): Boolean {
    if (a.isBlank() || b.isBlank()) return false
    if (a == b) return true
    try {
        if (android.telephony.PhoneNumberUtils.compare(a, b)) return true
    } catch (_: Exception) {}
    val da = normalizeNumberDigits(a).filter { it.isDigit() }
    val db = normalizeNumberDigits(b).filter { it.isDigit() }
    if (da.isEmpty() || db.isEmpty()) return false
    if (da == db) return true
    val shorterLen = minOf(da.length, db.length)
    if (shorterLen < MIN_TRUSTED_SUFFIX_MATCH_LEN) return false
    if (da.endsWith(db) || db.endsWith(da)) return true
    val matchLen = minOf(shorterLen, 10)
    for (len in matchLen downTo MIN_TRUSTED_SUFFIX_MATCH_LEN) {
        if (da.takeLast(len) == db.takeLast(len)) return true
    }
    return false
}

fun openInContacts(context: Context, contactId: String) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        data = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, contactId)
    }
    context.startActivity(intent)
}

fun openLink(context: Context, link: String) {
    val intent = Intent(Intent.ACTION_VIEW,
        link.toUri())
    context.startActivity(intent)
}

fun silenceRingingCall(context: Context) {
    try {
        val tm = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        tm?.silenceRinger()
    } catch (_: Exception) {}
    try {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        am?.adjustStreamVolume(android.media.AudioManager.STREAM_RING, android.media.AudioManager.ADJUST_MUTE, 0)
    } catch (_: Exception) {}
    try {
        val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
        }
        vibrator?.cancel()
    } catch (_: Exception) {}
}

fun deduplicatePhoneNumbers(numbers: List<String>): List<String> {
    val result = mutableListOf<String>()
    for (num in numbers) {
        val trimmed = num.trim()
        if (trimmed.isBlank()) continue
        if (result.none { numbersLikelyMatch(it, trimmed) }) {
            result.add(trimmed)
        }
    }
    return result
}

fun levenshteinDistance(s1: String, s2: String): Int {
    if (s1 == s2) return 0
    if (s1.isEmpty()) return s2.length
    if (s2.isEmpty()) return s1.length

    val d = Array(s1.length + 1) { IntArray(s2.length + 1) }
    for (i in 0..s1.length) d[i][0] = i
    for (j in 0..s2.length) d[0][j] = j

    for (i in 1..s1.length) {
        for (j in 1..s2.length) {
            val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
            d[i][j] = minOf(
                d[i - 1][j] + 1,       // deletion
                d[i][j - 1] + 1,       // insertion
                d[i - 1][j - 1] + cost // substitution
            )
        }
    }
    return d[s1.length][s2.length]
}

/**
 * Typo-tolerant, whitespace-insensitive, case-insensitive string matcher.
 * Handles:
 * 1. Case-insensitivity (lowercase)
 * 2. Unintentional extra/missing spaces (comparing space-stripped and whitespace-normalized forms)
 * 3. Substring matching
 * 4. Spelling mistakes / typo tolerance via Levenshtein edit distance on words or tokens
 */
fun matchesFuzzySearch(target: String, query: String): Boolean {
    if (query.isBlank()) return true
    if (target.isBlank()) return false

    val tLower = target.lowercase()
    val qLower = query.trim().lowercase()

    // 1. Direct contains (case insensitive)
    if (tLower.contains(qLower)) return true

    // 2. Ignore all spaces (handles unintentional spaces, e.g. "ever dialer" vs "everdialer" or "ap p" vs "app")
    val tNoSpaces = tLower.replace(" ", "")
    val qNoSpaces = qLower.replace(" ", "")
    if (qNoSpaces.isNotEmpty() && tNoSpaces.contains(qNoSpaces)) return true

    // 3. Typo-tolerant matching (Levenshtein distance)
    // Check if query is close to any sub-sequence or word of target
    val qTokens = qLower.split("\\s+".toRegex()).filter { it.isNotBlank() }
    val tTokens = tLower.split("[\\s_\\-•,]+".toRegex()).filter { it.isNotBlank() }

    if (qTokens.isEmpty()) return false

    // If query has tokens, see if every query token fuzzy-matches some target token or substring
    val allTokensMatch = qTokens.all { qTok ->
        val maxAllowedDistance = when {
            qTok.length <= 3 -> 0
            qTok.length in 4..6 -> 1
            else -> 2
        }

        // Direct token substring
        if (tLower.contains(qTok)) {
            true
        } else {
            // Levenshtein match against any target token
            tTokens.any { tTok ->
                if (tTok.contains(qTok)) true
                else if (maxAllowedDistance > 0 && kotlin.math.abs(tTok.length - qTok.length) <= maxAllowedDistance) {
                    levenshteinDistance(tTok, qTok) <= maxAllowedDistance
                } else false
            }
        }
    }

    if (allTokensMatch) return true

    // Also check entire stripped query against entire stripped target for typos if reasonably long
    val totalMaxDist = when {
        qNoSpaces.length <= 4 -> 0
        qNoSpaces.length in 5..8 -> 1
        else -> 2
    }
    if (totalMaxDist > 0 && kotlin.math.abs(tNoSpaces.length - qNoSpaces.length) <= totalMaxDist) {
        if (levenshteinDistance(tNoSpaces, qNoSpaces) <= totalMaxDist) return true
    }

    return false
}


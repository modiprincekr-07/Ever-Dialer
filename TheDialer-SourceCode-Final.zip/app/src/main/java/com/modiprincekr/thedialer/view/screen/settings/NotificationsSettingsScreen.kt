package com.modiprincekr.thedialer.view.screen.settings

import android.app.NotificationManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NotificationImportant
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.SignalCellularAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.modiprincekr.thedialer.controller.PcSyncService
import com.modiprincekr.thedialer.controller.util.MissedCallBadgeManager
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.coolappstore.everdialer.by.svhp.feature.AppFeatures
import com.modiprincekr.thedialer.view.components.RivoAnimatedSection
import com.modiprincekr.thedialer.view.components.RivoExpressiveCard
import com.modiprincekr.thedialer.view.components.RivoSwitchListItem
import com.modiprincekr.thedialer.view.components.SettingsPillTopAppBar
import com.modiprincekr.thedialer.view.components.rivoHeadingColor
import com.modiprincekr.thedialer.view.components.settingsSearchHighlight
import com.modiprincekr.thedialer.view.theme.SettingsTransitionStyle
import com.modiprincekr.thedialer.view.theme.settingsMotionBlur
import com.ramcosta.composedestinations.annotation.Destination
import com.ramcosta.composedestinations.annotation.RootGraph
import com.ramcosta.composedestinations.navigation.DestinationsNavigator
import org.koin.compose.koinInject

private val ColorBlue   = Color(0xFF1E88E5)
private val ColorRed    = Color(0xFFE53935)
private val ColorOrange = Color(0xFFFB8C00)
private val ColorGreen  = Color(0xFF43A047)
private val ColorTeal   = Color(0xFF00897B)

@OptIn(ExperimentalMaterial3Api::class)
@Destination<RootGraph>(style = SettingsTransitionStyle::class)
@Composable
fun NotificationsSettingsScreen(
    navigator: DestinationsNavigator,
    highlightKey: String? = null
) {
    val context = LocalContext.current
    val prefs = koinInject<PreferenceManager>()
    var highlightedKey by remember { mutableStateOf(highlightKey) }

    // Missed Call notification state (default on, provider default system)
    var missedCallNotification by remember {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_MISSED_CALL_NOTIFICATION, true))
    }
    var missedCallProvider by remember {
        mutableStateOf(
            prefs.getString(
                PreferenceManager.KEY_MISSED_CALL_NOTIFICATION_PROVIDER,
                PreferenceManager.MISSED_CALL_PROVIDER_SYSTEM
            ) ?: PreferenceManager.MISSED_CALL_PROVIDER_SYSTEM
        )
    }

    // PC Connect notification state
    var showPcNotification by remember {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_PC_SYNC_SHOW_NOTIFICATION, true))
    }

    // Call Recording notification states
    var recordingNotifications by remember {
        mutableStateOf(if (AppFeatures.isCallRecorderAvailable) AppFeatures.isRecordingNotificationsEnabled(context) else false)
    }
    var postRecordingNotification by remember {
        mutableStateOf(if (AppFeatures.isCallRecorderAvailable) AppFeatures.isPostRecordingNotificationEnabled(context) else false)
    }
    var showToasts by remember {
        mutableStateOf(if (AppFeatures.isCallRecorderAvailable) AppFeatures.isShowToastsEnabled(context) else false)
    }

    // 4G/5G Switcher notification state
    var nsNotifications by remember {
        mutableStateOf(if (AppFeatures.isNetworkSwitchAvailable) AppFeatures.isNetworkSwitchNotificationsEnabled(context) else false)
    }

    Scaffold(
        modifier = Modifier.settingsMotionBlur(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            SettingsPillTopAppBar(
                title = "Notifications",
                onBackClick = { navigator.navigateUp() }
            )
        }
    ) { padding ->
        val navBarBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = padding.calculateTopPadding())
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 16.dp + navBarBottom),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ── Missed Calls ──────────────────────────────────────────────────────
            RivoAnimatedSection(delayMs = 0L) {
                Column {
                    Text(
                        "Missed Calls",
                        style = MaterialTheme.typography.labelLarge,
                        color = rivoHeadingColor(),
                        modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                    )
                    RivoExpressiveCard {
                        RivoSwitchListItem(
                            headline = "Missed Call Notification",
                            supporting = if (missedCallNotification) {
                                if (missedCallProvider == PreferenceManager.MISSED_CALL_PROVIDER_EVER_DIALER) {
                                    "Prompted by Ever Dialer notification"
                                } else {
                                    "Prompted by Android System"
                                }
                            } else "Missed call notifications disabled",
                            leadingIcon = Icons.AutoMirrored.Filled.CallMissed,
                            iconContainerColor = ColorRed,
                            checked = missedCallNotification,
                            modifier = Modifier.settingsSearchHighlight("missed_call_notification", highlightedKey) { highlightedKey = null },
                            onCheckedChange = { isChecked ->
                                missedCallNotification = isChecked
                                prefs.setBoolean(PreferenceManager.KEY_MISSED_CALL_NOTIFICATION, isChecked)
                                if (isChecked) {
                                    if (missedCallProvider == PreferenceManager.MISSED_CALL_PROVIDER_EVER_DIALER) {
                                        MissedCallBadgeManager.cancelSystemMissedCallNotification(context)
                                        MissedCallBadgeManager.updateBadge(context)
                                    }
                                } else {
                                    (context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager)?.cancel(
                                        MissedCallBadgeManager.MISSED_CALLS_NOTIF_ID
                                    )
                                    MissedCallBadgeManager.cancelSystemMissedCallNotification(context)
                                    MissedCallBadgeManager.markMissedCallsAsRead(context)
                                }
                            }
                        )

                        AnimatedVisibility(visible = missedCallNotification) {
                            Column {
                                HorizontalDivider(
                                    modifier = Modifier.padding(horizontal = 16.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                )
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                ) {
                                    Text(
                                        text = "Notification Provider",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        FilterChip(
                                            selected = missedCallProvider == PreferenceManager.MISSED_CALL_PROVIDER_SYSTEM,
                                            onClick = {
                                                missedCallProvider = PreferenceManager.MISSED_CALL_PROVIDER_SYSTEM
                                                prefs.setString(
                                                    PreferenceManager.KEY_MISSED_CALL_NOTIFICATION_PROVIDER,
                                                    PreferenceManager.MISSED_CALL_PROVIDER_SYSTEM
                                                )
                                                (context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager)?.cancel(
                                                    MissedCallBadgeManager.MISSED_CALLS_NOTIF_ID
                                                )
                                                prefs.setInt("active_ever_dialer_missed_count", 0)
                                            },
                                            label = { Text("System") },
                                            leadingIcon = if (missedCallProvider == PreferenceManager.MISSED_CALL_PROVIDER_SYSTEM) {
                                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                            } else null,
                                            shape = CircleShape
                                        )
                                        FilterChip(
                                            selected = missedCallProvider == PreferenceManager.MISSED_CALL_PROVIDER_EVER_DIALER,
                                            onClick = {
                                                missedCallProvider = PreferenceManager.MISSED_CALL_PROVIDER_EVER_DIALER
                                                prefs.setString(
                                                    PreferenceManager.KEY_MISSED_CALL_NOTIFICATION_PROVIDER,
                                                    PreferenceManager.MISSED_CALL_PROVIDER_EVER_DIALER
                                                )
                                                MissedCallBadgeManager.cancelSystemMissedCallNotification(context)
                                                MissedCallBadgeManager.updateBadge(context)
                                            },
                                            label = { Text("Ever Dialer") },
                                            leadingIcon = if (missedCallProvider == PreferenceManager.MISSED_CALL_PROVIDER_EVER_DIALER) {
                                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                            } else null,
                                            shape = CircleShape
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ── PC Connect ────────────────────────────────────────────────────────
            RivoAnimatedSection(delayMs = 40L) {
                Column {
                    Text(
                        "PC Connect",
                        style = MaterialTheme.typography.labelLarge,
                        color = rivoHeadingColor(),
                        modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                    )
                    RivoExpressiveCard {
                        RivoSwitchListItem(
                            headline = "Notification",
                            supporting = "Show connected to PC notification in notification bar",
                            leadingIcon = Icons.Outlined.Notifications,
                            iconContainerColor = ColorBlue,
                            checked = showPcNotification,
                            modifier = Modifier.settingsSearchHighlight("pc_sync_notification", highlightedKey) { highlightedKey = null },
                            onCheckedChange = { isChecked ->
                                showPcNotification = isChecked
                                prefs.setBoolean(PreferenceManager.KEY_PC_SYNC_SHOW_NOTIFICATION, isChecked)
                                PcSyncService.updateNotificationVisibility(context, isChecked)
                            }
                        )
                    }
                }
            }

            // ── Call Recording ────────────────────────────────────────────────────
            if (AppFeatures.isCallRecorderAvailable) {
                RivoAnimatedSection(delayMs = 40L) {
                    Column {
                        Text(
                            "Call Recording",
                            style = MaterialTheme.typography.labelLarge,
                            color = rivoHeadingColor(),
                            modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                        )
                        RivoExpressiveCard {
                            RivoSwitchListItem(
                                headline = "Recording Notifications",
                                supporting = "Show notification during call recording",
                                leadingIcon = Icons.Outlined.Notifications,
                                iconContainerColor = ColorRed,
                                checked = recordingNotifications,
                                modifier = Modifier.settingsSearchHighlight("recording_notifications", highlightedKey) { highlightedKey = null },
                                onCheckedChange = { isChecked ->
                                    recordingNotifications = isChecked
                                    AppFeatures.setRecordingNotificationsEnabled(context, isChecked)
                                }
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                            RivoSwitchListItem(
                                headline = "Post-recording Notification",
                                supporting = "Show notification with options to play, share, or delete after recording finishes",
                                leadingIcon = Icons.Outlined.NotificationImportant,
                                iconContainerColor = ColorOrange,
                                checked = postRecordingNotification,
                                modifier = Modifier.settingsSearchHighlight("post_recording_notification", highlightedKey) { highlightedKey = null },
                                onCheckedChange = { isChecked ->
                                    postRecordingNotification = isChecked
                                    AppFeatures.setPostRecordingNotificationEnabled(context, isChecked)
                                }
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                            RivoSwitchListItem(
                                headline = "Toast Notifications",
                                supporting = "Show status toasts for recording actions",
                                leadingIcon = Icons.Outlined.Info,
                                iconContainerColor = ColorGreen,
                                checked = showToasts,
                                modifier = Modifier.settingsSearchHighlight("show_recording_toasts", highlightedKey) { highlightedKey = null },
                                onCheckedChange = { isChecked ->
                                    showToasts = isChecked
                                    AppFeatures.setShowToastsEnabled(context, isChecked)
                                }
                            )
                        }
                    }
                }
            }

            // ── 4G/5G Switcher ────────────────────────────────────────────────────
            if (AppFeatures.isNetworkSwitchAvailable) {
                RivoAnimatedSection(delayMs = 80L) {
                    Column {
                        Text(
                            "4G/5G Switcher",
                            style = MaterialTheme.typography.labelLarge,
                            color = rivoHeadingColor(),
                            modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                        )
                        RivoExpressiveCard {
                            RivoSwitchListItem(
                                headline = "Automation Service Notification",
                                supporting = "Show notification in status bar while automation service is running",
                                leadingIcon = Icons.Outlined.SignalCellularAlt,
                                iconContainerColor = ColorTeal,
                                checked = nsNotifications,
                                modifier = Modifier.settingsSearchHighlight("automation_notifications", highlightedKey) { highlightedKey = null },
                                onCheckedChange = { isChecked ->
                                    nsNotifications = isChecked
                                    AppFeatures.setNetworkSwitchNotificationsEnabled(context, isChecked)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

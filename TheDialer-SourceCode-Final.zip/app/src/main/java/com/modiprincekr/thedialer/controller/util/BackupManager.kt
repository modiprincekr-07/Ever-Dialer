package com.modiprincekr.thedialer.controller.util

import android.content.Context
import android.content.SharedPreferences
import com.modiprincekr.thedialer.modal.data.Contact
import com.modiprincekr.thedialer.modal.`interface`.IContactsRepository
import com.modiprincekr.thedialer.modal.repository.ContactsRepository
import org.json.JSONArray
import org.json.JSONObject
import org.koin.core.context.GlobalContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import com.coolappstore.everdialer.by.svhp.feature.AppFeatures

object BackupManager {

    data class BackupContents(
        val hasSettings: Boolean = false,
        val hasCallingCards: Boolean = false,
        val hasNotes: Boolean = false,
        val hasContactGroups: Boolean = false,
        val hasRecordings: Boolean = false,
        val hasContacts: Boolean = false,
        val hasCallLogs: Boolean = false,
        val hasSms: Boolean = false,
        val hasLiquidGlass: Boolean = false,
        val hasAlternateNumbers: Boolean = false
    ) {
        val hasAny: Boolean
            get() = hasSettings || hasCallingCards || hasNotes || hasContactGroups || hasRecordings || hasContacts || hasCallLogs || hasSms || hasLiquidGlass || hasAlternateNumbers
    }

    const val PREFS_RIVO = "rivo_prefs"
    const val PREFS_RECORDER = "evercallrecorder_prefs"
    const val PREFS_RECORDER_FAV = "home_favourites"
    const val PREFS_RECORDER_NOTES = "recording_notes"
    const val PREFS_RECORDER_SORT = "sort_config"
    const val PREFS_RECORDER_DURATION = "recording_duration"
    const val PREFS_NS_MASTER = "network_switch_master_switch"
    const val PREFS_NS_AUTO = "network_switch_automation_flags"
    const val PREFS_MISSED_CALL_DURATION = "missed_call_durations"
    const val PREFS_WIDGET = "recent_calls_widget_prefs"
    const val PREFS_DIRECT_CALL_WIDGET = "direct_call_widget_prefs"
    const val PREFS_CONTACT_INFO_WIDGET = "contact_info_widget_prefs"
    const val PREFS_ALTERNATE_NUMBERS = "alternate_numbers_prefs"

    val KNOWN_PREFS = listOf(
        PREFS_RIVO,
        PREFS_RECORDER,
        PREFS_RECORDER_FAV,
        PREFS_RECORDER_NOTES,
        PREFS_RECORDER_SORT,
        PREFS_RECORDER_DURATION,
        PREFS_NS_MASTER,
        PREFS_NS_AUTO,
        PREFS_MISSED_CALL_DURATION,
        PREFS_WIDGET,
        PREFS_DIRECT_CALL_WIDGET,
        PREFS_CONTACT_INFO_WIDGET,
        PREFS_ALTERNATE_NUMBERS
    )

    fun getBackupDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(null), "Backups")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getBackgroundsDir(context: Context): File {
        val dir = File(context.filesDir, "backgrounds")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getContactMediaDir(context: Context): File {
        val dir = File(context.filesDir, "contact_media")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getContactGifsDir(context: Context): File {
        val dir = File(context.filesDir, "contact_gifs")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun isCallingCardKey(key: String): Boolean {
        return key.startsWith("contact_") ||
                key.endsWith("_media_bg") ||
                key.endsWith("_gif_bg") ||
                key.startsWith("incoming_") ||
                key.startsWith("ongoing_") ||
                key.startsWith("call_ui_") ||
                key.startsWith("caller_ui_") ||
                key.startsWith("banner_") ||
                key.startsWith("show_incoming_") ||
                key.startsWith("show_ongoing_") ||
                key.startsWith("show_fullscreen_") ||
                key == PreferenceManager.KEY_SHOW_INCOMING_CALL_UI ||
                key == PreferenceManager.KEY_SHOW_CALLER_UI ||
                key == PreferenceManager.KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS ||
                key == PreferenceManager.KEY_SHOW_ONGOING_CALL_UI_WHEN_ANSWERED ||
                key == PreferenceManager.KEY_SHOW_ONGOING_CALL_UI_ON_LOCKSCREEN_WHEN_ANSWERED ||
                key == PreferenceManager.KEY_CALL_UI_ORDER
    }

    fun isContactGroupKey(key: String): Boolean {
        return key == PreferenceManager.KEY_CONTACT_GROUPS ||
                key == PreferenceManager.KEY_HIDDEN_CONTACT_GROUPS
    }

    fun isLiquidGlassKey(key: String): Boolean {
        return key == PreferenceManager.KEY_LIQUID_GLASS ||
                key == PreferenceManager.KEY_BLUR_EFFECTS ||
                key.startsWith("lg_") ||
                key.startsWith("blur_") ||
                key.endsWith("_blur") ||
                key.endsWith("_refraction_h") ||
                key.endsWith("_refraction_a") ||
                key.endsWith("_chromatic") ||
                key.endsWith("_depth") ||
                key.endsWith("_saturation") ||
                key.endsWith("_brightness") ||
                key.endsWith("_blur_radius") ||
                key.endsWith("_blur_sat")
    }

    fun filterLiquidGlassPrefs(prefs: SharedPreferences): Map<String, Any> {
        val result = mutableMapOf<String, Any>()
        prefs.all.forEach { (key, value) ->
            if (value != null && isLiquidGlassKey(key)) {
                result[key] = value
            }
        }
        return result
    }

    fun writeBackup(
        context: Context,
        outputStream: OutputStream,
        backupSettings: Boolean = true,
        backupCallingCards: Boolean = true,
        backupNotes: Boolean = true,
        backupContactGroups: Boolean = false,
        backupRecordings: Boolean = true,
        backupContacts: Boolean = false,
        backupCallLogs: Boolean = false,
        backupSms: Boolean = false,
        backupLiquidGlass: Boolean = true
    ): Boolean {
        return try {
            ZipOutputStream(outputStream).use { zip ->
                val backedUpFiles = mutableSetOf<String>()

                if (backupSettings) {
                    val prefsToBackup = KNOWN_PREFS.toMutableSet()
                    try {
                        val sharedPrefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
                        if (sharedPrefsDir.exists() && sharedPrefsDir.isDirectory) {
                            sharedPrefsDir.listFiles()?.filter { it.extension == "xml" }?.forEach { file ->
                                prefsToBackup.add(file.nameWithoutExtension)
                            }
                        }
                    } catch (_: Exception) {}

                    // 1. Backup SharedPreferences files
                    prefsToBackup.forEach { prefName ->
                        val prefs = context.getSharedPreferences(prefName, Context.MODE_PRIVATE)
                        if (prefs.all.isNotEmpty() || prefName == PREFS_RIVO) {
                            val prefsJson = if (prefName == PREFS_RIVO) {
                                prefsToJsonFiltered(prefs) { key ->
                                    val groupOk = backupContactGroups || !isContactGroupKey(key)
                                    val lgOk = backupLiquidGlass || !isLiquidGlassKey(key)
                                    groupOk && lgOk
                                }
                            } else {
                                prefsToJson(prefs)
                            }
                            zip.putNextEntry(ZipEntry("prefs/$prefName.json"))
                            zip.write(prefsJson.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()

                            // Backward compatibility with legacy restores expecting prefs.json at zip root
                            if (prefName == PREFS_RIVO) {
                                zip.putNextEntry(ZipEntry("prefs.json"))
                                zip.write(prefsJson.toByteArray(Charsets.UTF_8))
                                zip.closeEntry()
                            }
                        }
                    }

                    // Also backup standalone liquid_glass.json
                    if (backupLiquidGlass) {
                        val rivoPrefs = context.getSharedPreferences(PREFS_RIVO, Context.MODE_PRIVATE)
                        val lgPrefs = filterLiquidGlassPrefs(rivoPrefs)
                        if (lgPrefs.isNotEmpty()) {
                            val lgJson = mapToJson(lgPrefs)
                            zip.putNextEntry(ZipEntry("prefs/liquid_glass.json"))
                            zip.write(lgJson.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    }

                    // 2. Backup Network Switch DataStore preferences
                    try {
                        val datastoreDir = File(context.filesDir, "datastore")
                        if (datastoreDir.exists() && datastoreDir.isDirectory) {
                            datastoreDir.listFiles()?.forEach { dsFile ->
                                if (dsFile.isFile) {
                                    zip.putNextEntry(ZipEntry("datastore/${dsFile.name}"))
                                    FileInputStream(dsFile).use { it.copyTo(zip) }
                                    zip.closeEntry()
                                }
                            }
                        }
                    } catch (_: Exception) {}

                    // 3. Backup custom font if set
                    try {
                        val fontFile = File(context.filesDir, "custom_font.ttf")
                        if (fontFile.exists() && fontFile.isFile && fontFile.length() > 0) {
                            zip.putNextEntry(ZipEntry("custom_font.ttf"))
                            FileInputStream(fontFile).use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                    } catch (_: Exception) {}
                } else {
                    if (backupLiquidGlass) {
                        val rivoPrefs = context.getSharedPreferences(PREFS_RIVO, Context.MODE_PRIVATE)
                        val lgPrefs = filterLiquidGlassPrefs(rivoPrefs)
                        if (lgPrefs.isNotEmpty()) {
                            val lgJson = mapToJson(lgPrefs)
                            zip.putNextEntry(ZipEntry("prefs/liquid_glass.json"))
                            zip.write(lgJson.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    }
                    if (backupCallingCards) {
                        val rivoPrefs = context.getSharedPreferences(PREFS_RIVO, Context.MODE_PRIVATE)
                        val callingCardPrefs = filterCallingCardPrefs(rivoPrefs)
                        if (callingCardPrefs.isNotEmpty()) {
                            val prefsJson = mapToJson(callingCardPrefs)
                            zip.putNextEntry(ZipEntry("prefs/$PREFS_RIVO.json"))
                            zip.write(prefsJson.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    }
                }

                // 4. Backup Calling Cards Media (Backgrounds: images, videos, wallpapers, contact media GIFs & videos)
                if (backupSettings || backupCallingCards) {
                    val bgDir = getBackgroundsDir(context)
                    bgDir.listFiles()?.forEach { bgFile ->
                        if (bgFile.isFile && !backedUpFiles.contains(bgFile.name)) {
                            zip.putNextEntry(ZipEntry("backgrounds/${bgFile.name}"))
                            FileInputStream(bgFile).use { it.copyTo(zip) }
                            zip.closeEntry()
                            backedUpFiles.add(bgFile.name)
                        }
                    }

                    // Backup custom contact background videos (ExoPlayer) & GIFs (Coil)
                    val contactMediaDir = getContactMediaDir(context)
                    contactMediaDir.listFiles()?.forEach { mediaFile ->
                        if (mediaFile.isFile && !backedUpFiles.contains(mediaFile.name)) {
                            zip.putNextEntry(ZipEntry("contact_media/${mediaFile.name}"))
                            FileInputStream(mediaFile).use { it.copyTo(zip) }
                            zip.closeEntry()
                            backedUpFiles.add(mediaFile.name)
                        }
                    }

                    val contactGifsDir = getContactGifsDir(context)
                    contactGifsDir.listFiles()?.forEach { gifFile ->
                        if (gifFile.isFile && !backedUpFiles.contains(gifFile.name)) {
                            zip.putNextEntry(ZipEntry("contact_gifs/${gifFile.name}"))
                            FileInputStream(gifFile).use { it.copyTo(zip) }
                            zip.closeEntry()
                            backedUpFiles.add(gifFile.name)
                        }
                    }

                    // Check any referenced files in SharedPreferences that might reside elsewhere
                    val rivoPrefs = context.getSharedPreferences(PREFS_RIVO, Context.MODE_PRIVATE)
                    rivoPrefs.all.forEach { (key, value) ->
                        val isMediaKey = key.endsWith("_bg_path") ||
                                key.endsWith("_custom_pfp_path") ||
                                key.endsWith("_pfp_path") ||
                                key.endsWith("_media_bg") ||
                                key.endsWith("_gif_bg") ||
                                key == PreferenceManager.KEY_INCOMING_CUSTOM_PFP_PATH ||
                                key == PreferenceManager.KEY_ONGOING_CUSTOM_PFP_PATH
                        if (isMediaKey && value is String && value.isNotBlank()) {
                            val f = File(value)
                            if (f.exists() && f.isFile && !backedUpFiles.contains(f.name)) {
                                val entryPrefix = if (key.endsWith("_media_bg") || key.endsWith("_gif_bg")) "contact_media" else "backgrounds"
                                zip.putNextEntry(ZipEntry("$entryPrefix/${f.name}"))
                                FileInputStream(f).use { it.copyTo(zip) }
                                zip.closeEntry()
                                backedUpFiles.add(f.name)
                            }
                        }
                    }
                }

                // 4.5. Backup hidden contact photos
                if (backupSettings || backupContacts) {
                    try {
                        context.filesDir.listFiles()?.forEach { file ->
                            if (file.isFile && file.name.startsWith("hidden_contact_") && file.name.endsWith(".jpg")) {
                                zip.putNextEntry(ZipEntry("hidden_contacts/${file.name}"))
                                FileInputStream(file).use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                        }
                    } catch (_: Exception) {}
                }

                // 5. Backup notes (contact notes & general notes)
                if (backupNotes || backupCallingCards) {
                    val notesDir = NoteManager.getNotesDir(context)
                    notesDir.listFiles()?.filter { it.extension == "txt" }?.forEach { noteFile ->
                        zip.putNextEntry(ZipEntry("notes/${noteFile.name}"))
                        FileInputStream(noteFile).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }

                // 5.5. Backup contact groups (names, accounts, memberships, hidden state, and display order)
                if (backupContactGroups) {
                    try {
                        val prefs = PreferenceManager(context)
                        val groups = prefs.getContactGroups()
                        val hiddenGroups = prefs.getHiddenContactGroupIds()
                        val displayOrder = prefs.getContactsDisplayOrder().filter { it.startsWith("group_") }

                        if (groups.isNotEmpty() || hiddenGroups.isNotEmpty() || displayOrder.isNotEmpty()) {
                            val rootObj = JSONObject()
                            val groupsArr = JSONArray()
                            for (g in groups) {
                                val obj = JSONObject()
                                obj.put("id", g.id)
                                obj.put("name", g.name)
                                if (g.accountType != null) obj.put("accountType", g.accountType)
                                if (g.accountName != null) obj.put("accountName", g.accountName)
                                if (g.targetLabel != null) obj.put("targetLabel", g.targetLabel)
                                val contactsArr = JSONArray()
                                g.contactIds.forEach { contactsArr.put(it) }
                                obj.put("contactIds", contactsArr)
                                groupsArr.put(obj)
                            }
                            rootObj.put("groups", groupsArr)

                            val hiddenArr = JSONArray()
                            hiddenGroups.forEach { hiddenArr.put(it) }
                            rootObj.put("hiddenGroups", hiddenArr)

                            val orderArr = JSONArray()
                            displayOrder.forEach { orderArr.put(it) }
                            rootObj.put("displayOrder", orderArr)

                            zip.putNextEntry(ZipEntry("contact_groups.json"))
                            zip.write(rootObj.toString().toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    } catch (_: Exception) {}
                }

                // Backup alternate numbers
                try {
                    val altArray = AlternateNumberRepository.exportToJsonArray(context)
                    if (altArray.length() > 0) {
                        zip.putNextEntry(ZipEntry("alternate_numbers.json"))
                        zip.write(altArray.toString().toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                } catch (_: Exception) {}

                // 6. Backup call recordings & their metadata (favourites & notes)
                if (backupRecordings) {
                    val backedUpRecordingNames = mutableSetOf<String>()
                    val recordingsMetaArray = JSONArray()

                    val favPrefs = context.getSharedPreferences(PREFS_RECORDER_FAV, Context.MODE_PRIVATE)
                    val notesPrefs = context.getSharedPreferences(PREFS_RECORDER_NOTES, Context.MODE_PRIVATE)

                    // Helper to copy recording and record metadata
                    fun archiveRecording(name: String, openInput: () -> java.io.InputStream, uriString: String?) {
                        if (!backedUpRecordingNames.add(name)) return
                        zip.putNextEntry(ZipEntry("recordings/$name"))
                        openInput().use { it.copyTo(zip) }
                        zip.closeEntry()

                        val isFav = if (uriString != null) favPrefs.getBoolean(uriString, false) else false
                        val note = if (uriString != null) notesPrefs.getString(uriString, "") ?: "" else ""
                        if (isFav || note.isNotBlank()) {
                            val item = JSONObject()
                            item.put("fileName", name)
                            item.put("isFavourite", isFav)
                            item.put("noteText", note)
                            recordingsMetaArray.put(item)
                        }
                    }

                    if (AppFeatures.isCallRecorderAvailable) {
                        // A) App private storage recordings
                        val privateDir = AppFeatures.getPrivateStorageDir(context)
                        val authority = AppFeatures.getPrivateStorageAuthority(context)
                        privateDir.listFiles()?.filter { it.isFile }?.forEach { file ->
                            val uriStr = try {
                                androidx.core.content.FileProvider.getUriForFile(context, authority, file).toString()
                            } catch (_: Exception) { null }
                            archiveRecording(file.name, { FileInputStream(file) }, uriStr)
                        }

                        // B) SAF folder recordings if configured
                        val folderUri = AppFeatures.getRecordingFolderUri(context)
                        if (folderUri != null) {
                            try {
                                val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, folderUri)
                                dir?.listFiles()?.filter { it.isFile && it.name != null }?.forEach { docFile ->
                                    val fileName = docFile.name!!
                                    val uriStr = docFile.uri.toString()
                                    archiveRecording(fileName, { context.contentResolver.openInputStream(docFile.uri) ?: throw java.io.FileNotFoundException() }, uriStr)
                                }
                            } catch (_: Exception) {}
                        }
                    }

                    // Write recordings_meta.json
                    if (recordingsMetaArray.length() > 0) {
                        zip.putNextEntry(ZipEntry("recordings/recordings_meta.json"))
                        zip.write(recordingsMetaArray.toString().toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                }

                // 7. Backup contacts (if enabled)
                if (backupContacts) {
                    try {
                        val contactsRepo = GlobalContext.get().getOrNull<IContactsRepository>()
                            ?: ContactsRepository(context.contentResolver, context)
                        val contactsList = contactsRepo.getContacts()
                        if (contactsList.isNotEmpty()) {
                            val jsonArray = JSONArray()
                            contactsList.forEach { c ->
                                val obj = JSONObject()
                                obj.put("name", c.name)
                                obj.put("isFavorite", c.isFavorite)
                                val phoneArr = JSONArray()
                                c.phoneNumbers.forEach { phoneArr.put(it) }
                                obj.put("phoneNumbers", phoneArr)
                                val emailArr = JSONArray()
                                c.emails.forEach { emailArr.put(it) }
                                obj.put("emails", emailArr)
                                val addrArr = JSONArray()
                                c.addresses.forEach { addrArr.put(it) }
                                obj.put("addresses", addrArr)
                                jsonArray.put(obj)
                            }
                            zip.putNextEntry(ZipEntry("contacts/contacts.json"))
                            zip.write(jsonArray.toString().toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("BackupManager", "Failed to backup contacts", e)
                    }
                }

                if (backupCallLogs) {
                    try {
                        val cursor = context.contentResolver.query(
                            android.provider.CallLog.Calls.CONTENT_URI,
                            arrayOf(
                                android.provider.CallLog.Calls.NUMBER,
                                android.provider.CallLog.Calls.CACHED_NAME,
                                android.provider.CallLog.Calls.TYPE,
                                android.provider.CallLog.Calls.DATE,
                                android.provider.CallLog.Calls.DURATION,
                                android.provider.CallLog.Calls.PHONE_ACCOUNT_ID,
                                android.provider.CallLog.Calls.IS_READ,
                                android.provider.CallLog.Calls.NEW
                            ),
                            null,
                            null,
                            "${android.provider.CallLog.Calls.DATE} DESC"
                        )
                        cursor?.use { c ->
                            val numIdx = c.getColumnIndex(android.provider.CallLog.Calls.NUMBER)
                            val nameIdx = c.getColumnIndex(android.provider.CallLog.Calls.CACHED_NAME)
                            val typeIdx = c.getColumnIndex(android.provider.CallLog.Calls.TYPE)
                            val dateIdx = c.getColumnIndex(android.provider.CallLog.Calls.DATE)
                            val durIdx = c.getColumnIndex(android.provider.CallLog.Calls.DURATION)
                            val accIdx = c.getColumnIndex(android.provider.CallLog.Calls.PHONE_ACCOUNT_ID)
                            val isReadIdx = c.getColumnIndex(android.provider.CallLog.Calls.IS_READ)
                            val newIdx = c.getColumnIndex(android.provider.CallLog.Calls.NEW)

                            val jsonArray = JSONArray()
                            while (c.moveToNext()) {
                                val obj = JSONObject()
                                if (numIdx >= 0) obj.put("number", c.getString(numIdx) ?: "")
                                if (nameIdx >= 0 && !c.isNull(nameIdx)) obj.put("cachedName", c.getString(nameIdx))
                                if (typeIdx >= 0) obj.put("type", c.getInt(typeIdx))
                                if (dateIdx >= 0) obj.put("date", c.getLong(dateIdx))
                                if (durIdx >= 0) obj.put("duration", c.getLong(durIdx))
                                if (accIdx >= 0 && !c.isNull(accIdx)) obj.put("phoneAccountId", c.getString(accIdx))
                                if (isReadIdx >= 0) obj.put("isRead", c.getInt(isReadIdx))
                                if (newIdx >= 0) obj.put("isNew", c.getInt(newIdx))
                                jsonArray.put(obj)
                            }
                            if (jsonArray.length() > 0) {
                                zip.putNextEntry(ZipEntry("call_logs/call_logs.json"))
                                zip.write(jsonArray.toString().toByteArray(Charsets.UTF_8))
                                zip.closeEntry()
                            }
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("BackupManager", "Failed to backup call logs", e)
                    }
                }

                if (backupSms) {
                    try {
                        val cursor = context.contentResolver.query(
                            android.provider.Telephony.Sms.CONTENT_URI,
                            arrayOf(
                                android.provider.Telephony.Sms.ADDRESS,
                                android.provider.Telephony.Sms.BODY,
                                android.provider.Telephony.Sms.DATE,
                                android.provider.Telephony.Sms.TYPE,
                                android.provider.Telephony.Sms.READ,
                                android.provider.Telephony.Sms.STATUS,
                                android.provider.Telephony.Sms.THREAD_ID
                            ),
                            null,
                            null,
                            "${android.provider.Telephony.Sms.DATE} DESC"
                        )
                        cursor?.use { c ->
                            val addrIdx = c.getColumnIndex(android.provider.Telephony.Sms.ADDRESS)
                            val bodyIdx = c.getColumnIndex(android.provider.Telephony.Sms.BODY)
                            val dateIdx = c.getColumnIndex(android.provider.Telephony.Sms.DATE)
                            val typeIdx = c.getColumnIndex(android.provider.Telephony.Sms.TYPE)
                            val readIdx = c.getColumnIndex(android.provider.Telephony.Sms.READ)
                            val statusIdx = c.getColumnIndex(android.provider.Telephony.Sms.STATUS)
                            val threadIdx = c.getColumnIndex(android.provider.Telephony.Sms.THREAD_ID)

                            val jsonArray = JSONArray()
                            while (c.moveToNext()) {
                                val obj = JSONObject()
                                if (addrIdx >= 0 && !c.isNull(addrIdx)) obj.put("address", c.getString(addrIdx))
                                if (bodyIdx >= 0 && !c.isNull(bodyIdx)) obj.put("body", c.getString(bodyIdx))
                                if (dateIdx >= 0) obj.put("date", c.getLong(dateIdx))
                                if (typeIdx >= 0) obj.put("type", c.getInt(typeIdx))
                                if (readIdx >= 0) obj.put("read", c.getInt(readIdx))
                                if (statusIdx >= 0) obj.put("status", c.getInt(statusIdx))
                                if (threadIdx >= 0) obj.put("thread_id", c.getLong(threadIdx))
                                jsonArray.put(obj)
                            }
                            if (jsonArray.length() > 0) {
                                zip.putNextEntry(ZipEntry("sms/sms_messages.json"))
                                zip.write(jsonArray.toString().toByteArray(Charsets.UTF_8))
                                zip.closeEntry()
                            }
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("BackupManager", "Failed to backup SMS", e)
                    }
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun createBackup(
        context: Context,
        backupSettings: Boolean = true,
        backupCallingCards: Boolean = true,
        backupNotes: Boolean = true,
        backupContactGroups: Boolean = false,
        backupRecordings: Boolean = true,
        backupContacts: Boolean = false,
        backupCallLogs: Boolean = false,
        backupSms: Boolean = false,
        backupLiquidGlass: Boolean = true
    ): File? {
        return try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val backupFile = File(getBackupDir(context), "EverDialer_Backup_$timestamp.everdialer")
            val ok = FileOutputStream(backupFile).use { outputStream ->
                writeBackup(context, outputStream, backupSettings, backupCallingCards, backupNotes, backupContactGroups, backupRecordings, backupContacts, backupCallLogs, backupSms, backupLiquidGlass)
            }
            if (ok) backupFile else null
        } catch (_: Exception) {
            null
        }
    }

    fun inspectBackup(backupFile: File): BackupContents {
        var hasSettings = false
        var hasCallingCards = false
        var hasNotes = false
        var hasContactGroups = false
        var hasRecordings = false
        var hasContacts = false
        var hasCallLogs = false
        var hasSms = false
        var hasLiquidGlass = false
        var hasAlternateNumbers = false

        try {
            ZipInputStream(FileInputStream(backupFile)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    when {
                        name == "prefs/liquid_glass.json" -> {
                            hasLiquidGlass = true
                        }
                        name.startsWith("prefs/") && name.endsWith(".json") -> {
                            val prefName = name.removePrefix("prefs/").removeSuffix(".json")
                            if (prefName == PREFS_RIVO) {
                                hasSettings = true
                                val jsonStr = zip.readBytes().toString(Charsets.UTF_8)
                                val jsonObj = runCatching {
                                    val r = JSONObject(jsonStr)
                                    if (r.has("data")) r.getJSONObject("data") else r
                                }.getOrNull()
                                jsonObj?.keys()?.forEach { k ->
                                    if (isCallingCardKey(k)) hasCallingCards = true
                                    if (isContactGroupKey(k)) hasContactGroups = true
                                    if (isLiquidGlassKey(k)) hasLiquidGlass = true
                                }
                            } else {
                                hasSettings = true
                            }
                        }
                        name == "prefs.json" -> {
                            hasSettings = true
                            val jsonStr = zip.readBytes().toString(Charsets.UTF_8)
                            val jsonObj = runCatching {
                                val r = JSONObject(jsonStr)
                                if (r.has("data")) r.getJSONObject("data") else r
                            }.getOrNull()
                            jsonObj?.keys()?.forEach { k ->
                                if (isCallingCardKey(k)) hasCallingCards = true
                                if (isContactGroupKey(k)) hasContactGroups = true
                                if (isLiquidGlassKey(k)) hasLiquidGlass = true
                            }
                        }
                        name.startsWith("datastore/") || name == "custom_font.ttf" -> {
                            hasSettings = true
                        }
                        name.startsWith("backgrounds/") ||
                        name.startsWith("contact_media/") ||
                        name.startsWith("contact_gifs/") -> {
                            hasCallingCards = true
                        }
                        name.startsWith("notes/") -> {
                            hasNotes = true
                        }
                        name == "contact_groups.json" -> {
                            hasContactGroups = true
                        }
                        name == "alternate_numbers.json" -> {
                            hasAlternateNumbers = true
                        }
                        name.startsWith("recordings/") && !name.endsWith("/") -> {
                            hasRecordings = true
                        }
                        name.startsWith("contacts/") && !name.endsWith("/") -> {
                            hasContacts = true
                        }
                        name.startsWith("call_logs/") && !name.endsWith("/") -> {
                            hasCallLogs = true
                        }
                        name.startsWith("sms/") && !name.endsWith("/") -> {
                            hasSms = true
                        }
                        name.startsWith("hidden_contacts/") -> {
                            hasSettings = true
                            hasContacts = true
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } catch (_: Exception) {}

        return BackupContents(
            hasSettings = hasSettings,
            hasCallingCards = hasCallingCards,
            hasNotes = hasNotes,
            hasContactGroups = hasContactGroups,
            hasRecordings = hasRecordings,
            hasContacts = hasContacts,
            hasCallLogs = hasCallLogs,
            hasSms = hasSms,
            hasLiquidGlass = hasLiquidGlass,
            hasAlternateNumbers = hasAlternateNumbers
        )
    }

    fun restoreBackup(
        context: Context,
        backupFile: File,
        restoreSettings: Boolean = true,
        restoreCallingCards: Boolean = true,
        restoreNotes: Boolean = true,
        restoreContactGroups: Boolean = true,
        restoreRecordings: Boolean = true,
        restoreContacts: Boolean = true,
        restoreCallLogs: Boolean = true,
        restoreSms: Boolean = true,
        restoreLiquidGlass: Boolean = true
    ): Boolean {
        return try {
            var restoredAny = false
            var restoredRivoFromPrefsDir = false
            var recordingsRestoredCount = 0
            var restoredMetaJson: String? = null

            val privateRecDir = AppFeatures.getPrivateStorageDir(context)

            ZipInputStream(FileInputStream(backupFile)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    when {
                        name == "prefs/liquid_glass.json" -> {
                            val json = zip.readBytes().toString(Charsets.UTF_8)
                            if (restoreLiquidGlass || restoreSettings) {
                                restorePrefs(context, PREFS_RIVO, json, onlyCallingCardKeys = false, restoreContactGroups = false, restoreLiquidGlass = true, onlyLiquidGlassKeys = true)
                                restoredAny = true
                            }
                        }
                        name.startsWith("prefs/") && name.endsWith(".json") -> {
                            val prefName = name.removePrefix("prefs/").removeSuffix(".json")
                            val json = zip.readBytes().toString(Charsets.UTF_8)
                            if (restoreSettings) {
                                restorePrefs(context, prefName, json, onlyCallingCardKeys = false, restoreContactGroups = restoreContactGroups, restoreLiquidGlass = restoreLiquidGlass)
                                if (prefName == PREFS_RIVO) {
                                    restoredRivoFromPrefsDir = true
                                }
                                restoredAny = true
                            } else if (restoreLiquidGlass && prefName == PREFS_RIVO) {
                                restorePrefs(context, prefName, json, onlyCallingCardKeys = false, restoreContactGroups = false, restoreLiquidGlass = true, onlyLiquidGlassKeys = true)
                                restoredRivoFromPrefsDir = true
                                restoredAny = true
                            } else if (restoreCallingCards && prefName == PREFS_RIVO) {
                                restorePrefs(context, prefName, json, onlyCallingCardKeys = true, restoreContactGroups = false, restoreLiquidGlass = false)
                                restoredRivoFromPrefsDir = true
                                restoredAny = true
                            }
                        }
                        name == "prefs.json" -> {
                            val json = zip.readBytes().toString(Charsets.UTF_8)
                            if (!restoredRivoFromPrefsDir) {
                                if (restoreSettings) {
                                    restorePrefs(context, PREFS_RIVO, json, onlyCallingCardKeys = false, restoreContactGroups = restoreContactGroups, restoreLiquidGlass = restoreLiquidGlass)
                                    restoredAny = true
                                } else if (restoreLiquidGlass) {
                                    restorePrefs(context, PREFS_RIVO, json, onlyCallingCardKeys = false, restoreContactGroups = false, restoreLiquidGlass = true, onlyLiquidGlassKeys = true)
                                    restoredAny = true
                                } else if (restoreCallingCards) {
                                    restorePrefs(context, PREFS_RIVO, json, onlyCallingCardKeys = true, restoreContactGroups = false, restoreLiquidGlass = false)
                                    restoredAny = true
                                }
                            }
                        }
                        name.startsWith("datastore/") -> {
                            if (restoreSettings) {
                                val relativePath = name.removePrefix("datastore/")
                                if (relativePath.isNotEmpty()) {
                                    val dsFile = File(File(context.filesDir, "datastore"), relativePath)
                                    dsFile.parentFile?.mkdirs()
                                    FileOutputStream(dsFile).use { zip.copyTo(it) }
                                    restoredAny = true
                                }
                            }
                        }
                        name == "custom_font.ttf" -> {
                            if (restoreSettings) {
                                val fontFile = File(context.filesDir, "custom_font.ttf")
                                FileOutputStream(fontFile).use { zip.copyTo(it) }
                                val rivoPrefs = context.getSharedPreferences(PREFS_RIVO, Context.MODE_PRIVATE)
                                rivoPrefs.edit().putString(PreferenceManager.KEY_CUSTOM_FONT_PATH, fontFile.absolutePath).apply()
                                restoredAny = true
                            }
                        }
                        name.startsWith("backgrounds/") -> {
                            if (restoreCallingCards || restoreSettings) {
                                val fileName = name.removePrefix("backgrounds/")
                                if (fileName.isNotEmpty()) {
                                    val bgDir = getBackgroundsDir(context)
                                    val bgFile = File(bgDir, fileName)
                                    bgFile.parentFile?.mkdirs()
                                    FileOutputStream(bgFile).use { zip.copyTo(it) }
                                    restoredAny = true
                                }
                            }
                        }
                        name.startsWith("contact_media/") -> {
                            if (restoreCallingCards || restoreSettings) {
                                val fileName = name.removePrefix("contact_media/")
                                if (fileName.isNotEmpty()) {
                                    val mediaDir = getContactMediaDir(context)
                                    val mediaFile = File(mediaDir, fileName)
                                    mediaFile.parentFile?.mkdirs()
                                    FileOutputStream(mediaFile).use { zip.copyTo(it) }
                                    restoredAny = true
                                }
                            }
                        }
                        name.startsWith("contact_gifs/") -> {
                            if (restoreCallingCards || restoreSettings) {
                                val fileName = name.removePrefix("contact_gifs/")
                                if (fileName.isNotEmpty()) {
                                    val mediaDir = getContactMediaDir(context)
                                    val gifsDir = getContactGifsDir(context)
                                    val mediaFile = File(mediaDir, fileName)
                                    val gifFile = File(gifsDir, fileName)
                                    mediaFile.parentFile?.mkdirs()
                                    gifsDir.mkdirs()
                                    FileOutputStream(mediaFile).use { fos ->
                                        zip.copyTo(fos)
                                    }
                                    try { mediaFile.copyTo(gifFile, overwrite = true) } catch (_: Exception) {}
                                    restoredAny = true
                                }
                            }
                        }
                        name.startsWith("hidden_contacts/") -> {
                            if (restoreSettings || restoreContacts) {
                                val fileName = name.removePrefix("hidden_contacts/")
                                if (fileName.isNotEmpty()) {
                                    val photoFile = File(context.filesDir, fileName)
                                    photoFile.parentFile?.mkdirs()
                                    FileOutputStream(photoFile).use { zip.copyTo(it) }
                                    restoredAny = true
                                }
                            }
                        }
                        name.startsWith("notes/") -> {
                            if (restoreNotes || restoreCallingCards) {
                                val fileName = name.removePrefix("notes/")
                                if (fileName.isNotEmpty()) {
                                    val noteFile = File(NoteManager.getNotesDir(context), fileName)
                                    noteFile.parentFile?.mkdirs()
                                    FileOutputStream(noteFile).use { zip.copyTo(it) }
                                    restoredAny = true
                                }
                            }
                        }
                        name == "contact_groups.json" -> {
                            if (restoreContactGroups) {
                                try {
                                    val json = zip.readBytes().toString(Charsets.UTF_8)
                                    val list = mutableListOf<com.modiprincekr.thedialer.modal.data.ContactGroup>()
                                    val restoredHiddenGroups = mutableSetOf<String>()
                                    val restoredOrder = mutableListOf<String>()

                                    fun parseGroupObj(obj: JSONObject): com.modiprincekr.thedialer.modal.data.ContactGroup? {
                                        val id = obj.optString("id", java.util.UUID.randomUUID().toString())
                                        val gName = obj.optString("name", "")
                                        val accountType = if (obj.has("accountType")) obj.optString("accountType").ifBlank { null } else null
                                        val accountName = if (obj.has("accountName")) obj.optString("accountName").ifBlank { null } else null
                                        val targetLabel = if (obj.has("targetLabel")) obj.optString("targetLabel").ifBlank { null } else null
                                        val contactIds = mutableListOf<String>()
                                        val arr = obj.optJSONArray("contactIds")
                                        if (arr != null) {
                                            for (j in 0 until arr.length()) {
                                                contactIds.add(arr.getString(j))
                                            }
                                        }
                                        return if (gName.isNotBlank()) {
                                            com.modiprincekr.thedialer.modal.data.ContactGroup(
                                                id = id,
                                                name = gName,
                                                contactIds = contactIds,
                                                accountType = accountType,
                                                accountName = accountName,
                                                targetLabel = targetLabel
                                            )
                                        } else null
                                    }

                                    val trimmed = json.trim()
                                    if (trimmed.startsWith("[")) {
                                        val jsonArray = JSONArray(trimmed)
                                        for (i in 0 until jsonArray.length()) {
                                            parseGroupObj(jsonArray.getJSONObject(i))?.let { list.add(it) }
                                        }
                                    } else {
                                        val root = JSONObject(trimmed)
                                        val groupsArr = root.optJSONArray("groups")
                                        if (groupsArr != null) {
                                            for (i in 0 until groupsArr.length()) {
                                                parseGroupObj(groupsArr.getJSONObject(i))?.let { list.add(it) }
                                            }
                                        }
                                        val hiddenArr = root.optJSONArray("hiddenGroups")
                                        if (hiddenArr != null) {
                                            for (i in 0 until hiddenArr.length()) {
                                                restoredHiddenGroups.add(hiddenArr.getString(i))
                                            }
                                        }
                                        val orderArr = root.optJSONArray("displayOrder")
                                        if (orderArr != null) {
                                            for (i in 0 until orderArr.length()) {
                                                restoredOrder.add(orderArr.getString(i))
                                            }
                                        }
                                    }

                                    val contactsRepo = GlobalContext.get().getOrNull<IContactsRepository>()
                                        ?: ContactsRepository(context.contentResolver, context)

                                    // Resolve system group IDs on this device so groups aren't wiped as stale/deleted
                                    val resolvedList = mutableListOf<com.modiprincekr.thedialer.modal.data.ContactGroup>()
                                    for (g in list) {
                                        var targetGroup = g
                                        if (!g.accountType.isNullOrBlank() || !g.accountName.isNullOrBlank() || g.id.startsWith("sys_group_")) {
                                            val existingSysId = runCatching {
                                                contactsRepo.findSystemGroupId(g.name, g.accountType, g.accountName)
                                            }.getOrNull()

                                            if (existingSysId != null) {
                                                targetGroup = g.copy(id = "sys_group_$existingSysId")
                                            } else {
                                                val savedSysId = runCatching { contactsRepo.saveSystemContactGroup(g) }.getOrNull()
                                                if (savedSysId != null) {
                                                    targetGroup = g.copy(id = savedSysId)
                                                } else if (g.id.startsWith("sys_group_")) {
                                                    // Fallback to local UUID so it won't be deleted by ContactsViewModel check
                                                    targetGroup = g.copy(id = java.util.UUID.randomUUID().toString())
                                                }
                                            }
                                        }
                                        resolvedList.add(targetGroup)
                                    }

                                    val prefs = PreferenceManager(context)
                                    prefs.saveContactGroups(resolvedList)

                                    // Restore hidden groups state
                                    if (restoredHiddenGroups.isNotEmpty()) {
                                        val currentHidden = prefs.getHiddenContactGroupIds().toMutableSet()
                                        currentHidden.addAll(restoredHiddenGroups)
                                        prefs.setString(PreferenceManager.KEY_HIDDEN_CONTACT_GROUPS, currentHidden.joinToString(","))
                                    }

                                    // Update display order so restored groups show up
                                    val currentOrder = prefs.getContactsDisplayOrder().toMutableList()
                                    if (restoredOrder.isNotEmpty()) {
                                        for (key in restoredOrder) {
                                            if (key !in currentOrder) currentOrder.add(key)
                                        }
                                    }
                                    for (rg in resolvedList) {
                                        val gKey = "group_${rg.id}"
                                        if (gKey !in currentOrder) {
                                            currentOrder.add(gKey)
                                        }
                                    }
                                    prefs.setContactsDisplayOrder(currentOrder)

                                    try {
                                        GlobalContext.get().getOrNull<com.modiprincekr.thedialer.controller.ContactsViewModel>()?.fetchContactGroups()
                                    } catch (_: Throwable) {}

                                    restoredAny = true
                                } catch (_: Exception) {}
                            }
                        }
                        name == "alternate_numbers.json" -> {
                            try {
                                val json = zip.readBytes().toString(Charsets.UTF_8)
                                val arr = JSONArray(json)
                                AlternateNumberRepository.importFromJsonArray(context, arr)
                                restoredAny = true
                            } catch (_: Exception) {}
                        }
                        name == "recordings/recordings_meta.json" -> {
                            if (restoreRecordings) {
                                restoredMetaJson = zip.readBytes().toString(Charsets.UTF_8)
                                restoredAny = true
                            }
                        }
                        name.startsWith("recordings/") -> {
                            if (restoreRecordings) {
                                val fileName = name.removePrefix("recordings/")
                                if (fileName.isNotEmpty() && !fileName.endsWith(".json")) {
                                    val recFile = File(privateRecDir, fileName)
                                    recFile.parentFile?.mkdirs()
                                    FileOutputStream(recFile).use { zip.copyTo(it) }
                                    recordingsRestoredCount++
                                    restoredAny = true
                                }
                            }
                        }
                        name == "contacts/contacts.json" -> {
                            if (restoreContacts) {
                                try {
                                    val jsonStr = zip.readBytes().toString(Charsets.UTF_8)
                                    val jsonArray = JSONArray(jsonStr)
                                    val contactsRepo = GlobalContext.get().getOrNull<IContactsRepository>()
                                        ?: ContactsRepository(context.contentResolver, context)
                                    val existingContacts = contactsRepo.getContacts()
                                    for (i in 0 until jsonArray.length()) {
                                        val obj = jsonArray.getJSONObject(i)
                                        val cName = obj.optString("name", "")
                                        val isFavorite = obj.optBoolean("isFavorite", false)
                                        val phoneNumbers = mutableListOf<String>()
                                        val phoneArr = obj.optJSONArray("phoneNumbers")
                                        if (phoneArr != null) {
                                            for (j in 0 until phoneArr.length()) {
                                                phoneNumbers.add(phoneArr.getString(j))
                                            }
                                        }
                                        val emails = mutableListOf<String>()
                                        val emailArr = obj.optJSONArray("emails")
                                        if (emailArr != null) {
                                            for (j in 0 until emailArr.length()) {
                                                emails.add(emailArr.getString(j))
                                            }
                                        }
                                        val addresses = mutableListOf<String>()
                                        val addrArr = obj.optJSONArray("addresses")
                                        if (addrArr != null) {
                                            for (j in 0 until addrArr.length()) {
                                                addresses.add(addrArr.getString(j))
                                            }
                                        }

                                        val alreadyExists = existingContacts.any { ec ->
                                            ec.name.equals(cName, ignoreCase = true) &&
                                            (phoneNumbers.isEmpty() || ec.phoneNumbers.any { ep -> phoneNumbers.any { numbersLikelyMatch(ep, it) } })
                                        }
                                        if (!alreadyExists && (cName.isNotBlank() || phoneNumbers.isNotEmpty())) {
                                            val contactToSave = Contact(
                                                id = "",
                                                name = cName.ifBlank { phoneNumbers.firstOrNull() ?: "Unknown" },
                                                phoneNumbers = phoneNumbers,
                                                emails = emails,
                                                addresses = addresses,
                                                isFavorite = isFavorite
                                            )
                                            contactsRepo.saveContact(contactToSave)
                                        }
                                    }
                                    restoredAny = true
                                } catch (e: Exception) {
                                    android.util.Log.e("BackupManager", "Failed to restore contacts", e)
                                }
                            }
                        }
                        name == "call_logs/call_logs.json" -> {
                            if (restoreCallLogs) {
                                try {
                                    val jsonStr = zip.readBytes().toString(Charsets.UTF_8)
                                    val jsonArray = JSONArray(jsonStr)

                                    val existingKeys = mutableSetOf<String>()
                                    try {
                                        val cursor = context.contentResolver.query(
                                            android.provider.CallLog.Calls.CONTENT_URI,
                                            arrayOf(
                                                android.provider.CallLog.Calls.NUMBER,
                                                android.provider.CallLog.Calls.DATE,
                                                android.provider.CallLog.Calls.TYPE
                                            ),
                                            null,
                                            null,
                                            null
                                        )
                                        cursor?.use { c ->
                                            val numIdx = c.getColumnIndex(android.provider.CallLog.Calls.NUMBER)
                                            val dateIdx = c.getColumnIndex(android.provider.CallLog.Calls.DATE)
                                            val typeIdx = c.getColumnIndex(android.provider.CallLog.Calls.TYPE)
                                            while (c.moveToNext()) {
                                                val num = if (numIdx >= 0) c.getString(numIdx) ?: "" else ""
                                                val date = if (dateIdx >= 0) c.getLong(dateIdx) else 0L
                                                val type = if (typeIdx >= 0) c.getInt(typeIdx) else 0
                                                existingKeys.add("$num|$date|$type")
                                            }
                                        }
                                    } catch (_: Exception) {}

                                    for (i in 0 until jsonArray.length()) {
                                        val obj = jsonArray.getJSONObject(i)
                                        val number = obj.optString("number", "")
                                        val date = obj.optLong("date", 0L)
                                        val type = obj.optInt("type", 1)
                                        val key = "$number|$date|$type"
                                        if (!existingKeys.contains(key)) {
                                            val values = android.content.ContentValues().apply {
                                                put(android.provider.CallLog.Calls.NUMBER, number)
                                                if (obj.has("cachedName")) {
                                                    put(android.provider.CallLog.Calls.CACHED_NAME, obj.getString("cachedName"))
                                                }
                                                put(android.provider.CallLog.Calls.TYPE, type)
                                                put(android.provider.CallLog.Calls.DATE, date)
                                                put(android.provider.CallLog.Calls.DURATION, obj.optLong("duration", 0L))
                                                if (obj.has("phoneAccountId")) {
                                                    put(android.provider.CallLog.Calls.PHONE_ACCOUNT_ID, obj.getString("phoneAccountId"))
                                                }
                                                if (obj.has("isRead")) {
                                                    put(android.provider.CallLog.Calls.IS_READ, obj.getInt("isRead"))
                                                }
                                                if (obj.has("isNew")) {
                                                    put(android.provider.CallLog.Calls.NEW, obj.getInt("isNew"))
                                                }
                                            }
                                            try {
                                                context.contentResolver.insert(android.provider.CallLog.Calls.CONTENT_URI, values)
                                                existingKeys.add(key)
                                            } catch (e: Exception) {
                                                android.util.Log.e("BackupManager", "Failed to insert call log entry", e)
                                            }
                                        }
                                    }
                                    restoredAny = true
                                } catch (e: Exception) {
                                    android.util.Log.e("BackupManager", "Failed to restore call logs", e)
                                }
                            }
                        }
                        name == "sms/sms_messages.json" -> {
                            if (restoreSms) {
                                try {
                                    val jsonStr = zip.readBytes().toString(Charsets.UTF_8)
                                    val jsonArray = JSONArray(jsonStr)

                                    val existingKeys = mutableSetOf<String>()
                                    try {
                                        val cursor = context.contentResolver.query(
                                            android.provider.Telephony.Sms.CONTENT_URI,
                                            arrayOf(
                                                android.provider.Telephony.Sms.ADDRESS,
                                                android.provider.Telephony.Sms.DATE,
                                                android.provider.Telephony.Sms.BODY
                                            ),
                                            null,
                                            null,
                                            null
                                        )
                                        cursor?.use { c ->
                                            val addrIdx = c.getColumnIndex(android.provider.Telephony.Sms.ADDRESS)
                                            val dateIdx = c.getColumnIndex(android.provider.Telephony.Sms.DATE)
                                            val bodyIdx = c.getColumnIndex(android.provider.Telephony.Sms.BODY)
                                            while (c.moveToNext()) {
                                                val addr = if (addrIdx >= 0) c.getString(addrIdx) ?: "" else ""
                                                val date = if (dateIdx >= 0) c.getLong(dateIdx) else 0L
                                                val body = if (bodyIdx >= 0) c.getString(bodyIdx) ?: "" else ""
                                                existingKeys.add("$addr|$date|$body")
                                            }
                                        }
                                    } catch (_: Exception) {}

                                    for (i in 0 until jsonArray.length()) {
                                        val obj = jsonArray.getJSONObject(i)
                                        val addr = obj.optString("address", "")
                                        val body = obj.optString("body", "")
                                        val date = obj.optLong("date", 0L)
                                        val type = obj.optInt("type", android.provider.Telephony.Sms.MESSAGE_TYPE_INBOX)
                                        val read = obj.optInt("read", 1)
                                        val status = obj.optInt("status", -1)
                                        val key = "$addr|$date|$body"

                                        if (!existingKeys.contains(key)) {
                                            val values = android.content.ContentValues().apply {
                                                put(android.provider.Telephony.Sms.ADDRESS, addr)
                                                put(android.provider.Telephony.Sms.BODY, body)
                                                put(android.provider.Telephony.Sms.DATE, date)
                                                put(android.provider.Telephony.Sms.TYPE, type)
                                                put(android.provider.Telephony.Sms.READ, read)
                                                if (status >= 0) {
                                                    put(android.provider.Telephony.Sms.STATUS, status)
                                                }
                                                if (addr.isNotBlank()) {
                                                    try {
                                                        val threadId = android.provider.Telephony.Threads.getOrCreateThreadId(context, addr)
                                                        if (threadId > 0) {
                                                            put(android.provider.Telephony.Sms.THREAD_ID, threadId)
                                                        }
                                                    } catch (_: Throwable) {}
                                                }
                                            }
                                            try {
                                                val targetUri = if (type == android.provider.Telephony.Sms.MESSAGE_TYPE_SENT) {
                                                    android.provider.Telephony.Sms.Sent.CONTENT_URI
                                                } else {
                                                    android.provider.Telephony.Sms.Inbox.CONTENT_URI
                                                }
                                                context.contentResolver.insert(targetUri, values)
                                                existingKeys.add(key)
                                            } catch (e: Exception) {
                                                android.util.Log.e("BackupManager", "Failed to insert SMS message", e)
                                            }
                                        }
                                    }
                                    restoredAny = true
                                } catch (e: Exception) {
                                    android.util.Log.e("BackupManager", "Failed to restore SMS", e)
                                }
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }

            // If recordings were restored and recorder storage mode was unset, set it to PRIVATE so they show immediately
            if (recordingsRestoredCount > 0) {
                AppFeatures.ensurePrivateStorageMode(context)
            }

            // Restore recordings metadata (favourites and notes) re-keyed to current URIs
            if (!restoredMetaJson.isNullOrBlank()) {
                try {
                    val metaArray = JSONArray(restoredMetaJson)
                    val favPrefs = context.getSharedPreferences(PREFS_RECORDER_FAV, Context.MODE_PRIVATE)
                    val notesPrefs = context.getSharedPreferences(PREFS_RECORDER_NOTES, Context.MODE_PRIVATE)
                    val favEditor = favPrefs.edit()
                    val notesEditor = notesPrefs.edit()

                    val authority = AppFeatures.getPrivateStorageAuthority(context)

                    for (i in 0 until metaArray.length()) {
                        val item = metaArray.getJSONObject(i)
                        val fileName = item.optString("fileName", "")
                        val isFav = item.optBoolean("isFavourite", false)
                        val note = item.optString("noteText", "")

                        if (fileName.isNotEmpty()) {
                            val localFile = File(privateRecDir, fileName)
                            if (localFile.exists()) {
                                val uri = androidx.core.content.FileProvider.getUriForFile(context, authority, localFile).toString()
                                if (isFav) favEditor.putBoolean(uri, true)
                                if (note.isNotEmpty()) notesEditor.putString(uri, note)
                            }
                        }
                    }
                    favEditor.apply()
                    notesEditor.apply()
                } catch (_: Exception) {}
            }

            // Fix and validate all background paths after restore so they point to current device directories
            if (restoreCallingCards || restoreSettings) {
                fixBackgroundPathsAfterRestore(context)
            }

            // Sync services and stores after restore
            try {
                com.coolappstore.everdialer.by.svhp.feature.AppFeatures.reloadNetworkSwitchStores(context)
            } catch (_: Throwable) {}

            try {
                com.coolappstore.everdialer.by.svhp.feature.AppFeatures.syncCallRecordingComponentGuard(context)
            } catch (_: Throwable) {}

            try {
                val prefMgr = org.koin.java.KoinJavaComponent.getKoin().getOrNull<PreferenceManager>()
                prefMgr?.notifyChanged()

                if (restoreSettings) {
                    // Re-apply Ever Dialer launcher icon and app name preset
                    val selectedIcon = prefMgr?.getString("selected_app_icon", "default") ?: "default"
                    val appNamePreset = prefMgr?.getString(PreferenceManager.KEY_APP_NAME_PRESET, "default") ?: "default"
                    val dialerAlias = com.modiprincekr.thedialer.view.screen.settings.aliasNameFor(selectedIcon, appNamePreset)
                    com.modiprincekr.thedialer.view.screen.settings.applyLauncherAlias(context, dialerAlias)

                    // Re-apply SMS launcher alias
                    val smsIconEnabled = prefMgr?.getBoolean(PreferenceManager.KEY_SMS_LAUNCHER_ICON_ENABLED, true) ?: true
                    val smsAppName = prefMgr?.getString(PreferenceManager.KEY_SMS_LAUNCHER_APP_NAME, "Ever SMS") ?: "Ever SMS"
                    val smsIcon = prefMgr?.getString(PreferenceManager.KEY_SMS_SELECTED_APP_ICON, "default") ?: "default"
                    com.modiprincekr.thedialer.view.screen.settings.updateSmsLauncherAliasFull(context, smsIconEnabled, smsAppName, smsIcon)
                }
            } catch (_: Throwable) {}

            if (restoreSettings) {
                try {
                    com.modiprincekr.thedialer.widget.RecentCallsWidgetProvider.refresh(context)
                } catch (_: Throwable) {}
                try {
                    val mgr = android.appwidget.AppWidgetManager.getInstance(context)
                    val directComp = android.content.ComponentName(context, com.modiprincekr.thedialer.widget.DirectCallWidgetProvider::class.java)
                    mgr.getAppWidgetIds(directComp)?.forEach { id ->
                        com.modiprincekr.thedialer.widget.DirectCallWidgetProvider.updateWidget(context, mgr, id)
                    }
                    val contactComp = android.content.ComponentName(context, com.modiprincekr.thedialer.widget.ContactInfoWidgetProvider::class.java)
                    mgr.getAppWidgetIds(contactComp)?.forEach { id ->
                        com.modiprincekr.thedialer.widget.ContactInfoWidgetProvider.updateWidget(context, mgr, id)
                    }
                } catch (_: Throwable) {}
            }

            restoredAny
        } catch (_: Exception) {
            false
        }
    }

    private fun filterCallingCardPrefs(prefs: SharedPreferences): Map<String, Any> {
        val result = mutableMapOf<String, Any>()
        prefs.all.forEach { (key, value) ->
            if (value != null && isCallingCardKey(key)) {
                result[key] = value
            }
        }
        return result
    }

    private fun mapToJson(map: Map<String, Any>): String {
        val json = JSONObject()
        val meta = JSONObject()
        map.forEach { (key, value) ->
            when (value) {
                is Boolean -> {
                    json.put(key, value)
                    meta.put(key, "boolean")
                }
                is Int -> {
                    json.put(key, value)
                    meta.put(key, "int")
                }
                is Long -> {
                    json.put(key, value)
                    meta.put(key, "long")
                }
                is Float -> {
                    json.put(key, value.toDouble())
                    meta.put(key, "float")
                }
                is String -> {
                    json.put(key, value)
                    meta.put(key, "string")
                }
                is Set<*> -> {
                    val arr = JSONArray()
                    value.forEach { item -> if (item != null) arr.put(item.toString()) }
                    json.put(key, arr)
                    meta.put(key, "string_set")
                }
            }
        }
        val wrapper = JSONObject()
        wrapper.put("data", json)
        wrapper.put("meta", meta)
        return wrapper.toString()
    }

    private fun prefsToJsonFiltered(prefs: SharedPreferences, predicate: (String) -> Boolean): String {
        val json = JSONObject()
        val meta = JSONObject()
        prefs.all.forEach { (key, value) ->
            if (predicate(key)) {
                when (value) {
                    is Boolean -> {
                        json.put(key, value)
                        meta.put(key, "boolean")
                    }
                    is Int -> {
                        json.put(key, value)
                        meta.put(key, "int")
                    }
                    is Long -> {
                        json.put(key, value)
                        meta.put(key, "long")
                    }
                    is Float -> {
                        json.put(key, value.toDouble())
                        meta.put(key, "float")
                    }
                    is String -> {
                        json.put(key, value)
                        meta.put(key, "string")
                    }
                    is Set<*> -> {
                        val arr = JSONArray()
                        value.forEach { item -> if (item != null) arr.put(item.toString()) }
                        json.put(key, arr)
                        meta.put(key, "string_set")
                    }
                }
            }
        }
        val wrapper = JSONObject()
        wrapper.put("data", json)
        wrapper.put("meta", meta)
        return wrapper.toString()
    }

    private fun prefsToJson(prefs: SharedPreferences): String {
        val json = JSONObject()
        val meta = JSONObject() // store type hints for unambiguous restore
        prefs.all.forEach { (key, value) ->
            when (value) {
                is Boolean -> {
                    json.put(key, value)
                    meta.put(key, "boolean")
                }
                is Int -> {
                    json.put(key, value)
                    meta.put(key, "int")
                }
                is Long -> {
                    json.put(key, value)
                    meta.put(key, "long")
                }
                is Float -> {
                    json.put(key, value.toDouble())
                    meta.put(key, "float")
                }
                is String -> {
                    json.put(key, value)
                    meta.put(key, "string")
                }
                is Set<*> -> {
                    val arr = JSONArray()
                    value.forEach { item -> if (item != null) arr.put(item.toString()) }
                    json.put(key, arr)
                    meta.put(key, "string_set")
                }
            }
        }
        val wrapper = JSONObject()
        wrapper.put("data", json)
        wrapper.put("meta", meta)
        return wrapper.toString()
    }

    private fun restorePrefs(
        context: Context,
        prefName: String,
        json: String,
        onlyCallingCardKeys: Boolean = false,
        restoreContactGroups: Boolean = true,
        restoreLiquidGlass: Boolean = true,
        onlyLiquidGlassKeys: Boolean = false
    ) {
        try {
            val prefs = context.getSharedPreferences(prefName, Context.MODE_PRIVATE)
            val editor = prefs.edit()

            val raw = JSONObject(json)
            val jsonObj = if (raw.has("data")) raw.getJSONObject("data") else raw
            val meta = if (raw.has("meta")) raw.getJSONObject("meta") else JSONObject()

            val bgDir = getBackgroundsDir(context)

            fun remapString(key: String, strValue: String): String {
                val isMediaKey = key.endsWith("_bg_path") ||
                        key.endsWith("_custom_pfp_path") ||
                        key.endsWith("_pfp_path") ||
                        key == PreferenceManager.KEY_INCOMING_CUSTOM_PFP_PATH ||
                        key == PreferenceManager.KEY_ONGOING_CUSTOM_PFP_PATH
                return if (isMediaKey && strValue.isNotBlank()) {
                    val fileName = File(strValue).name
                    val localFile = File(bgDir, fileName)
                    if (localFile.exists()) localFile.absolutePath else strValue
                } else if (key == PreferenceManager.KEY_CUSTOM_FONT_PATH && strValue.isNotBlank()) {
                    val fontFile = File(context.filesDir, "custom_font.ttf")
                    if (fontFile.exists()) fontFile.absolutePath else strValue
                } else {
                    strValue
                }
            }

            jsonObj.keys().forEach { key ->
                if (onlyCallingCardKeys && !isCallingCardKey(key)) {
                    return@forEach
                }
                if (onlyLiquidGlassKeys && !isLiquidGlassKey(key)) {
                    return@forEach
                }
                if (!restoreLiquidGlass && isLiquidGlassKey(key)) {
                    return@forEach
                }
                if (!restoreContactGroups && isContactGroupKey(key)) {
                    return@forEach
                }
                if (!restoreContactGroups && key == PreferenceManager.KEY_CONTACTS_DISPLAY_ORDER) {
                    val incoming = jsonObj.optString(key, "")
                        .split(",").filter { !it.startsWith("group_") && it.isNotBlank() }
                    val currentGroupKeys = prefs.getString(PreferenceManager.KEY_CONTACTS_DISPLAY_ORDER, "")
                        ?.split(",")?.filter { it.startsWith("group_") && it.isNotBlank() } ?: emptyList()
                    val merged = (incoming + currentGroupKeys).distinct()
                    editor.putString(key, merged.joinToString(","))
                    return@forEach
                }
                val typeHint = meta.optString(key, "")
                when (typeHint) {
                    "boolean" -> {
                        editor.putBoolean(key, jsonObj.getBoolean(key))
                    }
                    "int" -> {
                        editor.putInt(key, jsonObj.getInt(key))
                    }
                    "long" -> {
                        editor.putLong(key, jsonObj.getLong(key))
                    }
                    "float" -> {
                        editor.putFloat(key, jsonObj.getDouble(key).toFloat())
                    }
                    "string" -> {
                        val str = jsonObj.optString(key, "")
                        editor.putString(key, remapString(key, str))
                    }
                    "string_set" -> {
                        val arr = jsonObj.optJSONArray(key)
                        if (arr != null) {
                            val set = mutableSetOf<String>()
                            for (i in 0 until arr.length()) {
                                set.add(arr.getString(i))
                            }
                            editor.putStringSet(key, set)
                        }
                    }
                    else -> {
                        // Fallback for legacy backups without full type hints
                        when (val value = jsonObj.get(key)) {
                            is Boolean -> editor.putBoolean(key, value)
                            is Int -> editor.putInt(key, value)
                            is Long -> {
                                if (value in Int.MIN_VALUE..Int.MAX_VALUE) editor.putInt(key, value.toInt())
                                else editor.putLong(key, value)
                            }
                            is Double -> editor.putFloat(key, value.toFloat())
                            is String -> {
                                editor.putString(key, remapString(key, value))
                            }
                            is JSONArray -> {
                                val set = mutableSetOf<String>()
                                for (i in 0 until value.length()) {
                                    set.add(value.getString(i))
                                }
                                editor.putStringSet(key, set)
                            }
                        }
                    }
                }
            }
            editor.commit()
        } catch (_: Exception) {}
    }

    /**
     * Fixes any background and custom PFP file paths in SharedPreferences after a restore.
     * Ensures all background and PFP paths point to existing files in the current device's backgrounds directory.
     */
    private fun fixBackgroundPathsAfterRestore(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_RIVO, Context.MODE_PRIVATE)
            val editor = prefs.edit()
            val bgDir = getBackgroundsDir(context)
            var modified = false

            val mediaDir = getContactMediaDir(context)
            val gifsDir = getContactGifsDir(context)

            prefs.all.forEach { (key, value) ->
                val isMediaKey = key.endsWith("_bg_path") ||
                        key.endsWith("_custom_pfp_path") ||
                        key.endsWith("_pfp_path") ||
                        key == PreferenceManager.KEY_INCOMING_CUSTOM_PFP_PATH ||
                        key == PreferenceManager.KEY_ONGOING_CUSTOM_PFP_PATH
                val isContactMediaKey = key.endsWith("_media_bg") || key.endsWith("_gif_bg")

                if (isMediaKey && value is String && value.isNotBlank()) {
                    val file = File(value)
                    if (!file.exists()) {
                        val fileName = file.name
                        val localFile = File(bgDir, fileName)
                        val candidateMedia = File(mediaDir, fileName)
                        when {
                            localFile.exists() -> {
                                editor.putString(key, localFile.absolutePath)
                                modified = true
                            }
                            candidateMedia.exists() -> {
                                editor.putString(key, candidateMedia.absolutePath)
                                modified = true
                            }
                        }
                    }
                } else if (isContactMediaKey && value is String && value.isNotBlank()) {
                    val file = File(value)
                    if (!file.exists()) {
                        val fileName = file.name
                        val localMedia = File(mediaDir, fileName)
                        val localGif = File(gifsDir, fileName)
                        val localBg = File(bgDir, fileName)
                        when {
                            localMedia.exists() -> {
                                editor.putString(key, localMedia.absolutePath)
                                modified = true
                            }
                            localGif.exists() -> {
                                editor.putString(key, localGif.absolutePath)
                                modified = true
                            }
                            localBg.exists() -> {
                                editor.putString(key, localBg.absolutePath)
                                modified = true
                            }
                        }
                    }
                }
            }

            // Also check if any background or custom PFP type is configured but its path is empty or pointing to a missing file
            val allKeys = prefs.all.keys.toList()
            allKeys.forEach { key ->
                if (key.endsWith("_bg_type")) {
                    val prefix = key.removeSuffix("_bg_type")
                    val type = prefs.getString(key, "none") ?: "none"
                    if (type == "wallpaper" || type == "picture" || type == "video") {
                        val pathKey = "${prefix}_bg_path"
                        val currentPath = prefs.getString(pathKey, "") ?: ""
                        val file = if (currentPath.isNotBlank()) File(currentPath) else null
                        if (file == null || !file.exists()) {
                            val candidatePng = File(bgDir, "custom_bg_${prefix}.png")
                            val candidateJpg = File(bgDir, "custom_bg_${prefix}.jpg")
                            val candidateMp4 = File(bgDir, "custom_bg_${prefix}.mp4")
                            when {
                                candidatePng.exists() -> {
                                    editor.putString(pathKey, candidatePng.absolutePath)
                                    modified = true
                                }
                                candidateJpg.exists() -> {
                                    editor.putString(pathKey, candidateJpg.absolutePath)
                                    modified = true
                                }
                                candidateMp4.exists() -> {
                                    editor.putString(pathKey, candidateMp4.absolutePath)
                                    modified = true
                                }
                            }
                        }
                    }
                } else if (key.endsWith("_custom_pfp_type")) {
                    val prefix = key.removeSuffix("_custom_pfp_type")
                    val type = prefs.getString(key, "none") ?: "none"
                    if (type == "wallpaper" || type == "picture" || type == "video") {
                        val pathKey = "${prefix}_custom_pfp_path"
                        val currentPath = prefs.getString(pathKey, "") ?: ""
                        val file = if (currentPath.isNotBlank()) File(currentPath) else null
                        if (file == null || !file.exists()) {
                            val candidatePng = File(bgDir, "custom_pfp_${prefix}.png")
                            val candidateJpg = File(bgDir, "custom_pfp_${prefix}.jpg")
                            val candidateMp4 = File(bgDir, "custom_pfp_${prefix}.mp4")
                            when {
                                candidatePng.exists() -> {
                                    editor.putString(pathKey, candidatePng.absolutePath)
                                    modified = true
                                }
                                candidateJpg.exists() -> {
                                    editor.putString(pathKey, candidateJpg.absolutePath)
                                    modified = true
                                }
                                candidateMp4.exists() -> {
                                    editor.putString(pathKey, candidateMp4.absolutePath)
                                    modified = true
                                }
                            }
                        }
                    }
                }
            }

            if (modified) {
                editor.apply()
            }
        } catch (_: Exception) {}
    }

    fun listBackups(context: Context): List<File> =
        getBackupDir(context).listFiles()
            ?.filter { it.extension == "everdialer" }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
}

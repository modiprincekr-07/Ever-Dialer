package com.modiprincekr.thedialer.view.components

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.modiprincekr.thedialer.controller.util.BackgroundMediaManager
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.modiprincekr.thedialer.controller.util.WallpaperExportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import java.io.FileOutputStream
import kotlin.math.roundToInt

enum class CustomBackgroundTarget(val prefix: String, val title: String) {
    INCOMING("incoming", "Incoming Call"),
    ONGOING("ongoing", "Ongoing Call")
}

@Composable
fun LoopingVideoPlayer(
    videoFile: File,
    modifier: Modifier = Modifier,
    isMuted: Boolean = true,
    videoSpeed: Float = 1.0f,
    isCircular: Boolean = false
) {
    AndroidView(
        factory = { ctx ->
            SeamlessLoopingVideoView(ctx).apply {
                this.isCircular = isCircular
                this.isMuted = isMuted
                this.videoSpeed = videoSpeed
                setVideoFile(videoFile)
            }
        },
        update = { view ->
            view.isCircular = isCircular
            view.isMuted = isMuted
            view.videoSpeed = videoSpeed
            view.setVideoFile(videoFile)
        },
        modifier = modifier
    )
}

class SeamlessLoopingVideoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val texture0 = TextureView(context)
    private val texture1 = TextureView(context)
    private var surface0: Surface? = null
    private var surface1: Surface? = null
    private var player0: MediaPlayer? = null
    private var player1: MediaPlayer? = null
    private var isPrepared0 = false
    private var isPrepared1 = false

    private var activeIndex = 0
    private var isCrossfading = false
    private var crossfadeAnimator: ValueAnimator? = null
    private val loopCheckHandler = Handler(Looper.getMainLooper())

    private var videoFile: File? = null
    private var videoDurationMs = 0

    var isCircular: Boolean = false
        set(value) {
            field = value
            updateOutline()
        }

    var isMuted: Boolean = true
        set(value) {
            field = value
            val vol = if (value) 0f else 1f
            if (!isCrossfading) {
                try { getActivePlayer()?.setVolume(vol, vol) } catch (_: Exception) {}
            }
        }

    var videoSpeed: Float = 1.0f
        set(value) {
            val clamped = value.coerceIn(0.25f, 3.0f)
            if (field == clamped) return
            field = clamped
            player0?.let { if (isPrepared0) applyPlaybackSpeed(it, clamped) }
            player1?.let { if (isPrepared1) applyPlaybackSpeed(it, clamped) }
        }

    private fun getActivePlayer(): MediaPlayer? = if (activeIndex == 0) player0 else player1
    private fun getStandbyPlayer(): MediaPlayer? = if (activeIndex == 0) player1 else player0
    private fun getActiveTexture(): TextureView = if (activeIndex == 0) texture0 else texture1
    private fun getStandbyTexture(): TextureView = if (activeIndex == 0) texture1 else texture0

    init {
        addView(texture0, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(texture1, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        texture0.alpha = 1f
        texture1.alpha = 0f
        setupTextureListeners()
    }

    private fun updateOutline() {
        if (isCircular) {
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    val w = if (view.width > 0) view.width else view.measuredWidth
                    val h = if (view.height > 0) view.height else view.measuredHeight
                    if (w > 0 && h > 0) {
                        outline.setOval(0, 0, w, h)
                    } else {
                        outline.setRect(0, 0, 0, 0)
                    }
                }
            }
            clipToOutline = true
        } else {
            outlineProvider = null
            clipToOutline = false
        }
        invalidateOutline()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            updateOutline()
            getActivePlayer()?.let { p ->
                if (isPrepared0 || isPrepared1) {
                    applyCenterCrop(texture0, p, w, h)
                    applyCenterCrop(texture1, p, w, h)
                }
            }
        }
    }

    private fun setupTextureListeners() {
        texture0.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                surface0?.release()
                surface0 = Surface(st)
                initPlayersIfReady(w, h)
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                getActivePlayer()?.let { p -> applyCenterCrop(texture0, p, w, h) }
            }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                surface0?.release()
                surface0 = null
                releasePlayer(0)
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        texture1.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                surface1?.release()
                surface1 = Surface(st)
                initPlayersIfReady(w, h)
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                getActivePlayer()?.let { p -> applyCenterCrop(texture1, p, w, h) }
            }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                surface1?.release()
                surface1 = null
                releasePlayer(1)
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }

    fun setVideoFile(file: File) {
        if (!file.exists()) return
        val isSameFile = videoFile?.absolutePath == file.absolutePath
        videoFile = file
        if (isSameFile && getActivePlayer() != null) {
            try {
                val p = getActivePlayer()
                if ((isPrepared0 || isPrepared1) && p?.isPlaying == false) {
                    p.start()
                    startProgressLoop()
                }
            } catch (_: Exception) {}
            return
        }

        ensureSurfaces()
        val w = if (width > 0) width else measuredWidth
        val h = if (height > 0) height else measuredHeight
        initPlayersIfReady(w, h)
    }

    private fun ensureSurfaces() {
        if ((surface0 == null || !surface0!!.isValid) && texture0.isAvailable && texture0.surfaceTexture != null) {
            try {
                surface0?.release()
                surface0 = Surface(texture0.surfaceTexture)
            } catch (_: Exception) {}
        }
        if ((surface1 == null || !surface1!!.isValid) && texture1.isAvailable && texture1.surfaceTexture != null) {
            try {
                surface1?.release()
                surface1 = Surface(texture1.surfaceTexture)
            } catch (_: Exception) {}
        }
    }

    private fun applyPlaybackSpeed(mp: MediaPlayer?, speed: Float) {
        if (mp == null) return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            try {
                val params = mp.playbackParams
                params.speed = speed
                params.pitch = 1.0f
                mp.playbackParams = params
            } catch (_: Exception) {
                try {
                    val params = android.media.PlaybackParams()
                    params.speed = speed
                    params.pitch = 1.0f
                    mp.playbackParams = params
                } catch (_: Exception) {}
            }
        }
    }

    private fun applyCenterCrop(texture: TextureView, player: MediaPlayer, viewW: Int, viewH: Int) {
        val actualW = if (viewW > 0) viewW else (if (texture.width > 0) texture.width else width)
        val actualH = if (viewH > 0) viewH else (if (texture.height > 0) texture.height else height)
        if (actualW <= 0 || actualH <= 0) return
        val vW = try { player.videoWidth } catch (_: Exception) { 0 }
        val vH = try { player.videoHeight } catch (_: Exception) { 0 }
        if (vW <= 0 || vH <= 0) return

        val viewRatio = actualW.toFloat() / actualH
        val videoRatio = vW.toFloat() / vH
        var scaleX = 1f
        var scaleY = 1f
        if (videoRatio > viewRatio) {
            scaleX = videoRatio / viewRatio
        } else {
            scaleY = viewRatio / videoRatio
        }
        val matrix = Matrix().apply {
            setScale(scaleX, scaleY, actualW / 2f, actualH / 2f)
        }
        texture.setTransform(matrix)
    }

    private fun createPlayerInstance(surf: Surface, index: Int, w: Int, h: Int): MediaPlayer? {
        val file = videoFile ?: return null
        if (!file.exists() || !surf.isValid) return null
        return try {
            MediaPlayer().apply {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MOVIE)
                            .build()
                    )
                }
                setDataSource(file.absolutePath)
                setSurface(surf)
                val vol = if (isMuted) 0f else 1f
                setVolume(vol, vol)

                setOnVideoSizeChangedListener { p, _, _ ->
                    applyCenterCrop(texture0, p, w, h)
                    applyCenterCrop(texture1, p, w, h)
                }

                setOnPreparedListener { p ->
                    if (index == 0) {
                        isPrepared0 = true
                        videoDurationMs = p.duration
                        applyCenterCrop(texture0, p, w, h)
                        applyCenterCrop(texture1, p, w, h)
                        applyPlaybackSpeed(p, videoSpeed)
                        if (activeIndex == 0) {
                            try { p.start() } catch (_: Exception) {}
                            startProgressLoop()
                        }
                        if (surface1?.isValid == true && player1 == null) {
                            player1 = createPlayerInstance(surface1!!, 1, w, h)
                        }
                    } else {
                        isPrepared1 = true
                        applyCenterCrop(texture1, p, w, h)
                        applyPlaybackSpeed(p, videoSpeed)
                        if (activeIndex == 1) {
                            try { p.start() } catch (_: Exception) {}
                            startProgressLoop()
                        }
                    }
                }

                setOnCompletionListener {
                    handlePlayerCompletion(index)
                }

                setOnErrorListener { p, _, _ ->
                    try { p.reset() } catch (_: Exception) {}
                    true
                }

                prepareAsync()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun initPlayersIfReady(w: Int, h: Int) {
        val file = videoFile ?: return
        ensureSurfaces()
        if (!file.exists()) return

        stopProgressLoop()
        crossfadeAnimator?.cancel()
        isCrossfading = false

        activeIndex = 0
        texture0.alpha = 1f
        texture1.alpha = 0f

        val surf0 = surface0
        if (surf0 != null && surf0.isValid) {
            releasePlayer(0)
            player0 = createPlayerInstance(surf0, 0, w, h)
        }
        val surf1 = surface1
        if (surf1 != null && surf1.isValid) {
            releasePlayer(1)
            player1 = createPlayerInstance(surf1, 1, w, h)
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            checkAndTriggerCrossfade()
            loopCheckHandler.postDelayed(this, 30L)
        }
    }

    private fun startProgressLoop() {
        stopProgressLoop()
        loopCheckHandler.post(progressRunnable)
    }

    private fun stopProgressLoop() {
        loopCheckHandler.removeCallbacksAndMessages(null)
    }

    private fun checkAndTriggerCrossfade() {
        if (isCrossfading || videoDurationMs <= 0) return
        val activePlayer = getActivePlayer() ?: return
        if (!activePlayer.isPlaying) return

        val currentPos = try { activePlayer.currentPosition } catch (_: Exception) { 0 }
        // User requested: "smooth and slow overlapping animation to join the video"
        val overlapMs = (videoDurationMs / 3).coerceIn(500, 1200)

        if (currentPos >= (videoDurationMs - overlapMs) && currentPos > 0) {
            startLoopCrossfade(overlapMs.toLong())
        }
    }

    private fun startLoopCrossfade(durationMs: Long) {
        if (isCrossfading) return
        val outgoingPlayer = getActivePlayer() ?: return
        val outgoingTexture = getActiveTexture()
        val incomingPlayer = getStandbyPlayer()
        val incomingTexture = getStandbyTexture()

        if (incomingPlayer == null) {
            try {
                outgoingPlayer.seekTo(0)
                outgoingPlayer.start()
            } catch (_: Exception) {}
            return
        }

        isCrossfading = true
        crossfadeAnimator?.cancel()

        try {
            incomingPlayer.seekTo(0)
            applyPlaybackSpeed(incomingPlayer, videoSpeed)
            val baseVol = if (isMuted) 0f else 1f
            incomingPlayer.setVolume(0f, 0f)
            incomingPlayer.start()
        } catch (_: Exception) {
            isCrossfading = false
            try {
                outgoingPlayer.seekTo(0)
                outgoingPlayer.start()
            } catch (_: Exception) {}
            return
        }

        incomingTexture.bringToFront()
        incomingTexture.alpha = 0f

        val baseVol = if (isMuted) 0f else 1f
        crossfadeAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                val f = anim.animatedFraction
                incomingTexture.alpha = f
                outgoingTexture.alpha = 1f - f
                if (!isMuted) {
                    try {
                        incomingPlayer.setVolume(baseVol * f, baseVol * f)
                        outgoingPlayer.setVolume(baseVol * (1f - f), baseVol * (1f - f))
                    } catch (_: Exception) {}
                }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    incomingTexture.alpha = 1f
                    outgoingTexture.alpha = 0f
                    try {
                        outgoingPlayer.pause()
                        outgoingPlayer.seekTo(0)
                    } catch (_: Exception) {}
                    activeIndex = if (activeIndex == 0) 1 else 0
                    isCrossfading = false
                }

                override fun onAnimationCancel(animation: Animator) {
                    isCrossfading = false
                }
            })
            start()
        }
    }

    private fun handlePlayerCompletion(index: Int) {
        if (index == activeIndex) {
            if (!isCrossfading) {
                startLoopCrossfade(500L)
            }
        }
    }

    private fun releasePlayer(index: Int) {
        if (index == 0) {
            isPrepared0 = false
            try { player0?.stop(); player0?.release() } catch (_: Exception) {}
            player0 = null
        } else {
            isPrepared1 = false
            try { player1?.stop(); player1?.release() } catch (_: Exception) {}
            player1 = null
        }
    }

    private fun releaseAllPlayers() {
        stopProgressLoop()
        crossfadeAnimator?.cancel()
        releasePlayer(0)
        releasePlayer(1)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ensureSurfaces()
        if (getActivePlayer() == null && videoFile != null) {
            val w = if (width > 0) width else measuredWidth
            val h = if (height > 0) height else measuredHeight
            initPlayersIfReady(w, h)
        }
        try {
            val p = getActivePlayer()
            if (p != null && !p.isPlaying && (isPrepared0 || isPrepared1)) {
                p.start()
                startProgressLoop()
            }
        } catch (_: Exception) {}
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == View.VISIBLE) {
            ensureSurfaces()
            if (getActivePlayer() == null && videoFile != null) {
                val w = if (width > 0) width else measuredWidth
                val h = if (height > 0) height else measuredHeight
                initPlayersIfReady(w, h)
            }
            try {
                val p = getActivePlayer()
                if (p != null && !p.isPlaying && (isPrepared0 || isPrepared1)) {
                    p.start()
                    startProgressLoop()
                }
            } catch (_: Exception) {}
        } else {
            stopProgressLoop()
            crossfadeAnimator?.cancel()
            try { getActivePlayer()?.pause() } catch (_: Exception) {}
            try { getStandbyPlayer()?.pause() } catch (_: Exception) {}
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        releaseAllPlayers()
    }
}

/**
 * Modern floating popup offering 4 background options: None, Wallpaper, Custom Picture, Custom Video.
 */
@Composable
fun CustomBackgroundOptionsPopup(
    target: CustomBackgroundTarget,
    currentType: String,
    dialogTitle: String? = null,
    dialogSubtitle: String? = null,
    noneSubtitle: String? = null,
    onDismiss: () -> Unit,
    onSelectNone: () -> Unit,
    onOpenEditor: (file: File, isVideo: Boolean, bgType: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isLoadingWallpaper by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val tempFile = File(context.cacheDir, "picked_image_${System.currentTimeMillis()}.png")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    withContext(Dispatchers.Main) {
                        onOpenEditor(tempFile, false, "picture")
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Failed to load image", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val tempFile = File(context.cacheDir, "picked_video_${System.currentTimeMillis()}.mp4")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    withContext(Dispatchers.Main) {
                        onOpenEditor(tempFile, true, "video")
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Failed to load video", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    val systemFilePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val cr = context.contentResolver
                    val mime = cr.getType(uri) ?: ""
                    val uriStr = uri.toString().lowercase()
                    val isVideo = mime.startsWith("video") || uriStr.endsWith(".mp4") || uriStr.endsWith(".mkv") || uriStr.endsWith(".webm") || uriStr.endsWith(".mov") || uriStr.endsWith(".3gp")
                    val ext = if (isVideo) ".mp4" else ".png"
                    val tempFile = File(context.cacheDir, "picked_file_${System.currentTimeMillis()}$ext")
                    cr.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    withContext(Dispatchers.Main) {
                        if (tempFile.exists() && tempFile.length() > 0) {
                            onOpenEditor(tempFile, isVideo, if (isVideo) "video" else "picture")
                        } else {
                            Toast.makeText(context, "Could not open selected file", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Failed to load file: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable { onDismiss() }
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp,
                shadowElevation = 12.dp,
                modifier = Modifier
                    .widthIn(max = 380.dp)
                    .fillMaxWidth()
                    .clickable(enabled = false) {}
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Outlined.Wallpaper,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                dialogTitle ?: "Choose Custom Background",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                dialogSubtitle ?: "${target.title} Screen",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // Option 1: None (Default)
                    BackgroundOptionItem(
                        icon = Icons.Outlined.NotInterested,
                        iconTint = MaterialTheme.colorScheme.primary,
                        iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        title = "None",
                        subtitle = noneSubtitle ?: "Default caller background",
                        isSelected = currentType == "none" || currentType.isEmpty(),
                        onClick = {
                            onSelectNone()
                            onDismiss()
                        }
                    )

                    Spacer(Modifier.height(10.dp))

                    // Option 2: Wallpaper
                    BackgroundOptionItem(
                        icon = Icons.Outlined.PhoneAndroid,
                        iconTint = MaterialTheme.colorScheme.primary,
                        iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        title = "Wallpaper",
                        subtitle = if (isLoadingWallpaper) "Extracting wallpaper..." else "Current device system wallpaper",
                        isSelected = currentType == "wallpaper",
                        onClick = {
                            if (!isLoadingWallpaper) {
                                isLoadingWallpaper = true
                                scope.launch(Dispatchers.IO) {
                                    val wallpaperFile = WallpaperExportHelper.extractWallpaperToFile(context)
                                    withContext(Dispatchers.Main) {
                                        isLoadingWallpaper = false
                                        if (wallpaperFile != null) {
                                            onOpenEditor(wallpaperFile, false, "wallpaper")
                                        } else {
                                            Toast.makeText(context, "Could not extract system wallpaper", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            }
                        }
                    )

                    Spacer(Modifier.height(10.dp))

                    // Option 3: Custom Picture
                    BackgroundOptionItem(
                        icon = Icons.Outlined.Image,
                        iconTint = MaterialTheme.colorScheme.primary,
                        iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        title = "Custom Picture",
                        subtitle = "Pick a photo or image from gallery",
                        isSelected = currentType == "picture",
                        onClick = {
                            imagePickerLauncher.launch("image/*")
                        }
                    )

                    Spacer(Modifier.height(10.dp))

                    // Option 4: Custom Video
                    BackgroundOptionItem(
                        icon = Icons.Outlined.Videocam,
                        iconTint = MaterialTheme.colorScheme.primary,
                        iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        title = "Custom Video",
                        subtitle = "Pick a looping video background",
                        isSelected = currentType == "video",
                        onClick = {
                            videoPickerLauncher.launch("video/*")
                        }
                    )

                    Spacer(Modifier.height(10.dp))

                    // Option 5: File Manager (any picture or video)
                    BackgroundOptionItem(
                        icon = Icons.Outlined.FolderOpen,
                        iconTint = MaterialTheme.colorScheme.primary,
                        iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        title = "Choose from File Manager",
                        subtitle = "Select any picture or video file",
                        isSelected = false,
                        onClick = {
                            systemFilePickerLauncher.launch(arrayOf("image/*", "video/*", "*/*"))
                        }
                    )

                    Spacer(Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cancel", fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun BackgroundOptionItem(
    icon: ImageVector,
    iconTint: Color,
    iconContainerColor: Color,
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                 else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = iconContainerColor,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(22.dp))
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (isSelected) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/**
 * Full-screen Interactive Background Editor Menu:
 * - Zoom in / out (interactive pinch and pan gesture + zoom buttons)
 * - Floating pill-styled buttons: Save, Dim, Blur, Speed
 * - Separate Back button on the left side in the bottom of the screen
 */
@Composable
fun CustomBackgroundEditorDialog(
    target: CustomBackgroundTarget,
    mediaFile: File,
    isVideo: Boolean,
    bgType: String,
    prefixOverride: String? = null,
    isPfpEditor: Boolean = false,
    pfpShape: String = "circle",
    initialZoom: Float = 1.0f,
    initialPanX: Float = 0f,
    initialPanY: Float = 0f,
    initialDim: Float = 0f,
    initialBlur: Float = 0f,
    initialVideoSpeed: Float = 1.0f,
    onDismiss: () -> Unit,
    onSaveSuccess: () -> Unit
) {
    val context = LocalContext.current
    val prefs = org.koin.compose.koinInject<PreferenceManager>()
    val scope = rememberCoroutineScope()

    var zoom by remember { mutableFloatStateOf(initialZoom.coerceIn(1f, 4f)) }
    var panX by remember { mutableFloatStateOf(initialPanX) }
    var panY by remember { mutableFloatStateOf(initialPanY) }

    var dimValue by remember { mutableFloatStateOf(initialDim.coerceIn(0f, 0.90f)) }
    var blurValue by remember { mutableFloatStateOf(initialBlur.coerceIn(0f, 50f)) }
    var videoSpeed by remember { mutableFloatStateOf(initialVideoSpeed.coerceIn(0.25f, 3.0f)) }

    // Active adjustable slider: null | "dim" | "blur" | "speed"
    var activeSlider by remember { mutableStateOf<String?>(null) }

    var isSaving by remember { mutableStateOf(false) }

    // Retrieve intrinsic dimensions of the media
    val (mediaWidth, mediaHeight) = remember(mediaFile) {
        if (!mediaFile.exists()) 1080 to 1920
        else if (!isVideo) {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(mediaFile.absolutePath, options)
            val w = if (options.outWidth > 0) options.outWidth else 1080
            val h = if (options.outHeight > 0) options.outHeight else 1920
            w to h
        } else {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(mediaFile.absolutePath)
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
                val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
                retriever.release()
                if (rotation == 90 || rotation == 270) rawH to rawW else rawW to rawH
            } catch (_: Exception) {
                1080 to 1920
            }
        }
    }

    fun handleDismiss() {
        scope.launch(Dispatchers.IO) {
            BackgroundMediaManager.cleanupFileIfInCache(context, mediaFile)
        }
        onDismiss()
    }

    fun saveBackground() {
        if (isSaving) return
        isSaving = true
        scope.launch(Dispatchers.IO) {
            try {
                val bgDir = File(context.filesDir, "backgrounds").apply { mkdirs() }
                val ext = if (isVideo) "mp4" else "png"
                val p = prefixOverride ?: target.prefix
                val destFile = File(bgDir, if (isPfpEditor) "custom_pfp_${p}.$ext" else "custom_bg_${p}.$ext")
                mediaFile.copyTo(destFile, overwrite = true)

                // Delete temporary picked file from cacheDir
                BackgroundMediaManager.cleanupFileIfInCache(context, mediaFile)

                if (isPfpEditor) {
                    prefs.setString("${p}_custom_pfp_type", bgType)
                    prefs.setString("${p}_custom_pfp_path", destFile.absolutePath)
                    prefs.setFloat("${p}_custom_pfp_zoom", zoom)
                    prefs.setFloat("${p}_custom_pfp_pan_x", panX)
                    prefs.setFloat("${p}_custom_pfp_pan_y", panY)
                    prefs.setFloat("${p}_custom_pfp_dim", dimValue)
                    prefs.setFloat("${p}_custom_pfp_blur", blurValue)
                    if (isVideo) {
                        prefs.setFloat("${p}_custom_pfp_video_speed", videoSpeed)
                    }
                } else {
                    prefs.setString("${p}_bg_type", bgType)
                    prefs.setString("${p}_bg_path", destFile.absolutePath)
                    prefs.setFloat("${p}_bg_zoom", zoom)
                    prefs.setFloat("${p}_bg_pan_x", panX)
                    prefs.setFloat("${p}_bg_pan_y", panY)
                    prefs.setFloat("${p}_bg_dim", dimValue)
                    prefs.setFloat("${p}_bg_blur", blurValue)
                    if (isVideo) {
                        prefs.setFloat("${p}_bg_video_speed", videoSpeed)
                    }
                }

                // Prune any unreferenced backgrounds
                BackgroundMediaManager.pruneOrphanedBackgrounds(context, prefs)

                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, if (isPfpEditor) "Contact PFP saved successfully" else "Background saved successfully", Toast.LENGTH_SHORT).show()
                    onSaveSuccess()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, "Failed to save: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Dialog(
        onDismissRequest = { handleDismiss() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            val density = LocalDensity.current
            val screenW = constraints.maxWidth.toFloat()
            val screenH = constraints.maxHeight.toFloat()

            val isSquare = isPfpEditor && pfpShape == "square"
            val cropShape = if (isSquare) RoundedCornerShape(20.dp) else CircleShape

            val cropSizeDp = 240.dp
            val cropSizePx = with(density) { cropSizeDp.toPx() }

            // Viewport dimensions for cropping
            val viewW = if (isPfpEditor) cropSizePx else screenW
            val viewH = if (isPfpEditor) cropSizePx else screenH

            val mediaRatio = (mediaWidth.toFloat() / mediaHeight.toFloat()).coerceIn(0.05f, 20f)
            val viewRatio = (viewW / viewH).coerceIn(0.05f, 20f)

            val baseRenderedW = if (mediaRatio > viewRatio) viewH * mediaRatio else viewW
            val baseRenderedH = if (mediaRatio > viewRatio) viewH else viewW / mediaRatio

            val effW = baseRenderedW * zoom
            val effH = baseRenderedH * zoom
            val maxPanX = max(0f, (effW - viewW) / 2f)
            val maxPanY = max(0f, (effH - viewH) / 2f)

            // Ensure pan remains within bounded frame (no black borders)
            LaunchedEffect(zoom, maxPanX, maxPanY) {
                panX = if (maxPanX <= 0f) 0f else panX.coerceIn(-maxPanX, maxPanX)
                panY = if (maxPanY <= 0f) 0f else panY.coerceIn(-maxPanY, maxPanY)
            }

            // Media Layer with Transform Gestures - strictly bounded to content boundary
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(baseRenderedW, baseRenderedH, viewW, viewH) {
                        detectTransformGestures { _, pan, gestureZoom, _ ->
                            val newZoom = (zoom * gestureZoom).coerceIn(1f, 4f)
                            zoom = newZoom

                            val curEffW = baseRenderedW * newZoom
                            val curEffH = baseRenderedH * newZoom
                            val curMaxPanX = max(0f, (curEffW - viewW) / 2f)
                            val curMaxPanY = max(0f, (curEffH - viewH) / 2f)

                            panX = if (curMaxPanX <= 0f) 0f else (panX + pan.x).coerceIn(-curMaxPanX, curMaxPanX)
                            panY = if (curMaxPanY <= 0f) 0f else (panY + pan.y).coerceIn(-curMaxPanY, curMaxPanY)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                val mediaWidthDp = with(density) { baseRenderedW.toDp() }
                val mediaHeightDp = with(density) { baseRenderedH.toDp() }

                Box(
                    modifier = Modifier
                        .size(mediaWidthDp, mediaHeightDp)
                        .graphicsLayer {
                            scaleX = zoom
                            scaleY = zoom
                            translationX = panX
                            translationY = panY
                        }
                        .then(if (blurValue > 0f) Modifier.blur(blurValue.dp) else Modifier)
                ) {
                    if (isVideo) {
                        LoopingVideoPlayer(
                            videoFile = mediaFile,
                            videoSpeed = videoSpeed,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        AsyncImage(
                            model = mediaFile,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Dim overlay
                if (dimValue > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = dimValue))
                    )
                }

                // Avatar shape-aware frame overlay for PFP editor (Circle or Square preview)
                if (isPfpEditor) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                    ) {
                        // Dark scrim outside crop frame
                        drawRect(Color.Black.copy(alpha = 0.65f))
                        val left = (size.width - cropSizePx) / 2f
                        val top = (size.height - cropSizePx) / 2f

                        if (isSquare) {
                            drawRoundRect(
                                color = Color.Transparent,
                                topLeft = Offset(left, top),
                                size = Size(cropSizePx, cropSizePx),
                                cornerRadius = CornerRadius(20.dp.toPx()),
                                blendMode = BlendMode.Clear
                            )
                        } else {
                            drawCircle(
                                color = Color.Transparent,
                                radius = cropSizePx / 2f,
                                center = Offset(size.width / 2f, size.height / 2f),
                                blendMode = BlendMode.Clear
                            )
                        }
                    }

                    // Precise crop border (square with rounded corners or circle)
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(cropSizeDp)
                            .border(2.5.dp, Color.White.copy(alpha = 0.90f), cropShape)
                    )
                }
            }

            // Top overlay bar with M3 Expressive floating glass pill
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 44.dp, start = 16.dp, end = 16.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.88f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    shadowElevation = 6.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                if (isPfpEditor) (if (isSquare) "Square PFP Editor" else "Circle PFP Editor") else "Background Editor",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                if (isPfpEditor) "Pinch or drag within ${if (isSquare) "square" else "circle"} frame" else "Pinch or drag to position & scale",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (zoom > 1.05f || panX != 0f || panY != 0f || dimValue > 0f || blurValue > 0f || videoSpeed != 1.0f) {
                            FilledTonalButton(
                                onClick = {
                                    zoom = 1.0f
                                    panX = 0f
                                    panY = 0f
                                    dimValue = 0f
                                    blurValue = 0f
                                    videoSpeed = 1.0f
                                    activeSlider = null
                                },
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Reset", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // Floating Zoom Buttons (Right side) - M3 Expressive Tonal Pill
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.90f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilledTonalIconButton(
                        onClick = { zoom = (zoom + 0.25f).coerceAtMost(4f) },
                        modifier = Modifier.size(40.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                            contentColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Zoom In", modifier = Modifier.size(20.dp))
                    }
                    FilledTonalIconButton(
                        onClick = { zoom = (zoom - 0.25f).coerceAtLeast(1f) },
                        modifier = Modifier.size(40.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                            contentColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Zoom Out", modifier = Modifier.size(20.dp))
                    }
                }
            }

            // Bottom Control Area (M3 Expressive Sliders Panel + Floating Action Bar)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                        )
                    )
                    .padding(start = 16.dp, end = 16.dp, bottom = 36.dp, top = 16.dp)
            ) {
                // Interactive Adjustable Slider Panel (Dim, Blur, or Speed)
                AnimatedVisibility(
                    visible = activeSlider != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.98f),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                        shadowElevation = 12.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (activeSlider == "dim") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Outlined.Brightness4, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                        Text(
                                            "Dim Intensity: ${(dimValue * 100).toInt()}%",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (dimValue > 0f) {
                                            FilledTonalIconButton(
                                                onClick = { dimValue = 0f },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = "Reset Dim", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        FilledTonalIconButton(
                                            onClick = { activeSlider = null },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Close Slider", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                                Slider(
                                    value = dimValue,
                                    onValueChange = { dimValue = it },
                                    valueRange = 0f..0.90f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.primary,
                                        activeTrackColor = MaterialTheme.colorScheme.primary,
                                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else if (activeSlider == "blur") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.tertiaryContainer,
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Outlined.BlurOn, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                        Text(
                                            "Blur Intensity: ${blurValue.toInt()} dp",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (blurValue > 0f) {
                                            FilledTonalIconButton(
                                                onClick = { blurValue = 0f },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = "Reset Blur", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        FilledTonalIconButton(
                                            onClick = { activeSlider = null },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Close Slider", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                                Slider(
                                    value = blurValue,
                                    onValueChange = { blurValue = it },
                                    valueRange = 0f..50f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.tertiary,
                                        activeTrackColor = MaterialTheme.colorScheme.tertiary,
                                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else if (activeSlider == "speed") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Outlined.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                        Text(
                                            "Playback Speed: ${String.format(java.util.Locale.US, "%.2f", videoSpeed)}x",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (videoSpeed != 1.0f) {
                                            FilledTonalIconButton(
                                                onClick = { videoSpeed = 1.0f },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = "Reset Speed", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        FilledTonalIconButton(
                                            onClick = { activeSlider = null },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Close Slider", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                                Slider(
                                    value = videoSpeed,
                                    onValueChange = { videoSpeed = it },
                                    valueRange = 0.25f..2.5f,
                                    steps = 8,
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.secondary,
                                        activeTrackColor = MaterialTheme.colorScheme.secondary,
                                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { preset ->
                                        SuggestionChip(
                                            onClick = { videoSpeed = preset },
                                            label = { Text("${preset}x", style = MaterialTheme.typography.labelSmall) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(
                                                containerColor = if (kotlin.math.abs(videoSpeed - preset) < 0.05f) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // M3 Expressive Back Button
                    Surface(
                        onClick = { handleDismiss() },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.92f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(52.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // M3 Expressive Floating Action Bar (Dim, Blur, Speed, Save)
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.92f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        shadowElevation = 8.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Dim Button - toggles Dim Slider
                            val isDimActive = activeSlider == "dim"
                            Surface(
                                onClick = {
                                    activeSlider = if (isDimActive) null else "dim"
                                },
                                shape = RoundedCornerShape(20.dp),
                                color = if (isDimActive) MaterialTheme.colorScheme.primaryContainer
                                        else if (dimValue > 0f) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                        else MaterialTheme.colorScheme.surfaceContainerHighest,
                                border = androidx.compose.foundation.BorderStroke(
                                    if (isDimActive) 1.5.dp else 1.dp,
                                    if (isDimActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                ),
                                modifier = Modifier.weight(1f).height(44.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        Icons.Outlined.Brightness4,
                                        contentDescription = "Dim",
                                        tint = if (dimValue > 0f || isDimActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        if (dimValue > 0f) "${(dimValue * 100).toInt()}%" else "Dim",
                                        color = if (dimValue > 0f || isDimActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Blur Button - toggles Blur Slider
                            val isBlurActive = activeSlider == "blur"
                            Surface(
                                onClick = {
                                    activeSlider = if (isBlurActive) null else "blur"
                                },
                                shape = RoundedCornerShape(20.dp),
                                color = if (isBlurActive) MaterialTheme.colorScheme.tertiaryContainer
                                        else if (blurValue > 0f) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                                        else MaterialTheme.colorScheme.surfaceContainerHighest,
                                border = androidx.compose.foundation.BorderStroke(
                                    if (isBlurActive) 1.5.dp else 1.dp,
                                    if (isBlurActive) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                ),
                                modifier = Modifier.weight(1f).height(44.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        Icons.Outlined.BlurOn,
                                        contentDescription = "Blur",
                                        tint = if (blurValue > 0f || isBlurActive) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        if (blurValue > 0f) "${blurValue.toInt()}dp" else "Blur",
                                        color = if (blurValue > 0f || isBlurActive) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Speed Button (video only)
                            if (isVideo) {
                                val isSpeedActive = activeSlider == "speed"
                                Surface(
                                    onClick = {
                                        activeSlider = if (isSpeedActive) null else "speed"
                                    },
                                    shape = RoundedCornerShape(20.dp),
                                    color = if (isSpeedActive) MaterialTheme.colorScheme.secondaryContainer
                                            else if (videoSpeed != 1.0f) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                                            else MaterialTheme.colorScheme.surfaceContainerHighest,
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (isSpeedActive) 1.5.dp else 1.dp,
                                        if (isSpeedActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                    ),
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            Icons.Outlined.Speed,
                                            contentDescription = "Speed",
                                            tint = if (videoSpeed != 1.0f || isSpeedActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            if (videoSpeed != 1.0f) "${String.format(java.util.Locale.US, "%.1f", videoSpeed)}x" else "Speed",
                                            color = if (videoSpeed != 1.0f || isSpeedActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            // Save Button - M3 Primary Filled
                            Button(
                                onClick = { saveBackground() },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                modifier = Modifier.height(44.dp)
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Save",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Save",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

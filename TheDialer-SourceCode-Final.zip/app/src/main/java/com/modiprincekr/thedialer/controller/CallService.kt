package com.modiprincekr.thedialer.controller

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ImageSpan
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat
import com.modiprincekr.thedialer.MainActivity
import com.modiprincekr.thedialer.R
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.modiprincekr.thedialer.controller.util.getSimSlotForAccountHandle
import com.modiprincekr.thedialer.controller.util.getSimSlotForCall
import com.modiprincekr.thedialer.controller.UssdRepository
import com.modiprincekr.thedialer.modal.`interface`.IContactsRepository
import com.modiprincekr.thedialer.view.screen.BiometricCallActivity
import com.modiprincekr.thedialer.view.screen.CallActivity
import com.modiprincekr.thedialer.view.screen.settings.KEY_SELECTED_APP_ICON
import android.telecom.DisconnectCause
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import org.koin.android.ext.android.inject

data class CallSession(
    val call: Call,
    val state: Int,
    val updateTime: Long = System.currentTimeMillis()
)

class CallService : InCallService() {

    private val contactsRepository: IContactsRepository by inject()
    private val prefs: PreferenceManager by inject()

    // Bug fix: the ongoing-call notification's elapsed-time display was driven off whatever
    // System.currentTimeMillis() happened to be at the moment updateNotification() rebuilt the
    // notification (setWhen() was never set, so NotificationCompat.Builder defaulted it to
    // "now"). updateNotification() gets called for lots of things besides the call actually
    // connecting — mute toggle, speaker toggle, held-call updates — so every one of those
    // silently reset the notification's start time and made the displayed call duration drift
    // away from the real one. This map remembers the real moment each call became ACTIVE once,
    // so every later rebuild reuses that same timestamp instead of a fresh "now".
    private val callConnectTimes = mutableMapOf<Call, Long>()
    private val callRingStartTimes = mutableMapOf<Call, Long>()
    private val callAnsweredSet = mutableSetOf<Call>()
    private val handledCallEndedPopups = java.util.Collections.newSetFromMap(java.util.WeakHashMap<Call, Boolean>())
    private val pendingAccountSelectionCalls = java.util.Collections.newSetFromMap(java.util.WeakHashMap<Call, Boolean>())
    private val defaultAudioAppliedForCall = java.util.Collections.newSetFromMap(java.util.WeakHashMap<Call, Boolean>())

    fun applyDefaultAudioRouting(call: Call) {
        if (!defaultAudioAppliedForCall.add(call)) return
        val usePrevious = prefs.getBoolean(PreferenceManager.KEY_USE_PREVIOUS_CALL_AUDIO_CONFIG, false)
        val desiredSpeaker = if (usePrevious) {
            prefs.getString(PreferenceManager.KEY_LAST_USED_SPEAKER_ROUTE, PreferenceManager.SPEAKER_ROUTE_EXTERNAL) ?: PreferenceManager.SPEAKER_ROUTE_EXTERNAL
        } else {
            prefs.getString(PreferenceManager.KEY_DEFAULT_SPEAKER_ROUTE, PreferenceManager.SPEAKER_ROUTE_EXTERNAL) ?: PreferenceManager.SPEAKER_ROUTE_EXTERNAL
        }

        val supportedMask = _audioState.value?.supportedRouteMask ?: 0
        val btAdapter = try { BluetoothAdapter.getDefaultAdapter() } catch (_: Throwable) { null }
        val hasBluetooth = (supportedMask and CallAudioState.ROUTE_BLUETOOTH) != 0 ||
            try {
                btAdapter?.getProfileConnectionState(BluetoothProfile.HEADSET) == BluetoothProfile.STATE_CONNECTED
            } catch (_: Throwable) { false }
        val hasWired = (supportedMask and CallAudioState.ROUTE_WIRED_HEADSET) != 0
        val isExternalConnected = hasBluetooth || hasWired

        val audioManager = try { getSystemService(Context.AUDIO_SERVICE) as? AudioManager } catch (_: Throwable) { null }
        try {
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (_: Throwable) {}

        when (desiredSpeaker) {
            PreferenceManager.SPEAKER_ROUTE_EXTERNAL -> {
                if (isExternalConnected) {
                    val route = if (hasBluetooth) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_HEADSET
                    setAudioRoute(route)
                } else {
                    setAudioRoute(CallAudioState.ROUTE_EARPIECE)
                }
            }
            PreferenceManager.SPEAKER_ROUTE_SPEAKER -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val speakerDev = audioManager?.availableCommunicationDevices?.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    if (speakerDev != null) audioManager.setCommunicationDevice(speakerDev)
                }
                setAudioRoute(CallAudioState.ROUTE_SPEAKER)
            }
            PreferenceManager.SPEAKER_ROUTE_EAR -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val earpieceDev = audioManager?.availableCommunicationDevices?.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
                    if (earpieceDev != null) audioManager.setCommunicationDevice(earpieceDev)
                }
                val targetRoute = if ((supportedMask and CallAudioState.ROUTE_EARPIECE) != 0) {
                    CallAudioState.ROUTE_EARPIECE
                } else if (hasWired) {
                    CallAudioState.ROUTE_WIRED_HEADSET
                } else {
                    CallAudioState.ROUTE_EARPIECE
                }
                setAudioRoute(targetRoute)
            }
            else -> {
                if (isExternalConnected) {
                    val route = if (hasBluetooth) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_HEADSET
                    setAudioRoute(route)
                } else {
                    setAudioRoute(CallAudioState.ROUTE_EARPIECE)
                }
            }
        }
    }

    private fun recordMissedCallDurationIfNeeded(call: Call) {
        val ringStart = callRingStartTimes.remove(call)
        val wasAnswered = callAnsweredSet.remove(call)
        val isMissed = ringStart != null && !wasAnswered
        val ringDurationSec = if (isMissed) {
            ((System.currentTimeMillis() - (ringStart ?: System.currentTimeMillis())) / 1000L).coerceAtLeast(1L)
        } else {
            0L
        }
        val number = call.details?.handle?.schemeSpecificPart?.let { android.net.Uri.decode(it) } ?: ""
        val callDate = call.details?.creationTimeMillis?.takeIf { it > 0 } ?: (ringStart ?: System.currentTimeMillis())

        if (number.isNotBlank()) {
            if (isMissed) {
                com.modiprincekr.thedialer.controller.util.MissedCallDurationStore.saveDuration(
                    this, number, callDate, ringDurationSec
                )
                com.modiprincekr.thedialer.controller.util.MissedCallDurationStore.updateProviderDuration(
                    this, number, ringDurationSec
                )
            }

            // Suppress popup if intentionally triggered by WhatsApp Video switch or during active Auto Redial loop
            if (suppressPostCallPopup || isAutoRedialActive.value) {
                // Consume the suppression flag so normal calls behave correctly next time
                suppressPostCallPopup = false
                handledCallEndedPopups.add(call)
                return
            }

            // Trigger Missed Call / Call End Popup if enabled and permission granted
            val missedPopupEnabled = prefs.getBoolean(PreferenceManager.KEY_MISSED_CALL_POPUP_ENABLED, false)
            val alwaysAfterCallEnds = prefs.getBoolean(PreferenceManager.KEY_ALWAYS_SHOW_MISSED_CALL_POPUP_AFTER_CALL_END, false)
            val shouldShowPopup = ((isMissed && missedPopupEnabled) || alwaysAfterCallEnds) && android.provider.Settings.canDrawOverlays(this)

            if (shouldShowPopup && handledCallEndedPopups.add(call)) {
                val contact = try { contactsRepository.getContactByNumber(number) } catch (_: Exception) { null }
                val alt = if (contact == null && number.isNotEmpty()) {
                    com.modiprincekr.thedialer.controller.util.AlternateNumberRepository.findByNumber(this, number)
                } else null
                val name = contact?.name ?: alt?.name ?: number
                val photo = contact?.photoUri
                val contactId = contact?.id
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    MissedCallPopupService.start(
                        context = this,
                        number = number,
                        name = name,
                        photoUri = photo,
                        contactId = contactId,
                        callDate = callDate,
                        ringDurationSec = ringDurationSec,
                        isMissedCall = isMissed
                    )
                }, 300)
            }
        } else {
            suppressPostCallPopup = false
        }
    }

    // ── Proximity screen-off (plain + "Device Orientation with Proximity Sensor") ──────────
    // This used to live entirely inside CallActivity, acquiring/releasing a real
    // PROXIMITY_SCREEN_OFF_WAKE_LOCK from there. That wake lock is only reliably honored by the
    // system while the acquiring app has an actively foregrounded window — so the moment the user
    // switched away to the main The Dialer app during a call (leaving CallActivity backgrounded
    // behind it), the near-ear screen-off would silently stop taking effect, even though the
    // sensor readings and gate logic underneath kept ticking along just fine. Re-opening the
    // in-call UI put CallActivity back on top and "fixed" it again — but only by accident.
    // Owning it here instead, in the InCallService that already runs continuously for the whole
    // call as a foreground service regardless of which Activity (if any) is on top, removes that
    // dependency on window focus entirely, for both the plain and orientation-gated modes.
    private var proxSensorManager: SensorManager? = null
    private var proxProximitySensor: Sensor? = null
    private var proxAccelerometer: Sensor? = null
    private var proxWakeLock: PowerManager.WakeLock? = null
    private var mLastProximityNear: Boolean? = null
    private var mInclinationValue: Int? = null
    private var mIsSlanted: Boolean = false

    private fun acquireProxWakeLock() { if (proxWakeLock?.isHeld == false) proxWakeLock?.acquire() }
    private fun releaseProxWakeLock() { if (proxWakeLock?.isHeld == true) proxWakeLock?.release() }

    /** Re-evaluates from the latest cached sensor readings + current call/audio state and
     *  directly acquires/releases the real proximity wake lock. Called on every proximity and
     *  accelerometer update (so either sensor changing, or the phone leaving the ear, reacts
     *  immediately), and whenever call state or audio route changes. */
    private fun updateProximityScreenOffGate() {
        val session = _currentCallSession.value
        val callState = session?.state
        val currentRoute = _audioState.value?.route
        val isEarActive = when (currentRoute) {
            CallAudioState.ROUTE_EARPIECE -> true
            CallAudioState.ROUTE_SPEAKER,
            CallAudioState.ROUTE_BLUETOOTH,
            CallAudioState.ROUTE_WIRED_HEADSET -> false
            else -> {
                val lastUsedSpeaker = prefs.getString(PreferenceManager.KEY_LAST_USED_SPEAKER_ROUTE, "")
                lastUsedSpeaker != PreferenceManager.SPEAKER_ROUTE_SPEAKER
            }
        }
        val inCallForScreenOff = (callState == Call.STATE_ACTIVE || callState == Call.STATE_DIALING) && isEarActive

        if (!inCallForScreenOff) {
            releaseProxWakeLock()
            return
        }

        val orientationGateEnabled = prefs.getBoolean(PreferenceManager.KEY_PROXIMITY_ORIENTATION_BG, false)
        val isNear = mLastProximityNear == true

        if (orientationGateEnabled) {
            val inclination = mInclinationValue
            val orientedToEar = inclination != null && inclination in -90..90 && mIsSlanted
            if (isNear && orientedToEar) acquireProxWakeLock() else releaseProxWakeLock()
            return
        }

        // Plain mode: proximity sensor alone, no orientation/tilt gating.
        // Holding the proximity wake lock during earpiece calls allows Android's PowerManager
        // to turn off the display natively when proximity is detected near.
        acquireProxWakeLock()
    }

    private val proxSensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            when (event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    val ax = event.values[0]
                    val ay = event.values[1]
                    val az = event.values[2]
                    val normOfG = kotlin.math.sqrt(ax * ax + ay * ay + az * az)
                    if (normOfG > 0f) {
                        val nx = ax / normOfG
                        val ny = ay / normOfG
                        val nz = az / normOfG
                        mInclinationValue = Math.toDegrees(kotlin.math.atan2(nx, ny).toDouble()).roundToInt()
                        val angleFromFlatDeg = Math.toDegrees(kotlin.math.acos(nz.coerceIn(-1f, 1f).toDouble()))
                        val angleFromFlatOrBelow = kotlin.math.min(angleFromFlatDeg, 180.0 - angleFromFlatDeg)
                        val slantThreshold = prefs.getFloat(
                            PreferenceManager.KEY_PROXIMITY_ORIENTATION_SLANT_THRESHOLD,
                            PreferenceManager.DEFAULT_PROXIMITY_ORIENTATION_SLANT_THRESHOLD
                        )
                        mIsSlanted = angleFromFlatOrBelow > slantThreshold.toDouble()
                    }
                    updateProximityScreenOffGate()
                }
                Sensor.TYPE_PROXIMITY -> {
                    val maxRange = event.sensor.maximumRange
                    mLastProximityNear = event.values[0] < maxRange * 0.5f || event.values[0] == 0f || (maxRange > 0f && event.values[0] < maxRange)
                    updateProximityScreenOffGate()
                }
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun setupProximityScreenOff() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        proxWakeLock = powerManager.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "Rivo::ServiceProx")
        proxSensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        proxProximitySensor = proxSensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        proxAccelerometer = proxSensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        proxProximitySensor?.let { proxSensorManager?.registerListener(proxSensorListener, it, SensorManager.SENSOR_DELAY_UI) }
        proxAccelerometer?.let { proxSensorManager?.registerListener(proxSensorListener, it, SensorManager.SENSOR_DELAY_UI) }

        // Also re-evaluate whenever the call/audio state or the relevant settings change —
        // covers the moments proxSensorListener alone wouldn't (e.g. the call just went ACTIVE,
        // or speakerphone was toggled, with no new sensor reading yet).
        proxScope.launch {
            combine(_currentCallSession, _audioState, prefs.settingsChanged) { _, _, _ -> Unit }
                .collect { updateProximityScreenOffGate() }
        }
    }

    private fun teardownProximityScreenOff() {
        releaseProxWakeLock()
        proxSensorManager?.unregisterListener(proxSensorListener)
        proxScopeJob.cancel()
    }

    private val proxScopeJob = SupervisorJob()
    private val proxScope = CoroutineScope(Dispatchers.Main + proxScopeJob)

    override fun onCreate() {
        super.onCreate()
        setupProximityScreenOff()
    }

    override fun onDestroy() {
        super.onDestroy()
        teardownProximityScreenOff()
        RainModeManager.stop(this)
        if (redialJob?.isActive != true) {
            cancelAutoRedial()
        }
        suppressPostCallPopup = false
    }

    /**
     * The ongoing/incoming-call notification's small icon should look like whichever app icon
     * the user currently has selected (Settings > App Icon), instead of a generic stock phone
     * glyph that doesn't match and can appear mirrored/"inverted" next to it. Each app icon
     * variant already ships a monochrome adaptive-icon layer designed for exactly this purpose.
     */
    private fun currentCallSmallIcon(): Int {
        return when (prefs.getString(KEY_SELECTED_APP_ICON, "default")) {
            "phone"        -> R.drawable.ic_notif_call_phone
            "custom_phone" -> R.drawable.ic_notif_call_custom_phone
            "google"       -> R.drawable.ic_notif_call_google
            "nothing"      -> R.drawable.ic_notif_call_nothing
            else           -> R.drawable.ic_notif_call_default
        }
    }

    /** Loads the contact's photo (if any) as a square bitmap suitable for a Person/large icon. */
    private fun loadContactPhotoBitmap(photoUri: String?): android.graphics.Bitmap? {
        if (photoUri.isNullOrEmpty()) return null
        return try {
            contentResolver.openInputStream(android.net.Uri.parse(photoUri))?.use { stream ->
                val bytes = stream.readBytes()
                val exif = try {
                    android.media.ExifInterface(java.io.ByteArrayInputStream(bytes))
                } catch (_: Throwable) { null }
                val orientation = exif?.getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION,
                    android.media.ExifInterface.ORIENTATION_NORMAL
                ) ?: android.media.ExifInterface.ORIENTATION_NORMAL

                val raw = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
                when (orientation) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> {
                        val m = android.graphics.Matrix().apply { postRotate(90f) }
                        val r = android.graphics.Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                        if (r != raw) raw.recycle()
                        r
                    }
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> {
                        val m = android.graphics.Matrix().apply { postRotate(180f) }
                        val r = android.graphics.Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                        if (r != raw) raw.recycle()
                        r
                    }
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> {
                        val m = android.graphics.Matrix().apply { postRotate(270f) }
                        val r = android.graphics.Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                        if (r != raw) raw.recycle()
                        r
                    }
                    else -> raw
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    

    

    companion object {
        private const val CHANNEL_ID = "call_channel"
        private const val CHANNEL_INCOMING_ID = "call_incoming_channel_v3"
        private const val NOTIFICATION_ID = 101

        private val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")

        // Third-party apps that register their own voice/video calls as
        // self-managed Telecom connections. Because CallService declares
        // INCLUDE_SELF_MANAGED_CALLS, Telecom hands these to us too — but
        // The Dialer must never touch them (no CallActivity, no notification,
        // no cellular call side-effects). Snapchat is one such app: without
        // this exclusion its self-managed call was being treated like a real
        // cellular call by this service.
        private val SELF_MANAGED_THIRD_PARTY_PACKAGES = WHATSAPP_PACKAGES + setOf(
            "com.snapchat.android"
        )

        /** True if [call] is a self-managed call placed/received by a third-party app (WhatsApp, Snapchat, etc.) that The Dialer must not touch. */
        private fun isWhatsAppCall(call: Call): Boolean {
            val pkg = call.details?.accountHandle?.componentName?.packageName ?: return false
            return pkg in SELF_MANAGED_THIRD_PARTY_PACKAGES
        }

        private val _currentCallSession = MutableStateFlow<CallSession?>(null)
        val currentCallSession = _currentCallSession.asStateFlow()

        private val _heldCallSession = MutableStateFlow<CallSession?>(null)
        val heldCallSession = _heldCallSession.asStateFlow()

        private val _incomingCallSession = MutableStateFlow<CallSession?>(null)
        val incomingCallSession = _incomingCallSession.asStateFlow()

        private val _audioState = MutableStateFlow<CallAudioState?>(null)
        val audioState = _audioState.asStateFlow()

        val isAutoRedialActive = MutableStateFlow(false)
        @Volatile
        var suppressPostCallPopup = false
        private var redialJob: Job? = null
        private val redialScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

        fun toggleAutoRedial() {
            val next = !isAutoRedialActive.value
            isAutoRedialActive.value = next
            if (!next) {
                cancelAutoRedial()
            }
        }

        fun setAutoRedialActive(active: Boolean) {
            isAutoRedialActive.value = active
            if (!active) {
                cancelAutoRedial()
            }
        }

        fun cancelAutoRedial() {
            isAutoRedialActive.value = false
            redialJob?.cancel()
            redialJob = null
        }

        fun scheduleAutoRedial(context: Context, targetUri: android.net.Uri, accountHandle: PhoneAccountHandle?) {
            redialJob?.cancel()
            redialJob = redialScope.launch {
                try {
                    android.util.Log.d("EverDialerCall", "AutoRedial: waiting 3000ms delay before redialing $targetUri")
                    delay(3000L)
                    if (!isAutoRedialActive.value) {
                        android.util.Log.d("EverDialerCall", "AutoRedial: cancelled during delay")
                        return@launch
                    }

                    val ctx = instance ?: context.applicationContext ?: com.modiprincekr.thedialer.RivoApp.instance
                    if (androidx.core.content.ContextCompat.checkSelfPermission(
                            ctx,
                            android.Manifest.permission.CALL_PHONE
                        ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                    ) {
                        android.util.Log.w("EverDialerCall", "AutoRedial: CALL_PHONE permission not granted, cancelling redial")
                        cancelAutoRedial()
                        return@launch
                    }

                    val telecomManager = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                    val extras = android.os.Bundle().apply {
                        if (accountHandle != null) {
                            putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, accountHandle)
                        }
                    }

                    var placed = false
                    if (telecomManager != null) {
                        try {
                            android.util.Log.d("EverDialerCall", "AutoRedial: TelecomManager.placeCall($targetUri)")
                            telecomManager.placeCall(targetUri, extras)
                            placed = true
                        } catch (e: Throwable) {
                            android.util.Log.e("EverDialerCall", "AutoRedial: placeCall threw", e)
                        }
                    }

                    if (!placed) {
                        try {
                            android.util.Log.d("EverDialerCall", "AutoRedial: fallback to Intent.ACTION_CALL")
                            val callIntent = Intent(Intent.ACTION_CALL, targetUri).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                if (accountHandle != null) {
                                    putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, accountHandle)
                                }
                            }
                            ctx.startActivity(callIntent)
                            placed = true
                        } catch (e: Throwable) {
                            android.util.Log.e("EverDialerCall", "AutoRedial: ACTION_CALL failed", e)
                            cancelAutoRedial()
                        }
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    android.util.Log.d("EverDialerCall", "AutoRedial: coroutine cancelled")
                }
            }
        }

        private var instance: CallService? = null

        @Volatile private var isMerging = false

        fun setMuted(muted: Boolean) {
            instance?.let { service ->
                try { service.setMuted(muted) } catch (_: Throwable) {}
                try {
                    val am = service.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.isMicrophoneMute = muted
                } catch (_: Throwable) {}
                val current = _audioState.value
                val route = current?.route ?: CallAudioState.ROUTE_EARPIECE
                val mask = current?.supportedRouteMask ?: (CallAudioState.ROUTE_EARPIECE or CallAudioState.ROUTE_SPEAKER or CallAudioState.ROUTE_BLUETOOTH or CallAudioState.ROUTE_WIRED_HEADSET)
                _audioState.value = CallAudioState(muted, route, mask)
            }
        }

        fun setAudioRoute(route: Int) {
            instance?.let { service ->
                try { service.setAudioRoute(route) } catch (_: Throwable) {}
                try {
                    val am = service.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        if (route == CallAudioState.ROUTE_SPEAKER) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val speakerDev = am.availableCommunicationDevices.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                                if (speakerDev != null) am.setCommunicationDevice(speakerDev)
                            }
                            am.isSpeakerphoneOn = true
                        } else if (route == CallAudioState.ROUTE_EARPIECE) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val earDev = am.availableCommunicationDevices.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
                                if (earDev != null) am.setCommunicationDevice(earDev) else am.clearCommunicationDevice()
                            }
                            am.isSpeakerphoneOn = false
                        }
                    }
                } catch (_: Throwable) {}
                val current = _audioState.value
                val mask = current?.supportedRouteMask ?: (CallAudioState.ROUTE_EARPIECE or CallAudioState.ROUTE_SPEAKER or CallAudioState.ROUTE_BLUETOOTH or CallAudioState.ROUTE_WIRED_HEADSET)
                val isMuted = current?.isMuted ?: false
                _audioState.value = CallAudioState(isMuted, route, mask)
            }
        }

        fun requestBluetoothAudio(device: BluetoothDevice) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    instance?.requestBluetoothAudio(device)
                } catch (_: Throwable) {}
            }
        }

        private fun shouldLaunchOngoingCallUi(context: Context): Boolean {
            val pm = PreferenceManager(context)
            val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            val isLocked = km?.isKeyguardLocked == true
            val showOnLock = pm.getBoolean(PreferenceManager.KEY_SHOW_ONGOING_CALL_UI_ON_LOCKSCREEN_WHEN_ANSWERED, true)
            val showUiUnlocked = pm.getBoolean(PreferenceManager.KEY_SHOW_ONGOING_CALL_UI_WHEN_ANSWERED, true)
            return if (isLocked) showOnLock else showUiUnlocked
        }

        fun answerCall() {
            val incoming = _incomingCallSession.value?.call
            if (incoming != null) {
                answerCallHoldingCurrent()
                return
            }
            val call = _currentCallSession.value?.call
                ?: _heldCallSession.value?.call
                ?: instance?.calls?.find { it.state == Call.STATE_RINGING }
                ?: instance?.calls?.firstOrNull()
            try {
                call?.answer(VideoProfile.STATE_AUDIO_ONLY)
            } catch (_: Exception) {}
            try {
                instance?.let { s ->
                    if (shouldLaunchOngoingCallUi(s)) {
                        s.launchCallActivity(answeredFromNotification = true)
                    }
                }
            } catch (_: Exception) {}
        }

        fun declineCall() {
            cancelAutoRedial()
            val incoming = _incomingCallSession.value?.call
            if (incoming != null) {
                try {
                    incoming.disconnect()
                } catch (_: Exception) {}
                _incomingCallSession.value = null
                _currentCallSession.value?.call?.let { instance?.updateNotification(it) }
                return
            }
            val call = _currentCallSession.value?.call
                ?: _heldCallSession.value?.call
                ?: instance?.calls?.firstOrNull()
            try {
                call?.disconnect()
            } catch (_: Exception) {}
        }

        fun switchToWhatsAppVideo(context: Context, phoneNumber: String = "") {
            cancelAutoRedial()
            val call = _currentCallSession.value?.call
                ?: _heldCallSession.value?.call
                ?: instance?.calls?.firstOrNull()
            val targetNumber = phoneNumber.takeIf { it.isNotBlank() }
                ?: call?.details?.handle?.schemeSpecificPart
                ?: ""
            if (call != null) {
                suppressPostCallPopup = true
            }
            try {
                call?.disconnect()
            } catch (_: Exception) {
                suppressPostCallPopup = false
            }
            com.modiprincekr.thedialer.controller.util.launchDirectWhatsAppVideoCall(context, targetNumber)
        }

        fun answerCallHoldingCurrent() {
            val incoming = _incomingCallSession.value?.call ?: return
            val current = _currentCallSession.value?.call
            val service = instance ?: return
            try {
                if (current != null && current.state != Call.STATE_HOLDING) {
                    current.hold()
                    current.unregisterCallback(service.callCallback)
                    current.registerCallback(service.heldCallCallback)
                    _heldCallSession.value = CallSession(current, Call.STATE_HOLDING)
                }
            } catch (_: Exception) {}

            try {
                incoming.unregisterCallback(service.incomingCallCallback)
                incoming.registerCallback(service.callCallback)
                incoming.answer(VideoProfile.STATE_AUDIO_ONLY)
                _currentCallSession.value = CallSession(incoming, Call.STATE_ACTIVE)
                _incomingCallSession.value = null
            } catch (_: Exception) {}

            try {
                service.updateNotification(incoming)
                if (shouldLaunchOngoingCallUi(service)) {
                    service.launchCallActivity(answeredFromNotification = true)
                }
            } catch (_: Exception) {}
        }

        fun answerCallEndingCurrent() {
            val incoming = _incomingCallSession.value?.call ?: return
            val current = _currentCallSession.value?.call
            val service = instance ?: return
            try {
                current?.disconnect()
            } catch (_: Exception) {}

            try {
                incoming.unregisterCallback(service.incomingCallCallback)
                incoming.registerCallback(service.callCallback)
                incoming.answer(VideoProfile.STATE_AUDIO_ONLY)
                _currentCallSession.value = CallSession(incoming, Call.STATE_ACTIVE)
                _incomingCallSession.value = null
            } catch (_: Exception) {}

            try {
                service.updateNotification(incoming)
                if (shouldLaunchOngoingCallUi(service)) {
                    service.launchCallActivity(answeredFromNotification = true)
                }
            } catch (_: Exception) {}
        }

        fun swapCalls() {
            val active = _currentCallSession.value?.call ?: return
            val held = _heldCallSession.value?.call ?: return
            val service = instance ?: return
            try {
                active.hold()
                active.unregisterCallback(service.callCallback)
                active.registerCallback(service.heldCallCallback)

                held.unhold()
                held.unregisterCallback(service.heldCallCallback)
                held.registerCallback(service.callCallback)

                _currentCallSession.value = CallSession(held, Call.STATE_ACTIVE)
                _heldCallSession.value = CallSession(active, Call.STATE_HOLDING)
                service.updateNotification(held)
            } catch (_: Exception) {}
        }

        fun syncCallSessions() {
            val service = instance ?: return
            val allCalls = try { service.calls } catch (_: Throwable) { emptyList() }
            if (allCalls.isEmpty()) return

            val confCall = allCalls.find {
                it.state != Call.STATE_DISCONNECTED && (
                    it.details?.hasProperty(Call.Details.PROPERTY_CONFERENCE) == true || it.children.isNotEmpty()
                )
            }

            if (confCall != null) {
                _currentCallSession.value = CallSession(confCall, confCall.state)
                try {
                    confCall.unregisterCallback(service.callCallback)
                    confCall.registerCallback(service.callCallback)
                } catch (_: Throwable) {}
                val heldCall = _heldCallSession.value?.call
                if (heldCall != null && (heldCall.parent == confCall || confCall.children.contains(heldCall) || heldCall.state == Call.STATE_DISCONNECTED)) {
                    _heldCallSession.value = null
                }
                val children = confCall.children
                val num1 = children.getOrNull(0)?.details?.handle?.schemeSpecificPart
                val num2 = children.getOrNull(1)?.details?.handle?.schemeSpecificPart
                if (!num1.isNullOrBlank() && !num2.isNullOrBlank()) {
                    com.modiprincekr.thedialer.controller.call.MultiCallRecordStore.recordMultiCall(
                        service, num1, null, num2, null, isMerged = true
                    )
                    com.coolappstore.everdialer.by.svhp.feature.AppFeatures.updateMultiCall(service, num2, isMerged = true)
                }
                service.updateNotification(confCall)
                return
            }

            val activeCall = allCalls.find { it.state == Call.STATE_ACTIVE || it.state == Call.STATE_DIALING || it.state == Call.STATE_CONNECTING }
            val heldCall = allCalls.find { it.state == Call.STATE_HOLDING && it.parent == null }
            val ringingCall = allCalls.find { it.state == Call.STATE_RINGING }

            if (activeCall != null && heldCall != null) {
                val num1 = activeCall.details?.handle?.schemeSpecificPart
                val num2 = heldCall.details?.handle?.schemeSpecificPart
                if (!num1.isNullOrBlank() && !num2.isNullOrBlank()) {
                    com.modiprincekr.thedialer.controller.call.MultiCallRecordStore.recordMultiCall(
                        service, num1, null, num2, null, isMerged = false
                    )
                    com.coolappstore.everdialer.by.svhp.feature.AppFeatures.updateMultiCall(service, num2, isMerged = false)
                }
            }

            if (activeCall != null && _currentCallSession.value?.call != activeCall) {
                _currentCallSession.value = CallSession(activeCall, activeCall.state)
                try {
                    activeCall.unregisterCallback(service.callCallback)
                    activeCall.registerCallback(service.callCallback)
                } catch (_: Throwable) {}
                service.updateNotification(activeCall)
            }
            if (heldCall != null) {
                if (_heldCallSession.value?.call != heldCall) {
                    _heldCallSession.value = CallSession(heldCall, heldCall.state)
                    try {
                        heldCall.unregisterCallback(service.heldCallCallback)
                        heldCall.registerCallback(service.heldCallCallback)
                    } catch (_: Throwable) {}
                }
            } else if (_heldCallSession.value?.call?.state == Call.STATE_DISCONNECTED || _heldCallSession.value?.call?.parent != null) {
                _heldCallSession.value = null
            }
            if (ringingCall != null && _incomingCallSession.value?.call != ringingCall) {
                _incomingCallSession.value = CallSession(ringingCall, ringingCall.state)
                try {
                    ringingCall.unregisterCallback(service.incomingCallCallback)
                    ringingCall.registerCallback(service.incomingCallCallback)
                } catch (_: Throwable) {}
            }
        }

        fun mergeCalls() {
            val primary = _currentCallSession.value?.call
                ?: instance?.calls?.find { it.state == Call.STATE_ACTIVE }
                ?: return
            val secondary = _heldCallSession.value?.call
                ?: instance?.calls?.find { it.state == Call.STATE_HOLDING }
                ?: return

            if (primary == secondary) return
            isMerging = true

            val num1 = primary.details?.handle?.schemeSpecificPart
            val num2 = secondary.details?.handle?.schemeSpecificPart
            val svc = instance
            if (!num1.isNullOrBlank() && !num2.isNullOrBlank() && svc != null) {
                com.modiprincekr.thedialer.controller.call.MultiCallRecordStore.recordMultiCall(
                    svc, num1, null, num2, null, isMerged = true
                )
                com.coolappstore.everdialer.by.svhp.feature.AppFeatures.updateMultiCall(svc, num2, isMerged = true)
            }

            android.util.Log.d(
                "EverDialerCall",
                "mergeCalls: starting merge. primary=$primary state=${primary.state} caps=${primary.details?.callCapabilities}, " +
                    "secondary=$secondary state=${secondary.state} caps=${secondary.details?.callCapabilities}"
            )

            var mergeTriggered = false

            // 1. If telecom framework explicitly lists the other call as conferenceable, use conference()
            try {
                if (primary.conferenceableCalls.contains(secondary)) {
                    android.util.Log.d("EverDialerCall", "mergeCalls: primary.conference(secondary)")
                    primary.conference(secondary)
                    mergeTriggered = true
                } else if (secondary.conferenceableCalls.contains(primary)) {
                    android.util.Log.d("EverDialerCall", "mergeCalls: secondary.conference(primary)")
                    secondary.conference(primary)
                    mergeTriggered = true
                }
            } catch (t: Throwable) {
                android.util.Log.w("EverDialerCall", "mergeCalls: conferenceableCalls attempt threw", t)
            }

            // 2. Check CAPABILITY_MERGE_CONFERENCE (standard for VoLTE/IMS and CDMA carriers)
            if (!mergeTriggered) {
                try {
                    val primaryCanMerge = primary.details?.can(Call.Details.CAPABILITY_MERGE_CONFERENCE) == true
                    val secondaryCanMerge = secondary.details?.can(Call.Details.CAPABILITY_MERGE_CONFERENCE) == true
                    android.util.Log.d("EverDialerCall", "mergeCalls: primaryCanMerge=$primaryCanMerge, secondaryCanMerge=$secondaryCanMerge")
                    if (primaryCanMerge) {
                        primary.mergeConference()
                        mergeTriggered = true
                    } else if (secondaryCanMerge) {
                        secondary.mergeConference()
                        mergeTriggered = true
                    }
                } catch (t: Throwable) {
                    android.util.Log.w("EverDialerCall", "mergeCalls: mergeConference capability attempt threw", t)
                }
            }

            // 3. Fallbacks: try mergeConference then conference in both directions
            if (!mergeTriggered) {
                try {
                    android.util.Log.d("EverDialerCall", "mergeCalls: fallback trying primary.mergeConference()")
                    primary.mergeConference()
                    mergeTriggered = true
                } catch (t1: Throwable) {
                    try {
                        android.util.Log.d("EverDialerCall", "mergeCalls: fallback trying secondary.mergeConference()")
                        secondary.mergeConference()
                        mergeTriggered = true
                    } catch (t2: Throwable) {
                        try {
                            android.util.Log.d("EverDialerCall", "mergeCalls: fallback trying primary.conference(secondary)")
                            primary.conference(secondary)
                            mergeTriggered = true
                        } catch (t3: Throwable) {
                            try {
                                android.util.Log.d("EverDialerCall", "mergeCalls: fallback trying secondary.conference(primary)")
                                secondary.conference(primary)
                                mergeTriggered = true
                            } catch (t4: Throwable) {
                                android.util.Log.e("EverDialerCall", "mergeCalls: all merge attempts failed", t4)
                                isMerging = false
                            }
                        }
                    }
                }
            }

            // Check if merge completed after delay
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                syncCallSessions()
                if (isMerging) {
                    isMerging = false
                    syncCallSessions()
                }
            }, 1200)

            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (isMerging) {
                    isMerging = false
                    syncCallSessions()
                }
            }, 3000)
        }

        fun hasHeldCall(): Boolean = _heldCallSession.value != null && _heldCallSession.value?.state == Call.STATE_HOLDING
        fun hasIncomingCall(): Boolean = _incomingCallSession.value != null && _incomingCallSession.value?.state == Call.STATE_RINGING
    }

    // Callback for the primary (active/dialing) call
    private val callCallback: Call.Callback = object : Call.Callback() {
        override fun onChildrenChanged(call: Call, children: MutableList<Call>?) {
            super.onChildrenChanged(call, children)
            android.util.Log.d("EverDialerCall", "callCallback onChildrenChanged call=$call childrenCount=${children?.size}")
            isMerging = false
            syncCallSessions()
        }

        override fun onParentChanged(call: Call, parent: Call?) {
            super.onParentChanged(call, parent)
            android.util.Log.d("EverDialerCall", "callCallback onParentChanged call=$call parent=$parent")
            isMerging = false
            syncCallSessions()
        }

        override fun onConferenceableCallsChanged(call: Call, conferenceableCalls: MutableList<Call>?) {
            super.onConferenceableCallsChanged(call, conferenceableCalls)
            android.util.Log.d("EverDialerCall", "callCallback onConferenceableCallsChanged call=$call count=${conferenceableCalls?.size}")
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            super.onDetailsChanged(call, details)
            val isConf = details.hasProperty(Call.Details.PROPERTY_CONFERENCE)
            if (isConf) {
                isMerging = false
                syncCallSessions()
            }
            // The call's handle/caller info can arrive or change AFTER onCallAdded (e.g. some
            // carriers/OEMs deliver the ringing call before its number is attached, or update
            // caller ID data slightly later). Since the notification and the incoming/ongoing
            // call UI both derive the displayed name from call.details.handle at the moment
            // they're built, missing this callback meant they never re-resolved the contact
            // once the number showed up — leaving the name blank even though the call log
            // (built later, once the call ends) resolved it fine. Refresh both here.
            if (_currentCallSession.value?.call == call) {
                _currentCallSession.value = CallSession(call, call.state)
                updateNotification(call)
            } else if (_heldCallSession.value?.call == call) {
                _heldCallSession.value = CallSession(call, call.state)
                updateNotification(call)
            }
        }

        override fun onConnectionEvent(call: Call, event: String, extras: android.os.Bundle?) {
            super.onConnectionEvent(call, event, extras)
            val number = call.details?.handle?.schemeSpecificPart?.let { android.net.Uri.decode(it) } ?: ""
            if (isUssdNumber(number)) {
                val resp = extras?.let { b ->
                    b.getString("ussdResult") ?: b.getString("android.telecom.extra.ussd_message")
                    ?: b.getString("android.telephony.extra.USSD_RESPONSE")
                    ?: b.getString("response") ?: b.getString("result") ?: b.getString("data") ?: b.getString("message")
                }
                if (!resp.isNullOrBlank()) UssdRepository.post(number, resp)
            }
        }

        override fun onStateChanged(call: Call, state: Int) {
            super.onStateChanged(call, state)

            android.util.Log.d(
                "EverDialerCall",
                "call state -> ${stateName(state)} number=${call.details?.handle} account=${call.details?.accountHandle}"
            )

            RaiseToAnswerManager.onCallStateChanged(this@CallService, call)
            RainModeManager.onCallStateChanged(this@CallService, call)

            // Normal state update
            when {
                _currentCallSession.value?.call == call -> _currentCallSession.value = CallSession(call, state)
                _heldCallSession.value?.call == call   -> _heldCallSession.value   = CallSession(call, state)
            }

            if (state == Call.STATE_SELECT_PHONE_ACCOUNT) {
                val num = call.details?.handle?.schemeSpecificPart?.let { android.net.Uri.decode(it) } ?: ""
                handleSelectPhoneAccount(call, num)
                return
            }

            if (pendingAccountSelectionCalls.contains(call)) {
                if (state == Call.STATE_DIALING || state == Call.STATE_CONNECTING || state == Call.STATE_ACTIVE) {
                    pendingAccountSelectionCalls.remove(call)
                    updateNotification(call)
                    launchCallActivity()
                } else if (state == Call.STATE_DISCONNECTED) {
                    pendingAccountSelectionCalls.remove(call)
                }
            }

            if (state == Call.STATE_RINGING) {
                callRingStartTimes.getOrPut(call) { System.currentTimeMillis() }
                com.modiprincekr.thedialer.haptics.RingHapticManager.startIncomingCallHaptics(this@CallService)
            } else if (state == Call.STATE_ACTIVE || state == Call.STATE_DIALING) {
                com.modiprincekr.thedialer.haptics.RingHapticManager.stopIncomingCallHaptics()
                if (state == Call.STATE_ACTIVE) {
                    cancelAutoRedial()
                    callAnsweredSet.add(call)
                    callConnectTimes.getOrPut(call) { System.currentTimeMillis() }
                    com.coolappstore.everdialer.by.svhp.feature.AppFeatures.onCallAnswered(this@CallService)
                }
                applyDefaultAudioRouting(call)
            }

            if (state == Call.STATE_DISCONNECTED) {
                com.modiprincekr.thedialer.haptics.RingHapticManager.stopIncomingCallHaptics()
                defaultAudioAppliedForCall.remove(call)
                recordMissedCallDurationIfNeeded(call)
                val cause = call.details?.disconnectCause
                val causeCode = cause?.code ?: DisconnectCause.UNKNOWN
                android.util.Log.w(
                    "EverDialerCall",
                    "call DISCONNECTED number=${call.details?.handle} code=$causeCode " +
                        "label=${cause?.label} description=${cause?.description} reason=${cause?.reason}"
                )

                // ── Auto Redial Loop Evaluation ──
                val isRedialCause = causeCode == DisconnectCause.BUSY ||
                                    causeCode == DisconnectCause.REJECTED ||
                                    causeCode == DisconnectCause.MISSED ||
                                    causeCode == DisconnectCause.REMOTE
                val targetUri = call.details?.handle
                val accountHandle = call.details?.accountHandle

                if (isAutoRedialActive.value && isRedialCause && targetUri != null) {
                    scheduleAutoRedial(this@CallService, targetUri, accountHandle)
                } else if (!isAutoRedialActive.value || !isRedialCause) {
                    cancelAutoRedial()
                }

                if (_currentCallSession.value?.call == call) {
                    _currentCallSession.value = null
                    val incoming = _incomingCallSession.value
                    val held = _heldCallSession.value
                    if (incoming != null) {
                        _incomingCallSession.value = null
                        incoming.call.unregisterCallback(incomingCallCallback)
                        incoming.call.registerCallback(callCallback)
                        _currentCallSession.value = CallSession(incoming.call, incoming.call.state)
                        updateNotification(incoming.call)
                    } else if (held != null) {
                        _heldCallSession.value = null
                        held.call.unregisterCallback(heldCallCallback)
                        held.call.registerCallback(callCallback)
                        _currentCallSession.value = CallSession(held.call, held.call.state)
                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                            try { held.call.unhold() } catch (_: Exception) {}
                        }, 300)
                    }
                } else if (_heldCallSession.value?.call == call) {
                    _heldCallSession.value = null
                }
                if (_currentCallSession.value == null) {
                    if (!isAutoRedialActive.value) {
                        removeForeground()
                        cancelNotification()
                    }
                }
            } else {
                updateNotification(call)
            }
        }
    }

    private val heldCallCallback: Call.Callback = object : Call.Callback() {
        override fun onChildrenChanged(call: Call, children: MutableList<Call>?) {
            super.onChildrenChanged(call, children)
            android.util.Log.d("EverDialerCall", "heldCallCallback onChildrenChanged call=$call childrenCount=${children?.size}")
            isMerging = false
            syncCallSessions()
        }

        override fun onParentChanged(call: Call, parent: Call?) {
            super.onParentChanged(call, parent)
            android.util.Log.d("EverDialerCall", "heldCallCallback onParentChanged call=$call parent=$parent")
            isMerging = false
            syncCallSessions()
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            super.onDetailsChanged(call, details)
            val isConf = details.hasProperty(Call.Details.PROPERTY_CONFERENCE)
            if (isConf) {
                isMerging = false
                syncCallSessions()
            }
            if (_heldCallSession.value?.call == call) {
                _heldCallSession.value = CallSession(call, call.state)
                updateNotification(call)
            }
        }

        override fun onStateChanged(call: Call, state: Int) {
            super.onStateChanged(call, state)
            RaiseToAnswerManager.onCallStateChanged(this@CallService, call)
            RainModeManager.onCallStateChanged(this@CallService, call)
            if (state == Call.STATE_RINGING) {
                callRingStartTimes.getOrPut(call) { System.currentTimeMillis() }
            } else if (state == Call.STATE_ACTIVE) {
                cancelAutoRedial()
                callAnsweredSet.add(call)
                callConnectTimes.getOrPut(call) { System.currentTimeMillis() }
            }
            _heldCallSession.value = CallSession(call, state)
            if (state == Call.STATE_DISCONNECTED) {
                recordMissedCallDurationIfNeeded(call)
                _heldCallSession.value = null
            } else {
                updateNotification(call)
            }
        }
    }

    private val incomingCallCallback: Call.Callback = object : Call.Callback() {
        override fun onDetailsChanged(call: Call, details: Call.Details) {
            super.onDetailsChanged(call, details)
            if (_incomingCallSession.value?.call == call) {
                _incomingCallSession.value = CallSession(call, call.state)
                updateNotification(call)
            }
        }

        override fun onStateChanged(call: Call, state: Int) {
            super.onStateChanged(call, state)
            RaiseToAnswerManager.onCallStateChanged(this@CallService, call)
            RainModeManager.onCallStateChanged(this@CallService, call)
            if (state == Call.STATE_RINGING) {
                callRingStartTimes.getOrPut(call) { System.currentTimeMillis() }
                _incomingCallSession.value = CallSession(call, state)
                updateNotification(call)
                com.modiprincekr.thedialer.haptics.RingHapticManager.startIncomingCallHaptics(this@CallService)
            } else if (state == Call.STATE_ACTIVE) {
                cancelAutoRedial()
                com.modiprincekr.thedialer.haptics.RingHapticManager.stopIncomingCallHaptics()
                callAnsweredSet.add(call)
                callConnectTimes.getOrPut(call) { System.currentTimeMillis() }
                _incomingCallSession.value = null
                _currentCallSession.value = CallSession(call, state)
                updateNotification(call)
            } else if (state == Call.STATE_DISCONNECTED) {
                com.modiprincekr.thedialer.haptics.RingHapticManager.stopIncomingCallHaptics()
                recordMissedCallDurationIfNeeded(call)
                _incomingCallSession.value = null
                _currentCallSession.value?.call?.let { updateNotification(it) }
            }
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        com.modiprincekr.thedialer.haptics.RingHapticManager.stopIncomingCallHaptics()
        RaiseToAnswerManager.stop(this)
        RainModeManager.onCallStateChanged(this, call)
        recordMissedCallDurationIfNeeded(call)
        call.unregisterCallback(callCallback)
        call.unregisterCallback(heldCallCallback)
        call.unregisterCallback(incomingCallCallback)
        callConnectTimes.remove(call)
        pendingAccountSelectionCalls.remove(call)

        if (_incomingCallSession.value?.call == call) {
            _incomingCallSession.value = null
            _currentCallSession.value?.call?.let { updateNotification(it) }
            return
        }

        if (isMerging) {
            if (_heldCallSession.value?.call == call) {
                _heldCallSession.value = null
            }
            if (_currentCallSession.value?.call == call) {
                val remaining = try { calls.filter { it != call && it.state != Call.STATE_DISCONNECTED } } catch (_: Throwable) { emptyList() }
                val conf = remaining.find { it.details?.hasProperty(Call.Details.PROPERTY_CONFERENCE) == true || it.children.isNotEmpty() }
                val nextActive = conf ?: remaining.find { it.state == Call.STATE_ACTIVE } ?: remaining.firstOrNull()
                if (nextActive != null) {
                    _currentCallSession.value = CallSession(nextActive, nextActive.state)
                    try {
                        nextActive.unregisterCallback(callCallback)
                        nextActive.registerCallback(callCallback)
                    } catch (_: Throwable) {}
                    updateNotification(nextActive)
                } else {
                    _currentCallSession.value = null
                }
            }
            if (_currentCallSession.value != null) {
                return
            }
        }

        // Normal removal — if the current call is removed, promote held call if any
        if (_currentCallSession.value?.call == call) {
            _currentCallSession.value = null
            _heldCallSession.value?.let { held ->
                _heldCallSession.value = null
                held.call.unregisterCallback(heldCallCallback)
                held.call.registerCallback(callCallback)
                _currentCallSession.value = CallSession(held.call, held.call.state)
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    try { held.call.unhold() } catch (_: Exception) {}
                }, 300)
            }
        } else if (_heldCallSession.value?.call == call) {
            _heldCallSession.value = null
        }

        if (_currentCallSession.value == null) {
            com.modiprincekr.thedialer.controller.call.MultiCallRecordStore.endMultiCall(this)
            if (!isAutoRedialActive.value) {
                instance = null
                removeForeground()
                cancelNotification()
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.mode = AudioManager.MODE_NORMAL
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        am?.clearCommunicationDevice()
                    }
                } catch (_: Throwable) {}
            }
        }

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try {
                org.koin.core.context.GlobalContext.get().getOrNull<com.modiprincekr.thedialer.controller.CallLogViewModel>()?.refreshLogs()
            } catch (_: Throwable) {}
            try {
                com.modiprincekr.thedialer.controller.util.MissedCallBadgeManager.updateBadge(this)
            } catch (_: Exception) {}
            try {
                org.koin.core.context.GlobalContext.get().getOrNull<com.modiprincekr.thedialer.controller.util.PcBluetoothSyncManager>()?.triggerImmediateSync()
            } catch (_: Throwable) {}
        }, 300)
    }

    private fun removeForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
    }

    /** Returns true for any MMI / USSD code like *124# *#06# ##002# *21*N# */
    private fun isUssdNumber(number: String): Boolean {
        if (number.isBlank()) return false
        val n = android.net.Uri.decode(number).trim()
        return (n.startsWith("*") || n.startsWith("#")) && n.endsWith("#")
    }

    private fun isNumberBlocked(number: String): Boolean =
        com.modiprincekr.thedialer.controller.util.BlockedNumbersManager.isBlocked(this, prefs, number)

    private fun launchCallActivity(answeredFromNotification: Boolean = false) {
        val intent = Intent(this, CallActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            if (answeredFromNotification) putExtra("ANSWERED_FROM_NOTIFICATION", true)
        }
        startActivity(intent)
    }

    private fun launchBiometricCallActivity(action: String) {
        val intent = Intent(this, BiometricCallActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("NOTIFICATION_PENDING_ACTION", action)
        }
        startActivity(intent)
    }

    private fun stateName(state: Int): String = when (state) {
        Call.STATE_NEW -> "NEW"
        Call.STATE_RINGING -> "RINGING"
        Call.STATE_DIALING -> "DIALING"
        Call.STATE_ACTIVE -> "ACTIVE"
        Call.STATE_HOLDING -> "HOLDING"
        Call.STATE_DISCONNECTED -> "DISCONNECTED"
        Call.STATE_CONNECTING -> "CONNECTING"
        Call.STATE_DISCONNECTING -> "DISCONNECTING"
        Call.STATE_SELECT_PHONE_ACCOUNT -> "SELECT_PHONE_ACCOUNT"
        Call.STATE_PULLING_CALL -> "PULLING_CALL"
        Call.STATE_AUDIO_PROCESSING -> "AUDIO_PROCESSING"
        Call.STATE_SIMULATED_RINGING -> "SIMULATED_RINGING"
        else -> "UNKNOWN($state)"
    }

    private fun handleSelectPhoneAccount(call: Call, number: String) {
        pendingAccountSelectionCalls.add(call)
        val telecomManager = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val availableAccounts = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            call.details?.intentExtras?.getParcelableArrayList<PhoneAccountHandle>(Call.AVAILABLE_PHONE_ACCOUNTS)
        } else null
        val accounts = availableAccounts?.takeIf { it.isNotEmpty() }
            ?: (try { telecomManager?.callCapablePhoneAccounts } catch (_: Throwable) { null })
            ?: emptyList()

        var autoSelected = false
        if (accounts.size == 1) {
            try {
                call.phoneAccountSelected(accounts[0], false)
                autoSelected = true
            } catch (_: Throwable) {}
        } else if (accounts.size > 1) {
            val cleanNum = number.trim()
            val contactKey = try { contactsRepository.getContactByNumber(cleanNum)?.id } catch (_: Exception) { null } ?: cleanNum
            val contactSimChoice = prefs.getContactSimChoice(contactKey, cleanNum)
            val globalSimPref = prefs.getInt(PreferenceManager.KEY_DEFAULT_SIM, prefs.getDefaultSimIndexDefault())
            val useSimFromCallLog = getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)
                .getBoolean(PreferenceManager.KEY_USE_SIM_FROM_CALL_LOG, false)
            val targetAccount = when (contactSimChoice) {
                PreferenceManager.SIM_CHOICE_SIM1 -> com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, 0)
                PreferenceManager.SIM_CHOICE_SIM2 -> com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, 1)
                PreferenceManager.SIM_CHOICE_CALL_LOG,
                PreferenceManager.SIM_CHOICE_LAST_FOR_CONTACT -> {
                    val slot = com.modiprincekr.thedialer.controller.util.queryRecentSimSlot(this, cleanNum)
                    if (slot != null) com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, slot) else null
                }
                PreferenceManager.SIM_CHOICE_LAST_IN_CALL -> {
                    val lastIdx = getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)
                        .getInt(PreferenceManager.KEY_LAST_USED_SIM_GLOBAL, 0)
                    if (lastIdx in 1..2) com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, lastIdx - 1)
                    else if (lastIdx in 1..accounts.size) accounts[lastIdx - 1]
                    else null
                }
                PreferenceManager.SIM_CHOICE_SETTINGS -> {
                    if (useSimFromCallLog || globalSimPref == 3) {
                        val slot = com.modiprincekr.thedialer.controller.util.queryRecentSimSlot(this, cleanNum)
                        if (slot != null) com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, slot)
                        else when (globalSimPref) {
                            1 -> com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, 0)
                            2 -> com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, 1)
                            else -> null
                        }
                    } else {
                        when (globalSimPref) {
                            1 -> com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, 0)
                            2 -> com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot(this, accounts, 1)
                            else -> null
                        }
                    }
                }
                else -> null // SIM_CHOICE_ASK
            }
            if (targetAccount != null) {
                try {
                    call.phoneAccountSelected(targetAccount, false)
                    autoSelected = true
                } catch (_: Throwable) {}
            }
        }

        if (!autoSelected) {
            updateNotification(call)
            launchCallActivity()
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        instance = this
        val direction = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) call.details?.callDirection else null
        android.util.Log.d(
            "EverDialerCall",
            "onCallAdded number=${call.details?.handle} state=${stateName(call.state)} " +
                "account=${call.details?.accountHandle} isOutgoing=$direction"
        )

        // WhatsApp registers its voice/video calls as a self-managed Telecom
        // connection. Because this InCallService declares
        // INCLUDE_SELF_MANAGED_CALLS, Telecom hands those calls to us too —
        // but The Dialer must never touch them: no callback, no notification,
        // no CallActivity, no missed-call alert. Bail out immediately so
        // WhatsApp's own call UI is left completely alone.
        if (isWhatsAppCall(call)) return

        val number = call.details.handle?.schemeSpecificPart
            ?.let { android.net.Uri.decode(it) } ?: ""

        // ── USSD / MMI outgoing calls ────────────────────────────────────────
        // Do NOT launch CallActivity for codes like *124# *#06# ##002# *21*N#.
        // com.android.phone owns MMI/USSD processing at the RIL level and shows
        // its own system dialog — just return and let it handle everything.
        val isUssd = call.state != Call.STATE_RINGING && isUssdNumber(number)
        if (isUssd) return
        // ────────────────────────────────────────────────────────────────────

        if (prefs.getBoolean(PreferenceManager.KEY_SILENCE_UNKNOWN, false) && number.isBlank() && call.state == Call.STATE_RINGING) {
            call.disconnect(); return
        }
        if (number.isNotBlank() && call.state == Call.STATE_RINGING && isNumberBlocked(number)) {
            val callDate = call.details?.creationTimeMillis?.takeIf { it > 0 } ?: System.currentTimeMillis()
            val ringDurationSec = ((System.currentTimeMillis() - callDate) / 1000L).coerceIn(1L, 60L)
            com.modiprincekr.thedialer.controller.util.MissedCallDurationStore.saveDuration(
                this, number, callDate, ringDurationSec
            )
            com.modiprincekr.thedialer.controller.util.MissedCallDurationStore.updateProviderBlockedCall(
                this, number, ringDurationSec, callDate
            )
            call.disconnect()
            return
        }

        if (call.state == Call.STATE_RINGING) {
            callRingStartTimes.getOrPut(call) { System.currentTimeMillis() }
            RaiseToAnswerManager.onCallStateChanged(this, call)
            RainModeManager.onCallStateChanged(this, call)
            com.modiprincekr.thedialer.haptics.RingHapticManager.startIncomingCallHaptics(this)
        } else {
            RainModeManager.onCallStateChanged(this, call)
        }

        val isConference = call.details?.hasProperty(Call.Details.PROPERTY_CONFERENCE) == true || call.children.isNotEmpty()
        if (isConference || isMerging) {
            isMerging = false
            try {
                call.unregisterCallback(callCallback)
                call.registerCallback(callCallback)
            } catch (_: Throwable) {}
            _currentCallSession.value = CallSession(call, call.state)
            _heldCallSession.value = null
            updateNotification(call)
            launchCallActivity()
            return
        }

        if (_currentCallSession.value != null && _currentCallSession.value?.state != Call.STATE_DISCONNECTED) {
            if (call.state != Call.STATE_RINGING) {
                // Second outgoing call (from "Add to call" or user-initiated)
                val prev = _currentCallSession.value
                if (prev != null && prev.call != call) {
                    try { if (prev.call.state != Call.STATE_HOLDING) prev.call.hold() } catch (_: Exception) {}
                    prev.call.unregisterCallback(callCallback)
                    prev.call.registerCallback(heldCallCallback)
                    _heldCallSession.value = CallSession(prev.call, Call.STATE_HOLDING)
                }
                call.registerCallback(callCallback)
                _currentCallSession.value = CallSession(call, call.state)
                if (call.state == Call.STATE_SELECT_PHONE_ACCOUNT) {
                    handleSelectPhoneAccount(call, number)
                    return
                }
                updateNotification(call)
                launchCallActivity()
            } else {
                // Incoming second call (Call Waiting)
                call.registerCallback(incomingCallCallback)
                _incomingCallSession.value = CallSession(call, call.state)
                updateNotification(call)
                if (prefs.getBoolean(PreferenceManager.KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS, false)) {
                    launchCallActivity()
                }
            }
            return
        }

        call.registerCallback(callCallback)
        _currentCallSession.value = CallSession(call, call.state)
        if (call.state == Call.STATE_SELECT_PHONE_ACCOUNT) {
            handleSelectPhoneAccount(call, number)
            return
        }
        if (call.state == Call.STATE_DIALING || call.state == Call.STATE_CONNECTING || call.state == Call.STATE_ACTIVE) {
            applyDefaultAudioRouting(call)
        }
        updateNotification(call)
        if (call.state != Call.STATE_RINGING) {
            launchCallActivity()
        } else if (prefs.getBoolean(PreferenceManager.KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS, false)) {
            launchCallActivity()
        }
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        _audioState.value = audioState
        // Rebuild notification so mute/speaker button labels stay in sync
        _currentCallSession.value?.call?.let { updateNotification(it) }

        audioState?.let { state ->
            val currentPref = prefs.getString(PreferenceManager.KEY_LAST_USED_SPEAKER_ROUTE, "")
            val speakerVal = when (state.route) {
                CallAudioState.ROUTE_BLUETOOTH -> PreferenceManager.SPEAKER_ROUTE_EXTERNAL
                CallAudioState.ROUTE_WIRED_HEADSET -> {
                    if (currentPref == PreferenceManager.SPEAKER_ROUTE_EAR) {
                        PreferenceManager.SPEAKER_ROUTE_EAR
                    } else {
                        PreferenceManager.SPEAKER_ROUTE_EXTERNAL
                    }
                }
                CallAudioState.ROUTE_SPEAKER -> PreferenceManager.SPEAKER_ROUTE_SPEAKER
                CallAudioState.ROUTE_EARPIECE -> PreferenceManager.SPEAKER_ROUTE_EAR
                else -> null
            }
            if (speakerVal != null) {
                prefs.setString(PreferenceManager.KEY_LAST_USED_SPEAKER_ROUTE, speakerVal)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "ANSWER_CALL"  -> {
                val ringingNumber = _incomingCallSession.value?.call?.details?.handle?.schemeSpecificPart
                    ?: _currentCallSession.value?.call?.details?.handle?.schemeSpecificPart
                if (prefs.shouldGateCallWithBiometric(ringingNumber)) {
                    launchBiometricCallActivity("ANSWER")
                } else {
                    answerCall()
                }
            }
            "DECLINE_CALL" -> {
                val ringingNumber = _incomingCallSession.value?.call?.details?.handle?.schemeSpecificPart
                    ?: _currentCallSession.value?.call?.details?.handle?.schemeSpecificPart
                if (prefs.shouldGateCallWithBiometric(ringingNumber)) {
                    launchBiometricCallActivity("DECLINE")
                } else {
                    declineCall()
                }
            }
            "SILENCE_CALL" -> {
                com.modiprincekr.thedialer.controller.util.silenceRingingCall(this)
            }
            "MUTE_CALL"    -> setMuted(!(_audioState.value?.isMuted ?: false))
            "SPEAKER_CALL" -> {
                val isSpeaker = _audioState.value?.route == android.telecom.CallAudioState.ROUTE_SPEAKER
                setAudioRoute(if (isSpeaker) android.telecom.CallAudioState.ROUTE_EARPIECE else android.telecom.CallAudioState.ROUTE_SPEAKER)
            }
            "HOLD_CALL"    -> {
                val call = _currentCallSession.value?.call
                try {
                    if (call?.state == Call.STATE_HOLDING) {
                        call.unhold()
                        _currentCallSession.value = _currentCallSession.value?.copy(state = Call.STATE_ACTIVE)
                    } else {
                        call?.hold()
                        _currentCallSession.value = _currentCallSession.value?.copy(state = Call.STATE_HOLDING)
                    }
                } catch (_: Exception) {}
            }
            "BLUETOOTH_CALL" -> {
                val isBluetooth = _audioState.value?.route == android.telecom.CallAudioState.ROUTE_BLUETOOTH
                setAudioRoute(if (isBluetooth) android.telecom.CallAudioState.ROUTE_SPEAKER else android.telecom.CallAudioState.ROUTE_BLUETOOTH)
            }
            "NOTES_CALL"   -> {
                val name   = intent.getStringExtra("contact_name") ?: "Unknown"
                val number = intent.getStringExtra("phone_number") ?: ""
                if (android.provider.Settings.canDrawOverlays(this)) {
                    FloatingNotesService.start(this, name, number)
                }
            }
            "CANCEL_AUTO_REDIAL" -> {
                cancelAutoRedial()
                if (_currentCallSession.value == null) {
                    removeForeground()
                    cancelNotification()
                }
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun updateNotification(call: Call) {
        if (call.state == Call.STATE_SELECT_PHONE_ACCOUNT) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Delete legacy channels that may have cached default notification sound or vibration
            try { nm.deleteNotificationChannel("call_incoming_channel") } catch (_: Exception) {}
            try { nm.deleteNotificationChannel("call_incoming_channel_v2") } catch (_: Exception) {}

            nm.createNotificationChannel(NotificationChannel(CHANNEL_INCOMING_ID, "Incoming Calls", NotificationManager.IMPORTANCE_HIGH).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
                setBypassDnd(true)
            })
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Ongoing Calls", NotificationManager.IMPORTANCE_LOW).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
            })
        }

        val number = call.details.handle?.schemeSpecificPart ?: ""
        val contact = if (number.isNotEmpty()) try { contactsRepository.getContactByNumber(number) } catch (_: Exception) { null } else null
        val hideNames = prefs.getBoolean(PreferenceManager.KEY_CONTACTS_HIDER_HIDE_NAMES, false)
        val hiddenIdsRaw = prefs.getString(PreferenceManager.KEY_CONTACTS_HIDER_IDS, "") ?: ""
        val hiddenIds = if (hiddenIdsRaw.isBlank()) emptySet() else hiddenIdsRaw.split(",").filter { it.isNotBlank() }.toSet()
        val isHiddenContact = contact != null && contact.id in hiddenIds
        val isConf = (call.details?.hasProperty(Call.Details.PROPERTY_CONFERENCE) == true) || call.children.isNotEmpty()
        val alt = if (contact == null && number.isNotEmpty()) {
            com.modiprincekr.thedialer.controller.util.AlternateNumberRepository.findByNumber(this, number)
        } else null
        val contactName = when {
            isConf -> "Conference call"
            isHiddenContact && hideNames -> number.ifEmpty { "Unknown Number" }
            contact != null -> contact.name
            alt != null -> alt.name
            else -> number.ifEmpty { "Unknown Number" }
        }

        val fsi = PendingIntent.getActivity(this, 0,
            Intent(this, CallActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT) },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val answerPi = PendingIntent.getService(this, 1,
            Intent(this, CallService::class.java).apply { action = "ANSWER_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val declinePi = PendingIntent.getService(this, 2,
            Intent(this, CallService::class.java).apply { action = "DECLINE_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notesPi = PendingIntent.getService(this, 3,
            Intent(this, CallService::class.java).apply {
                action = "NOTES_CALL"
                putExtra("contact_name", contactName)
                putExtra("phone_number", number)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val mutePi = PendingIntent.getService(this, 4,
            Intent(this, CallService::class.java).apply { action = "MUTE_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val speakerPi = PendingIntent.getService(this, 5,
            Intent(this, CallService::class.java).apply { action = "SPEAKER_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val holdPi = PendingIntent.getService(this, 6,
            Intent(this, CallService::class.java).apply { action = "HOLD_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val bluetoothPi = PendingIntent.getService(this, 7,
            Intent(this, CallService::class.java).apply { action = "BLUETOOTH_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val contactPhotoBitmap = loadContactPhotoBitmap(if (isHiddenContact && hideNames) null else contact?.photoUri)
        val personBuilder = Person.Builder().setName(contactName).setImportant(true)
        if (contactPhotoBitmap != null) {
            personBuilder.setIcon(IconCompat.createWithAdaptiveBitmap(contactPhotoBitmap))
        }
        val person = personBuilder.build()
        val isRinging = call.state == Call.STATE_RINGING
        val isMuted   = _audioState.value?.isMuted ?: false
        val isSpeaker = _audioState.value?.route == android.telecom.CallAudioState.ROUTE_SPEAKER
        val isOnHold  = call.state == Call.STATE_HOLDING
        val bluetoothAvailable = (_audioState.value?.supportedRouteMask ?: 0) and android.telecom.CallAudioState.ROUTE_BLUETOOTH != 0
        val isBluetooth = _audioState.value?.route == android.telecom.CallAudioState.ROUTE_BLUETOOTH
        val isFullScreenIncoming = isRinging && prefs.getBoolean(PreferenceManager.KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS, false)
        val channelId = if (isRinging && !isFullScreenIncoming) CHANNEL_INCOMING_ID else CHANNEL_ID

        // Use the call's real, authoritative connect time from Telecom (the same source
        // CallActivity's on-screen timer already trusts) — not "now" — so the notification's
        // elapsed-time chronometer stays correct across every later rebuild (mute/speaker
        // toggles, held-call updates, etc.) instead of restarting from zero each time.
        val connectTime = call.details?.connectTimeMillis?.takeIf { it > 0L }
            ?: callConnectTimes.getOrPut(call) { System.currentTimeMillis() }

        val silencePi = PendingIntent.getService(this, 8,
            Intent(this, CallService::class.java).apply { action = "SILENCE_CALL" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val isDualSim = prefs.getActiveSimCount() >= 2
        val simSlot = if (isDualSim) getSimSlotForCall(this, call) else -1
        val contentText = buildCallNotificationContentText(this, isRinging, isDualSim, simSlot)

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(currentCallSmallIcon())
            .setContentTitle(contactName)
            .setContentText(contentText)
            .apply {
                if (isDualSim && simSlot in 0..1) {
                    setSubText(buildSimBadgeSpan(this@CallService, simSlot))
                }
            }
            .setPriority(if (isFullScreenIncoming) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .apply {
                if (!isFullScreenIncoming) {
                    setFullScreenIntent(fsi, true)
                }
            }
            .setContentIntent(fsi)
            .setOngoing(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(false)
            .setSound(null)
            .setDefaults(0)
            .setVibrate(longArrayOf(0L))
            .setOnlyAlertOnce(true)
            .setWhen(connectTime)
            .setShowWhen(!isRinging)
            .setUsesChronometer(!isRinging)
            .setStyle(
                if (isRinging) NotificationCompat.CallStyle.forIncomingCall(person, declinePi, answerPi)
                else           NotificationCompat.CallStyle.forOngoingCall(person, declinePi)
            )
            .setColorized(false)

        val showIncomingMute = prefs.getBoolean(PreferenceManager.KEY_INCOMING_SHOW_MUTE_BUTTON, false)
        if (isRinging && showIncomingMute) {
            builder.addAction(
                NotificationCompat.Action.Builder(
                    R.drawable.ic_notif_volume_off,
                    "Mute",
                    silencePi
                ).build()
            )
        }

        // Add extra action buttons for ongoing calls
        if (!isRinging) {
            builder.addAction(
                NotificationCompat.Action.Builder(
                    R.drawable.ic_notif_note,
                    "Notes",
                    notesPi
                ).build()
            )
            builder.addAction(
                NotificationCompat.Action.Builder(
                    if (isMuted) R.drawable.ic_notif_mic_on else R.drawable.ic_notif_mic_off,
                    if (isMuted) "Unmute" else "Mute",
                    mutePi
                ).build()
            )
            builder.addAction(
                NotificationCompat.Action.Builder(
                    R.drawable.ic_notif_speaker,
                    if (isSpeaker) "Earpiece" else "Speaker",
                    speakerPi
                ).build()
            )
            builder.addAction(
                NotificationCompat.Action.Builder(
                    R.drawable.ic_notif_hold,
                    if (isOnHold) "Resume" else "Hold",
                    holdPi
                ).build()
            )
            if (bluetoothAvailable) {
                builder.addAction(
                    NotificationCompat.Action.Builder(
                        R.drawable.ic_notif_bluetooth,
                        if (isBluetooth) "Speaker" else "Bluetooth",
                        bluetoothPi
                    ).build()
                )
            }
        }

        val notification = builder.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
        else
            startForeground(NOTIFICATION_ID, notification)

        // Start/stop floating bubble based on preference
        if (call.state != android.telecom.Call.STATE_DISCONNECTED &&
            call.state != android.telecom.Call.STATE_DISCONNECTING) {
            maybeStartFloatingCall(contactName, number, if (isHiddenContact && hideNames) null else contact?.photoUri)
        }
    }

    private fun maybeStartFloatingCall(contactName: String, number: String, photoUri: String?) {
        if (!prefs.getBoolean(PreferenceManager.KEY_FLOATING_CALL, false)) return
        if (!android.provider.Settings.canDrawOverlays(this)) return
        FloatingCallService.start(this, contactName, number, photoUri)
    }

    private fun cancelNotification() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIFICATION_ID)
    }

    private fun createSimBadgeBitmap(context: Context, slot: Int): Bitmap {
        val density = context.resources.displayMetrics.density
        val widthPx = (16 * density).toInt().coerceAtLeast(1)
        val heightPx = (19 * density).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (slot == 0) android.graphics.Color.parseColor("#2E7D32") else android.graphics.Color.parseColor("#C62828")
            style = Paint.Style.FILL
        }
        val cornerRadius = 4 * density
        val rect = RectF(0f, 0f, widthPx.toFloat(), heightPx.toFloat())
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, paint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = 10f * density
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val fontMetrics = textPaint.fontMetrics
        val textY = (heightPx - (fontMetrics.descent + fontMetrics.ascent)) / 2f
        canvas.drawText((slot + 1).toString(), widthPx / 2f, textY, textPaint)

        return bitmap
    }

    private fun buildSimBadgeSpan(context: Context, simSlot: Int): CharSequence {
        if (simSlot !in 0..1) return ""
        val simTag = "SIM ${simSlot + 1}"
        val ssb = SpannableStringBuilder(simTag)
        try {
            val bitmap = createSimBadgeBitmap(context, simSlot)
            val align = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ImageSpan.ALIGN_CENTER else ImageSpan.ALIGN_BOTTOM
            val imageSpan = ImageSpan(context, bitmap, align)
            ssb.setSpan(imageSpan, 0, simTag.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        } catch (_: Exception) {}
        return ssb
    }

    private fun buildCallNotificationContentText(
        context: Context,
        isRinging: Boolean,
        isDualSim: Boolean,
        simSlot: Int
    ): CharSequence {
        val baseText = if (isRinging) "Incoming call" else "Active call"
        if (!isDualSim || simSlot !in 0..1) return baseText

        val simTag = "SIM ${simSlot + 1}"
        val fullText = "$simTag  $baseText"
        val ssb = SpannableStringBuilder(fullText)
        try {
            val bitmap = createSimBadgeBitmap(context, simSlot)
            val align = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ImageSpan.ALIGN_CENTER else ImageSpan.ALIGN_BOTTOM
            val imageSpan = ImageSpan(context, bitmap, align)
            ssb.setSpan(imageSpan, 0, simTag.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        } catch (_: Exception) {}
        return ssb
    }
}

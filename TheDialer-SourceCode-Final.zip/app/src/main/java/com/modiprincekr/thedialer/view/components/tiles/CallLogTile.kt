package com.modiprincekr.thedialer.view.components.tiles

import android.provider.CallLog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.modiprincekr.thedialer.controller.util.formatDate
import com.modiprincekr.thedialer.controller.util.formatDuration
import com.modiprincekr.thedialer.modal.data.CallLogEntry
import org.koin.compose.koinInject

@Composable
fun CallLogTile(
    log: CallLogEntry,
    modifier: Modifier = Modifier,
    onCallClick: () -> Unit = {},
    onClick: () -> Unit = {},
    displayNameOverride: String? = null
) {
    val isMissed = log.types.any { it == CallLog.Calls.MISSED_TYPE } || (log.types.isEmpty() && log.type == CallLog.Calls.MISSED_TYPE)
    val isBlocked = log.types.any { it == CallLog.Calls.BLOCKED_TYPE } || (log.types.isEmpty() && log.type == CallLog.Calls.BLOCKED_TYPE)
    val prefs = koinInject<PreferenceManager>()
    val settingsVer by prefs.settingsChanged.collectAsState()
    val use24HourTime = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_CALL_TIME_FORMAT_24H, false) }
    val showTalkTime = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_SHOW_TALK_TIME_IN_CALL_LOGS, false) }
    val showMissedCallDuration = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_SHOW_MISSED_CALL_DURATION, false) }
    val nameNonContactsAsUnknown = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_NAME_NON_CONTACTS_AS_UNKNOWN, true) }
    val showAvatarsInCalls = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_SHOW_AVATARS_CALLS, true) }
    val displayTitle = displayNameOverride ?: (
        if (!log.name.isNullOrBlank() && log.name != log.number) {
            log.name
        } else if (nameNonContactsAsUnknown) {
            "Unknown"
        } else {
            log.number.ifBlank { "Unknown" }
        }
    )



    SingleTile(
        title = displayTitle,
        titleMaxLines = 2,
        photoUri = if (showAvatarsInCalls) log.photoUri else null,
        forcePersonIcon = log.name.isNullOrEmpty(),
        isMissedCall = isMissed || isBlocked,
        showAvatar = showAvatarsInCalls,
        modifier = modifier,
        titleTrailing = if (log.isCallerIdName) {
            {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "Caller ID",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        } else null,
        supportingContent = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val displayTypes = if (log.types.isNotEmpty()) log.types else listOf(log.type)
                val iconsToShow = displayTypes.take(4)
                val remaining = displayTypes.size - iconsToShow.size

                iconsToShow.forEach { type ->
                    val icon = when (type) {
                        CallLog.Calls.INCOMING_TYPE -> Icons.AutoMirrored.Filled.CallReceived
                        CallLog.Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade
                        CallLog.Calls.MISSED_TYPE -> Icons.AutoMirrored.Filled.CallMissed
                        CallLog.Calls.BLOCKED_TYPE -> Icons.Default.Block
                        else -> Icons.Rounded.Call
                    }
                    val tint = if (type == CallLog.Calls.MISSED_TYPE || type == CallLog.Calls.BLOCKED_TYPE) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(14.dp), tint = tint)
                }

                if (remaining > 0) {
                    Text(text = "+$remaining", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Spacer(modifier = Modifier.width(4.dp))
                val dateStr = formatDate(log.date, use24HourTime)
                val durationStr = if (isBlocked && log.duration > 0) {
                    " • ${log.duration}s"
                } else if (isMissed && showMissedCallDuration && log.duration > 0) {
                    " • ${log.duration}s"
                } else if (showTalkTime && !isMissed) {
                    " • ${formatDuration(log.duration)}"
                } else ""
                Text(text = "$dateStr$durationStr", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        trailingContent = {
            IconButton(onClick = onCallClick, modifier = Modifier.size(48.dp)) {
                Icon(imageVector = Icons.Rounded.Call, contentDescription = "Call", tint = MaterialTheme.colorScheme.primary)
            }
        },
        onClick = onClick
    )
}

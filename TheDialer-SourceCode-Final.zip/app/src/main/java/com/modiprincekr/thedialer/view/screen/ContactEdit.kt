package com.modiprincekr.thedialer.view.screen

import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Cake
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.modiprincekr.thedialer.controller.ContactsViewModel
import com.modiprincekr.thedialer.modal.data.Contact
import com.modiprincekr.thedialer.modal.data.ContactAccountInfo
import com.modiprincekr.thedialer.modal.data.ContactEvent
import com.modiprincekr.thedialer.modal.data.ContactPhone
import com.modiprincekr.thedialer.modal.data.ContactSaveTarget
import com.modiprincekr.thedialer.modal.data.getPhoneTypeLabel
import com.modiprincekr.thedialer.view.components.ExpressiveAvatar
import com.modiprincekr.thedialer.view.components.PfpCropDialog
import com.modiprincekr.thedialer.view.components.RivoAvatar
import com.modiprincekr.thedialer.view.components.RivoExpressiveCard
import com.modiprincekr.thedialer.view.components.RivoSectionHeader
import com.ramcosta.composedestinations.annotation.Destination
import com.ramcosta.composedestinations.annotation.RootGraph
import com.modiprincekr.thedialer.view.theme.SettingsTransitionStyle
import com.ramcosta.composedestinations.navigation.DestinationsNavigator
import org.koin.compose.viewmodel.koinActivityViewModel

private data class EditableField(val id: Long, val value: String)
private data class EditablePhoneField(
    val id: Long,
    val value: String,
    val type: Int = ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,
    val customLabel: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Destination<RootGraph>(style = SettingsTransitionStyle::class)
@Composable
fun ContactEditScreen(
    contactId: String? = null,
    initialName: String? = null,
    initialPhone: String? = null,
    navigator: DestinationsNavigator
) {
    val contactsVM: ContactsViewModel = koinActivityViewModel()
    val allContacts by contactsVM.allContacts.collectAsState()
    
    var resolvedContact by remember { mutableStateOf<Contact?>(null) }
    var isInitialized by remember { mutableStateOf(false) }
    var nextFieldId by remember { mutableLongStateOf(100L) }

    val initialNameParts = remember(initialName) {
        val trimmed = (initialName ?: "").trim()
        if (trimmed.isEmpty()) Pair("", "")
        else {
            val parts = trimmed.split(Regex("\\s+"), limit = 2)
            Pair(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" })
        }
    }
    var prefix by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf(initialNameParts.first) }
    var middleName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf(initialNameParts.second) }
    var suffix by remember { mutableStateOf("") }
    val fullName = remember(prefix, firstName, middleName, lastName, suffix) {
        listOf(prefix.trim(), firstName.trim(), middleName.trim(), lastName.trim(), suffix.trim())
            .filter { it.isNotBlank() }
            .joinToString(" ")
    }
    var photoUri by remember { mutableStateOf<String?>(null) }
    val phoneFields = remember { 
        mutableStateListOf<EditablePhoneField>().apply { 
            add(EditablePhoneField(1L, initialPhone ?: "")) 
        } 
    }
    val emailFields = remember { mutableStateListOf<EditableField>().apply { add(EditableField(2L, "")) } }
    val addressFields = remember { mutableStateListOf<EditableField>().apply { add(EditableField(3L, "")) } }
    var description by remember { mutableStateOf("") }
    var birthday by remember { mutableStateOf("") }

    val context = LocalContext.current
    val isNewContact = contactId.isNullOrBlank() || contactId == "0" || contactId == "null"
    val saveTargets = remember { contactsVM.getSaveTargets() }
    var currentAccounts by remember { mutableStateOf<List<ContactAccountInfo>>(emptyList()) }
    var selectedTarget by remember { mutableStateOf<ContactSaveTarget?>(null) }
    var updateAllLinkedAccounts by remember { mutableStateOf(true) }
    var showAccountPickerDialog by remember { mutableStateOf(false) }
    var showMultiAccountConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(contactId, allContacts) {
        if (contactId != null && contactId != "0" && contactId != "null" && !isInitialized) {
            val contact = allContacts.find { it.id == contactId } 
                ?: kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { contactsVM.getContactById(contactId) }
            val accounts = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                contactsVM.getContactAccounts(contactId)
            }
            currentAccounts = accounts
            // By default, editing an existing contact should update all linked accounts
            updateAllLinkedAccounts = true
            selectedTarget = null

            if (contact != null) {
                resolvedContact = contact
                var loadedPrefix = contact.prefix ?: ""
                var loadedFirst = contact.firstName ?: ""
                var loadedMiddle = contact.middleName ?: ""
                var loadedLast = contact.lastName ?: ""
                var loadedSuffix = contact.suffix ?: ""
                if (loadedFirst.isBlank() && loadedLast.isBlank() && loadedMiddle.isBlank() && loadedPrefix.isBlank() && loadedSuffix.isBlank()) {
                    try {
                        context.contentResolver.query(
                            ContactsContract.Data.CONTENT_URI,
                            arrayOf(
                                ContactsContract.CommonDataKinds.StructuredName.PREFIX,
                                ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME,
                                ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME,
                                ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME,
                                ContactsContract.CommonDataKinds.StructuredName.SUFFIX
                            ),
                            "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                            arrayOf(contactId, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE),
                            null
                        )?.use { cursor ->
                            if (cursor.moveToFirst()) {
                                val prefixIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.PREFIX)
                                val givenIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME)
                                val middleIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.MIDDLE_NAME)
                                val familyIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME)
                                val suffixIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.SUFFIX)
                                if (prefixIdx >= 0) loadedPrefix = cursor.getString(prefixIdx) ?: ""
                                if (givenIdx >= 0) loadedFirst = cursor.getString(givenIdx) ?: ""
                                if (middleIdx >= 0) loadedMiddle = cursor.getString(middleIdx) ?: ""
                                if (familyIdx >= 0) loadedLast = cursor.getString(familyIdx) ?: ""
                                if (suffixIdx >= 0) loadedSuffix = cursor.getString(suffixIdx) ?: ""
                            }
                        }
                    } catch (_: Exception) {}
                }
                if (loadedFirst.isBlank() && loadedLast.isBlank() && loadedMiddle.isBlank() && loadedPrefix.isBlank() && loadedSuffix.isBlank()) {
                    val parts = contact.name.trim().split(Regex("\\s+"), limit = 2)
                    loadedFirst = parts.getOrNull(0) ?: ""
                    loadedLast = parts.getOrNull(1) ?: ""
                }
                prefix = loadedPrefix
                firstName = loadedFirst
                middleName = loadedMiddle
                lastName = loadedLast
                suffix = loadedSuffix
                photoUri = contact.photoUri
                
                phoneFields.clear()
                if (contact.phones.isNotEmpty()) {
                    contact.phones.forEach { 
                        phoneFields.add(EditablePhoneField(nextFieldId++, it.number, it.type, it.label)) 
                    }
                } else if (contact.phoneNumbers.isNotEmpty()) {
                    contact.phoneNumbers.forEach { 
                        phoneFields.add(EditablePhoneField(nextFieldId++, it, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE, null)) 
                    }
                } else {
                    phoneFields.add(EditablePhoneField(nextFieldId++, ""))
                }

                if (!initialPhone.isNullOrBlank()) {
                    val cleanInit = initialPhone.filter { it.isDigit() || it == '+' }
                    val alreadyPresent = phoneFields.any { field ->
                        val cleanField = field.value.filter { it.isDigit() || it == '+' }
                        cleanField == cleanInit || (cleanField.isNotEmpty() && cleanInit.isNotEmpty() && (cleanField.endsWith(cleanInit) || cleanInit.endsWith(cleanField)))
                    }
                    if (!alreadyPresent) {
                        if (phoneFields.size == 1 && phoneFields[0].value.isBlank()) {
                            phoneFields[0] = phoneFields[0].copy(value = initialPhone)
                        } else {
                            phoneFields.add(EditablePhoneField(nextFieldId++, initialPhone))
                        }
                    }
                }

                emailFields.clear()
                if (contact.emails.isNotEmpty()) {
                    contact.emails.forEach { emailFields.add(EditableField(nextFieldId++, it)) }
                } else {
                    emailFields.add(EditableField(nextFieldId++, ""))
                }

                addressFields.clear()
                if (contact.addresses.isNotEmpty()) {
                    contact.addresses.forEach { addressFields.add(EditableField(nextFieldId++, it)) }
                } else {
                    addressFields.add(EditableField(nextFieldId++, ""))
                }
                description = contact.note ?: ""
                val bEvent = contact.events.firstOrNull { it.type == ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY }
                birthday = bEvent?.date ?: ""
                isInitialized = true
            }
        }
    }

    LaunchedEffect(isNewContact, saveTargets) {
        if (isNewContact && selectedTarget == null && saveTargets.isNotEmpty()) {
            selectedTarget = saveTargets.firstOrNull { it.accountType?.contains("google", ignoreCase = true) == true }
                ?: saveTargets.firstOrNull { !it.isSim }
                ?: saveTargets.firstOrNull()
        }
    }

    var pendingCropImageUri by remember { mutableStateOf<Uri?>(null) }
    var showCropDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                pendingCropImageUri = uri
                showCropDialog = true
            }
        }
    )

    var phoneTypePickerIndex by remember { mutableStateOf<Int?>(null) }
    var showCustomPhoneLabelDialog by remember { mutableStateOf(false) }
    var customPhoneLabelIndex by remember { mutableStateOf<Int?>(null) }
    var customPhoneLabelInput by remember { mutableStateOf("") }

    val performSave: (ContactSaveTarget?, Boolean) -> Unit = { target, allAccounts ->
        val validPhoneFields = phoneFields.filter { it.value.trim().isNotBlank() }
        val validPhones = validPhoneFields.map { it.value.trim() }
        val contactPhones = validPhoneFields.map { 
            ContactPhone(number = it.value.trim(), type = it.type, label = it.customLabel)
        }
        val finalContactId = if (isNewContact) "0" else contactId
        val otherEvents = resolvedContact?.events?.filter { it.type != ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY } ?: emptyList()
        val updatedEvents = if (birthday.isNotBlank()) {
            otherEvents + ContactEvent(
                type = ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY,
                label = null,
                date = birthday.trim()
            )
        } else otherEvents
        val contactToSave = Contact(
            id = finalContactId,
            name = fullName,
            prefix = prefix.trim().ifBlank { null },
            firstName = firstName.trim().ifBlank { null },
            middleName = middleName.trim().ifBlank { null },
            lastName = lastName.trim().ifBlank { null },
            suffix = suffix.trim().ifBlank { null },
            phoneNumbers = validPhones,
            phones = contactPhones,
            emails = emailFields.map { it.value.trim() }.filter { it.isNotBlank() },
            addresses = addressFields.map { it.value.trim() }.filter { it.isNotBlank() },
            photoUri = photoUri,
            note = description.trim().ifBlank { null },
            isFavorite = resolvedContact?.isFavorite ?: false,
            sourceAccounts = resolvedContact?.sourceAccounts ?: emptyList(),
            events = updatedEvents
        )

        if (isNewContact) {
            val finalTarget = target ?: selectedTarget
            if (finalTarget?.isSim == true) {
                contactsVM.saveContactToSim(contactToSave, finalTarget.simSlotIndex) { success ->
                    Toast.makeText(
                        context,
                        if (success) "Saved to ${finalTarget.label}" else "Couldn't save to ${finalTarget.label}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                contactsVM.saveContact(
                    contact = contactToSave,
                    accountType = finalTarget?.accountType,
                    accountName = finalTarget?.accountName
                )
            }
        } else {
            contactsVM.saveContact(
                contact = contactToSave,
                accountType = target?.accountType,
                accountName = target?.accountName,
                updateAllAccounts = allAccounts,
                originalContact = resolvedContact
            )
        }
        navigator.navigateUp()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        if (isNewContact) "Create Contact" else "Edit Contact",
                        fontWeight = FontWeight.Bold
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = { navigator.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    val validPhones = phoneFields.map { it.value.trim() }.filter { it.isNotBlank() }
                    Button(
                        onClick = {
                            if (isNewContact) {
                                if (selectedTarget != null) {
                                    performSave(selectedTarget, false)
                                } else {
                                    showAccountPickerDialog = true
                                }
                            } else {
                                val writable = currentAccounts.filter { !it.isReadOnly }
                                if (writable.size > 1 && !updateAllLinkedAccounts && selectedTarget == null) {
                                    showMultiAccountConfirmDialog = true
                                } else {
                                    performSave(selectedTarget, updateAllLinkedAccounts)
                                }
                            }
                        },
                        enabled = fullName.isNotBlank() && validPhones.isNotEmpty(),
                        modifier = Modifier.padding(end = 8.dp),
                        shape = RoundedCornerShape(24.dp),
                        elevation = ButtonDefaults.buttonElevation(0.dp)
                    ) {
                        Icon(Icons.Default.Check, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Save")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        ExpressiveAvatar(
                            name = fullName.ifBlank { "Unknown" },
                            photoUri = photoUri,
                            size = 120.dp,
                            modifier = Modifier.size(120.dp)
                        )
                        
                        Row {
                            if (photoUri != null) {
                                SmallFloatingActionButton(
                                    onClick = { photoUri = null },
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                                    shape = CircleShape,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(Icons.Default.Delete, null, modifier = Modifier.size(20.dp))
                                }
                                Spacer(Modifier.width(8.dp))
                            }
                            
                            SmallFloatingActionButton(
                                onClick = { 
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                shape = CircleShape,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(Icons.Default.AddAPhoto, null, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }

            
            item {
                val allPresentAccounts = currentAccounts
                val (storageTitle, storageSubtitle, storageIcon) = remember(
                    isNewContact,
                    allPresentAccounts,
                    selectedTarget,
                    updateAllLinkedAccounts
                ) {
                    if (isNewContact) {
                        val label = selectedTarget?.label ?: "Device Storage"
                        val sub = selectedTarget?.subLabel
                        val icon = when {
                            selectedTarget?.isSim == true -> Icons.Default.SimCard
                            selectedTarget?.accountType?.contains("google", ignoreCase = true) == true -> Icons.Default.AccountCircle
                            selectedTarget?.accountType != null -> Icons.Default.Sync
                            else -> Icons.Default.PhoneAndroid
                        }
                        Triple("Saving to", if (sub != null) "$label ($sub)" else label, icon)
                    } else {
                        val locationNames = allPresentAccounts.map { it.displayName }.distinct()
                        val allLocationsText = if (locationNames.isNotEmpty()) locationNames.joinToString(", ") else "Device Storage"
                        if (updateAllLinkedAccounts || selectedTarget == null) {
                            Triple("Edit Location", "Present in: $allLocationsText", Icons.Default.Storage)
                        } else {
                            Triple("Edit Location", "Editing only in: ${selectedTarget?.label ?: ""}", Icons.Default.Edit)
                        }
                    }
                }

                RivoSectionHeader(title = if (isNewContact) "Storage Location" else "Edit Location")
                RivoExpressiveCard {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showAccountPickerDialog = true }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    storageIcon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = storageTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = storageSubtitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            OutlinedButton(
                                onClick = { showAccountPickerDialog = true },
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("Change", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        // Badges for all locations wherever this contact is present (Gmail, WhatsApp, Meet, Device, SIM, etc.)
                        if (!isNewContact && allPresentAccounts.isNotEmpty()) {
                            Spacer(Modifier.height(10.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Present across ${allPresentAccounts.size} location${if (allPresentAccounts.size != 1) "s" else ""} (edits all by default):",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                allPresentAccounts.forEach { acc ->
                                    val (badgeIcon, badgeColor) = when {
                                        acc.accountType?.contains("google", ignoreCase = true) == true ->
                                            Icons.Default.Email to Color(0xFFE53935)
                                        acc.accountType?.contains("whatsapp", ignoreCase = true) == true ->
                                            Icons.Default.Chat to Color(0xFF25D366)
                                        acc.accountType?.contains("meet", ignoreCase = true) == true ->
                                            Icons.Default.VideoCall to Color(0xFF00897B)
                                        acc.accountType?.contains("telegram", ignoreCase = true) == true ->
                                            Icons.Default.Send to Color(0xFF0088CC)
                                        acc.isSim ->
                                            Icons.Default.SimCard to Color(0xFFFB8C00)
                                        else ->
                                            Icons.Default.PhoneAndroid to Color(0xFF607D8B)
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = badgeColor.copy(alpha = 0.12f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(badgeIcon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                acc.displayName,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                RivoSectionHeader(title = "Identity")
                RivoExpressiveCard {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = prefix,
                            onValueChange = { prefix = it },
                            label = { Text("Prefix (optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        OutlinedTextField(
                            value = firstName,
                            onValueChange = { firstName = it },
                            label = { Text("First Name") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        OutlinedTextField(
                            value = middleName,
                            onValueChange = { middleName = it },
                            label = { Text("Middle Name (optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        OutlinedTextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            label = { Text("Last Name (optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        OutlinedTextField(
                            value = suffix,
                            onValueChange = { suffix = it },
                            label = { Text("Suffix (optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }

            
            item {
                RivoSectionHeader(title = "Phone Numbers")
                RivoExpressiveCard {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        phoneFields.forEachIndexed { index, field ->
                            key(field.id) {
                                val currentTypeLabel = getPhoneTypeLabel(field.type, field.customLabel)
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { phoneTypePickerIndex = index }
                                            .padding(vertical = 2.dp, horizontal = 4.dp)
                                    ) {
                                        Text(
                                            text = currentTypeLabel,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.ArrowDropDown,
                                            contentDescription = "Select phone type",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    EditField(
                                        value = field.value,
                                        onValueChange = { newValue ->
                                            phoneFields[index] = field.copy(value = newValue)
                                        },
                                        label = "Phone",
                                        icon = Icons.Default.Phone,
                                        onDelete = if (phoneFields.size > 1) { { phoneFields.removeAt(index) } } else null
                                    )
                                }
                            }
                        }
                        TextButton(
                            onClick = { phoneFields.add(EditablePhoneField(nextFieldId++, "")) },
                            modifier = Modifier.align(Alignment.Start)
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Add Phone")
                        }
                    }
                }
            }

            
            item {
                RivoSectionHeader(title = "Emails")
                RivoExpressiveCard {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        emailFields.forEachIndexed { index, field ->
                            key(field.id) {
                                EditField(
                                    value = field.value,
                                    onValueChange = { newValue ->
                                        emailFields[index] = field.copy(value = newValue)
                                    },
                                    label = "Email",
                                    icon = Icons.Default.Email,
                                    onDelete = if (emailFields.size > 1) { { emailFields.removeAt(index) } } else null
                                )
                            }
                        }
                        TextButton(
                            onClick = { emailFields.add(EditableField(nextFieldId++, "")) },
                            modifier = Modifier.align(Alignment.Start)
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Add Email")
                        }
                    }
                }
            }

            
            item {
                RivoSectionHeader(title = "Address")
                RivoExpressiveCard {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        addressFields.forEachIndexed { index, field ->
                            key(field.id) {
                                EditField(
                                    value = field.value,
                                    onValueChange = { newValue ->
                                        addressFields[index] = field.copy(value = newValue)
                                    },
                                    label = "Address",
                                    icon = Icons.Default.LocationOn,
                                    onDelete = if (addressFields.size > 1) { { addressFields.removeAt(index) } } else null
                                )
                            }
                        }
                        TextButton(
                            onClick = { addressFields.add(EditableField(nextFieldId++, "")) },
                            modifier = Modifier.align(Alignment.Start)
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Add Address")
                        }
                    }
                }
            }

            item {
                RivoSectionHeader(title = "Birthday")
                RivoExpressiveCard {
                    OutlinedTextField(
                        value = birthday,
                        onValueChange = { birthday = it },
                        label = { Text("Birthday") },
                        placeholder = { Text("YYYY-MM-DD or tap calendar") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        leadingIcon = {
                            Icon(Icons.Outlined.Cake, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (birthday.isNotBlank()) {
                                    IconButton(onClick = { birthday = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear Birthday")
                                    }
                                }
                                IconButton(onClick = {
                                    val cal = java.util.Calendar.getInstance()
                                    val parts = birthday.split("-")
                                    val y = parts.getOrNull(0)?.toIntOrNull() ?: cal.get(java.util.Calendar.YEAR)
                                    val m = (parts.getOrNull(1)?.toIntOrNull()?.minus(1)) ?: cal.get(java.util.Calendar.MONTH)
                                    val d = parts.getOrNull(2)?.toIntOrNull() ?: cal.get(java.util.Calendar.DAY_OF_MONTH)
                                    android.app.DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            val mm = String.format("%02d", month + 1)
                                            val dd = String.format("%02d", dayOfMonth)
                                            birthday = "$year-$mm-$dd"
                                        },
                                        y, m, d
                                    ).show()
                                }) {
                                    Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
            
            item {
                RivoSectionHeader(title = "Description")
                RivoExpressiveCard {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description") },
                        placeholder = { Text("Notes synced with Google / Exchange") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                        shape = RoundedCornerShape(16.dp),
                        leadingIcon = { Icon(Icons.Default.Description, null) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        minLines = 3,
                        maxLines = 6
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(100.dp)) }
        }
    }

    if (showAccountPickerDialog) {
        val writableAccounts = currentAccounts.filter { !it.isReadOnly }
        Dialog(onDismissRequest = { showAccountPickerDialog = false }) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    Text(
                        if (isNewContact) "Save contact to" else "Edit location",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
                    )

                    if (!isNewContact && currentAccounts.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    updateAllLinkedAccounts = true
                                    selectedTarget = null
                                    showAccountPickerDialog = false
                                }
                                .padding(horizontal = 24.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "All locations (${currentAccounts.size})",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Edit across all accounts by default (Recommended)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (updateAllLinkedAccounts && selectedTarget == null) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                    }

                    val targetsToShow = if (!isNewContact && writableAccounts.isNotEmpty()) {
                        writableAccounts.map { acc ->
                            ContactSaveTarget(
                                label = acc.displayName,
                                subLabel = acc.accountName,
                                accountType = acc.accountType,
                                accountName = acc.accountName,
                                isSim = acc.isSim,
                                simSlotIndex = acc.simSlotIndex
                            )
                        }
                    } else {
                        saveTargets
                    }

                    targetsToShow.forEach { target ->
                        val isSelected = !updateAllLinkedAccounts && (
                            (target.accountType == selectedTarget?.accountType && target.accountName == selectedTarget?.accountName) ||
                            (target.isSim && selectedTarget?.isSim == true && target.simSlotIndex == selectedTarget?.simSlotIndex)
                        )
                        val icon: ImageVector = when {
                            target.isSim -> Icons.Default.SimCard
                            target.accountType?.contains("google", ignoreCase = true) == true -> Icons.Default.AccountCircle
                            target.accountType != null -> Icons.Default.Sync
                            else -> Icons.Default.PhoneAndroid
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedTarget = target
                                    updateAllLinkedAccounts = false
                                    showAccountPickerDialog = false
                                }
                                .padding(horizontal = 24.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(target.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                if (target.subLabel != null) {
                                    Text(
                                        target.subLabel,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    val readOnlyAccounts = currentAccounts.filter { it.isReadOnly }
                    if (!isNewContact && readOnlyAccounts.isNotEmpty()) {
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                        )
                        Text(
                            "Synced app accounts (auto-updated):",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                        )
                        readOnlyAccounts.forEach { acc ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 24.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val roIcon = when {
                                    acc.accountType?.contains("whatsapp", true) == true -> Icons.Default.Chat
                                    acc.accountType?.contains("meet", true) == true -> Icons.Default.VideoCall
                                    acc.accountType?.contains("telegram", true) == true -> Icons.Default.Send
                                    else -> Icons.Default.Sync
                                }
                                Icon(
                                    roIcon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(16.dp))
                                Column {
                                    Text(acc.displayName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Synced via ${acc.accountType ?: "app"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = { showAccountPickerDialog = false },
                        modifier = Modifier.align(Alignment.End).padding(horizontal = 16.dp)
                    ) { Text("Cancel") }
                }
            }
        }
    }

    if (showMultiAccountConfirmDialog) {
        val writableAccounts = currentAccounts.filter { !it.isReadOnly }
        Dialog(onDismissRequest = { showMultiAccountConfirmDialog = false }) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    Text(
                        "Save contact changes",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
                    )
                    Text(
                        "This contact is linked across multiple accounts. Choose how to save your changes:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                    )
                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showMultiAccountConfirmDialog = false
                                performSave(null, true)
                            }
                            .padding(horizontal = 24.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(
                                "All linked accounts (${writableAccounts.size})",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Keep unified across all accounts (Recommended)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    writableAccounts.forEach { acc ->
                        val target = ContactSaveTarget(
                            label = acc.displayName,
                            subLabel = acc.accountName,
                            accountType = acc.accountType,
                            accountName = acc.accountName,
                            isSim = acc.isSim,
                            simSlotIndex = acc.simSlotIndex
                        )
                        val icon = when {
                            acc.isSim -> Icons.Default.SimCard
                            acc.accountType?.contains("google", ignoreCase = true) == true -> Icons.Default.AccountCircle
                            acc.accountType != null -> Icons.Default.Sync
                            else -> Icons.Default.PhoneAndroid
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showMultiAccountConfirmDialog = false
                                    performSave(target, false)
                                }
                                .padding(horizontal = 24.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(16.dp))
                            Column {
                                Text(target.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                if (target.subLabel != null) {
                                    Text(target.subLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = { showMultiAccountConfirmDialog = false },
                        modifier = Modifier.align(Alignment.End).padding(horizontal = 16.dp)
                    ) { Text("Cancel") }
                }
            }
        }
    }

    // Phone Type Selection Dialog
    phoneTypePickerIndex?.let { fieldIndex ->
        if (fieldIndex in phoneFields.indices) {
            val phoneTypes = listOf(
                ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE to "Mobile",
                ContactsContract.CommonDataKinds.Phone.TYPE_WORK to "Work",
                ContactsContract.CommonDataKinds.Phone.TYPE_HOME to "Home",
                ContactsContract.CommonDataKinds.Phone.TYPE_MAIN to "Main",
                ContactsContract.CommonDataKinds.Phone.TYPE_OTHER to "Other",
                ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM to "Custom"
            )

            AlertDialog(
                onDismissRequest = { phoneTypePickerIndex = null },
                title = {
                    Text(
                        text = "Phone",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        phoneTypes.forEach { (typeVal, typeName) ->
                            val isSelected = if (typeVal == ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM) {
                                phoneFields[fieldIndex].type == ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM
                            } else {
                                phoneFields[fieldIndex].type == typeVal
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        phoneTypePickerIndex = null
                                        if (typeVal == ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM) {
                                            customPhoneLabelIndex = fieldIndex
                                            customPhoneLabelInput = phoneFields[fieldIndex].customLabel ?: ""
                                            showCustomPhoneLabelDialog = true
                                        } else {
                                            phoneFields[fieldIndex] = phoneFields[fieldIndex].copy(
                                                type = typeVal,
                                                customLabel = null
                                            )
                                        }
                                    }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = typeName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { phoneTypePickerIndex = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }

    // Custom Phone Label Input Dialog
    if (showCustomPhoneLabelDialog) {
        AlertDialog(
            onDismissRequest = { showCustomPhoneLabelDialog = false },
            title = {
                Text(
                    text = "Custom label",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                OutlinedTextField(
                    value = customPhoneLabelInput,
                    onValueChange = { customPhoneLabelInput = it },
                    label = { Text("Label name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val idx = customPhoneLabelIndex
                        if (idx != null && idx in phoneFields.indices) {
                            val trimmed = customPhoneLabelInput.trim()
                            if (trimmed.isNotBlank()) {
                                phoneFields[idx] = phoneFields[idx].copy(
                                    type = ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM,
                                    customLabel = trimmed
                                )
                            }
                        }
                        showCustomPhoneLabelDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomPhoneLabelDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showCropDialog && pendingCropImageUri != null) {
        PfpCropDialog(
            imageUri = pendingCropImageUri!!,
            contactId = if (isNewContact) "0" else contactId,
            onDismiss = {
                showCropDialog = false
                pendingCropImageUri = null
            },
            onCropSaved = { savedUri, _, _ ->
                showCropDialog = false
                pendingCropImageUri = null
                photoUri = savedUri.toString()
            }
        )
    }
}

@Composable
fun EditField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: ImageVector,
    onDelete: (() -> Unit)? = null
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary
            )
        )
        if (onDelete != null) {
            IconButton(
                onClick = onDelete,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Icon(
                    Icons.Default.DeleteOutline, 
                    null, 
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

package com.modiprincekr.thedialer.view.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.PhoneCallback
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.findRootCoordinates
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import com.modiprincekr.thedialer.controller.util.WHATSAPP_PACKAGES
import com.modiprincekr.thedialer.controller.util.isAnyPackageInstalled
import com.modiprincekr.thedialer.controller.util.isTelegramInstalled
import com.modiprincekr.thedialer.controller.util.isGoogleMeetInstalled
import com.modiprincekr.thedialer.controller.util.isTruecallerInstalled
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.modiprincekr.thedialer.controller.util.BlockedNumbersManager
import com.modiprincekr.thedialer.controller.util.FakeCallManager
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.modiprincekr.thedialer.view.components.SwipeableItemContainer
import com.modiprincekr.thedialer.controller.util.SwipeActionHelper
import com.modiprincekr.thedialer.controller.util.deduplicatePhoneNumbers
import com.modiprincekr.thedialer.controller.ContactsViewModel
import com.modiprincekr.thedialer.modal.data.Contact
import com.modiprincekr.thedialer.controller.util.makeCall
import com.modiprincekr.thedialer.controller.util.getPhoneAccountForSimSlot
import com.modiprincekr.thedialer.view.screen.SimCardIconWithNumber
import com.modiprincekr.thedialer.view.screen.settings.AddMode
import com.modiprincekr.thedialer.view.screen.settings.FakeCallAddSheet
import com.ramcosta.composedestinations.generated.destinations.ContactDetailsScreenDestination
import com.ramcosta.composedestinations.generated.destinations.ContactEditScreenDestination
import com.ramcosta.composedestinations.navigation.DestinationsNavigator
import kotlinx.coroutines.launch
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinActivityViewModel
private val CARD_RADIUS = 28.dp
private val INNER_RADIUS = 4.dp

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun AZListScroll(
    contacts: List<Contact>,
    navigator: DestinationsNavigator,
    modifier: Modifier = Modifier,
    listState: androidx.compose.foundation.lazy.LazyListState = rememberLazyListState(),
    selectionMode: Boolean = false,
    selectedContacts: Set<String> = emptySet(),
    onSelectionModeChange: (Boolean) -> Unit = {},
    onSelectedContactsChange: (Set<String>) -> Unit = {},
    topContent: (@Composable () -> Unit)? = null,
    isAlphabetical: Boolean = true,
    isAlphabeticalReversed: Boolean = false
) {
    AZListContent(
        contacts = contacts,
        navigator = navigator,
        listState = listState,
        modifier = modifier,
        selectionMode = selectionMode,
        selectedContacts = selectedContacts,
        topContent = topContent,
        isAlphabetical = isAlphabetical,
        isAlphabeticalReversed = isAlphabeticalReversed,
        onSelectMode = { contact ->
            onSelectionModeChange(true)
            onSelectedContactsChange(setOf(contact.id))
        },
        onSelectToggle = { contact ->
            val updated = if (selectedContacts.contains(contact.id))
                selectedContacts - contact.id else selectedContacts + contact.id
            onSelectedContactsChange(updated)
        }
    )
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun AZListContent(
    contacts: List<Contact>,
    navigator: DestinationsNavigator,
    modifier: Modifier = Modifier,
    listState: androidx.compose.foundation.lazy.LazyListState = rememberLazyListState(),
    selectionMode: Boolean = false,
    selectedContacts: Set<String> = emptySet(),
    onSelectMode: (Contact) -> Unit = {},
    onSelectToggle: (Contact) -> Unit = {},
    topContent: (@Composable () -> Unit)? = null,
    isAlphabetical: Boolean = true,
    isAlphabeticalReversed: Boolean = false
) {
    val grouped = remember(contacts, isAlphabeticalReversed) {
        val mainGroups = contacts.groupBy {
            val firstChar = it.name.trimStart().firstOrNull()?.uppercaseChar() ?: '#'
            if (firstChar.isLetter()) firstChar else '#'
        }.toMutableMap()

        val finalMap = linkedMapOf<Char, List<Contact>>()
        val letterKeys = if (isAlphabeticalReversed) {
            val latinLetters = mainGroups.keys.filter { it in 'A'..'Z' }.sortedDescending()
            val otherLetters = mainGroups.keys.filter { it.isLetter() && it !in 'A'..'Z' }.sortedDescending()
            latinLetters + otherLetters
        } else {
            val latinLetters = mainGroups.keys.filter { it in 'A'..'Z' }.sorted()
            val otherLetters = mainGroups.keys.filter { it.isLetter() && it !in 'A'..'Z' }.sorted()
            latinLetters + otherLetters
        }
        letterKeys.forEach { char ->
            finalMap[char] = mainGroups[char]!!
        }
        val hashGroup = mainGroups['#']
        if (hashGroup != null) finalMap['#'] = hashGroup
        finalMap
    }

    // Map each letter to its first LazyColumn item index for sidebar jump
    val topContentOffset = if (topContent != null) 1 else 0
    val alphabetIndices = remember(grouped, topContentOffset) {
        val map = mutableMapOf<Char, Int>()
        var currentIndex = topContentOffset
        grouped.forEach { (char, group) ->
            map[char] = currentIndex          // stickyHeader index
            currentIndex += 1 + group.size   // header + N contact items
        }
        map
    }

    val scope = rememberCoroutineScope()
    var draggingChar by remember { mutableStateOf<Char?>(null) }

    val scrollingChar by remember(alphabetIndices) {
        derivedStateOf {
            val firstVisible = listState.firstVisibleItemIndex
            alphabetIndices.entries
                .filter { it.value <= firstVisible }
                .maxByOrNull { it.value }
                ?.key ?: alphabetIndices.keys.firstOrNull()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            if (topContent != null) {
                item(key = "search_bar_pill", contentType = "searchBar") {
                    topContent()
                }
            }
            if (isAlphabetical) {
                grouped.forEach { (initial, contactsForChar) ->
                    // ── Letter header ──────────────────────────────────────────
                    stickyHeader(key = "header_$initial", contentType = "letterHeader") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = initial.toString(),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }

                    // ── One lazy item per contact for smooth scrolling ─────────
                    itemsIndexed(
                        items = contactsForChar,
                        key = { _, contact -> "${initial}_${contact.id}" },
                        contentType = { _, _ -> "contact" }
                    ) { index, contact ->
                        val isOnly   = contactsForChar.size == 1
                        val isFirst  = index == 0
                        val isLast   = index == contactsForChar.lastIndex

                        val shape = when {
                            isOnly  -> RoundedCornerShape(CARD_RADIUS)
                            isFirst -> RoundedCornerShape(
                                topStart = CARD_RADIUS, topEnd = CARD_RADIUS,
                                bottomStart = INNER_RADIUS, bottomEnd = INNER_RADIUS
                            )
                            isLast  -> RoundedCornerShape(
                                topStart = INNER_RADIUS, topEnd = INNER_RADIUS,
                                bottomStart = CARD_RADIUS, bottomEnd = CARD_RADIUS
                            )
                            else    -> RoundedCornerShape(INNER_RADIUS)
                        }

                        Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                            RivoScrollAnimatedItem(delayMs = 0L) {
                                Surface(
                                    shape = shape,
                                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column {
                                        ContactListItem(
                                            contact = contact,
                                            navigator = navigator,
                                            selectionMode = selectionMode,
                                            isSelected = selectedContacts.contains(contact.id),
                                            onSelectMode = { onSelectMode(contact) },
                                            onSelectToggle = { onSelectToggle(contact) }
                                        )
                                        if (!isLast) {
                                            HorizontalDivider(
                                                modifier = Modifier.padding(horizontal = 16.dp),
                                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Gap between letter groups
                        if (isLast) {
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }
            } else {
                // Non-alphabetical sort order (Date added or Frequently)
                itemsIndexed(
                    items = contacts,
                    key = { _, contact -> "sorted_${contact.id}" },
                    contentType = { _, _ -> "contact" }
                ) { index, contact ->
                    val isOnly   = contacts.size == 1
                    val isFirst  = index == 0
                    val isLast   = index == contacts.lastIndex

                    val shape = when {
                        isOnly  -> RoundedCornerShape(CARD_RADIUS)
                        isFirst -> RoundedCornerShape(
                            topStart = CARD_RADIUS, topEnd = CARD_RADIUS,
                            bottomStart = INNER_RADIUS, bottomEnd = INNER_RADIUS
                        )
                        isLast  -> RoundedCornerShape(
                            topStart = INNER_RADIUS, topEnd = INNER_RADIUS,
                            bottomStart = CARD_RADIUS, bottomEnd = CARD_RADIUS
                        )
                        else    -> RoundedCornerShape(INNER_RADIUS)
                    }

                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        RivoScrollAnimatedItem(delayMs = 0L) {
                            Surface(
                                shape = shape,
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    ContactListItem(
                                        contact = contact,
                                        navigator = navigator,
                                        selectionMode = selectionMode,
                                        isSelected = selectedContacts.contains(contact.id),
                                        onSelectMode = { onSelectMode(contact) },
                                        onSelectToggle = { onSelectToggle(contact) }
                                    )
                                    if (!isLast) {
                                        HorizontalDivider(
                                            modifier = Modifier.padding(horizontal = 16.dp),
                                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (isLast) {
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }
            }
        }

        if (isAlphabetical) {
            AlphabetSideBar(
                alphabet = alphabetIndices.keys.toList(),
                selectedCharProvider = { draggingChar ?: scrollingChar },
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 4.dp),
                onLetterSelected = { char ->
                    draggingChar = char
                    val index = alphabetIndices[char] ?: return@AlphabetSideBar
                    scope.launch { listState.scrollToItem(index) }
                },
                onDragEnd = { draggingChar = null }
            )

            if (draggingChar != null) {
                Surface(
                    modifier = Modifier
                        .size(100.dp)
                        .align(Alignment.Center),
                    shape = RoundedCornerShape(40.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shadowElevation = 8.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = draggingChar.toString(),
                            style = MaterialTheme.typography.displayLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }
    }
}

/**
 * Renders a single contact row with the full long-press context menu (Select, View, Edit,
 * Copy number, Share, Move, Favourite, Fake Call, Delete). Used both by the main A-Z contacts
 * list ([AZListContent]) and by [com.modiprincekr.thedialer.view.screen.ContactSearchContent]
 * so that contacts found via search get the exact same context menu — including the same
 * Settings → Appearance → "Context Menu Elements" (Contacts) show/hide + ordering.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContactListItem(
    contact: Contact,
    navigator: DestinationsNavigator,
    selectionMode: Boolean = false,
    isSelected: Boolean = false,
    onSelectMode: () -> Unit = {},
    onSelectToggle: () -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val prefs = koinInject<PreferenceManager>()
    val contactsVM: ContactsViewModel = koinActivityViewModel()
    var showMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showMoveDialog by remember { mutableStateOf(false) }
    var horizontalDragDetected by remember { mutableStateOf(false) }

    val settingsVer by prefs.settingsChanged.collectAsState()
    val showAvatarsInContacts = remember(settingsVer) {
        prefs.getBoolean(PreferenceManager.KEY_SHOW_AVATARS_CONTACTS, true)
    }
    val fakeCallInContextMenu = remember(settingsVer) {
        prefs.getBoolean(PreferenceManager.KEY_FAKE_CALL_IN_CONTEXT_MENU, false)
    }
    var showFakeCallSheet by remember { mutableStateOf(false) }
    var showCallChatViaPicker by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (showMenu) 0.97f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "contactItemScale"
    )

    val headline = contact.name.ifEmpty {
        contact.phoneNumbers.firstOrNull() ?: "Unknown"
    }

    // Delete confirmation dialog
    if (showDeleteConfirm) {
        DeleteContactDialog(
            contactName = headline,
            contactId = contact.id,
            contactsViewModel = contactsVM,
            onDeleted = {
                showDeleteConfirm = false
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    if (showFakeCallSheet) {
        FakeCallAddSheet(
            mode = AddMode.Number,
            initialNumber = contact.phoneNumbers.firstOrNull() ?: "",
            initialDisplayName = headline,
            onDismiss = { showFakeCallSheet = false },
            onSave = { entry, exactTriggerOverride ->
                FakeCallManager.addEntry(context, prefs, entry, exactTriggerOverride)
                showFakeCallSheet = false
            }
        )
    }

    if (showMoveDialog) {
        val moveTargets = remember { contactsVM.getSaveTargets() }
        MoveContactDialog(
            contactName = headline,
            targets = moveTargets,
            onSelect = { target ->
                showMoveDialog = false
                contactsVM.moveContact(contact, target) { success ->
                    Toast.makeText(
                        context,
                        if (success) "Moved to ${target.label}" else "Couldn't move contact",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            onDismiss = { showMoveDialog = false }
        )
    }

        val colorScheme = MaterialTheme.colorScheme
        val leftSwipeKey = remember(settingsVer) { prefs.getSwipeAction("contacts", "left") }
        val rightSwipeKey = remember(settingsVer) { prefs.getSwipeAction("contacts", "right") }
        val leftSwipeAction = remember(leftSwipeKey, colorScheme) { SwipeActionHelper.resolveActionItem(leftSwipeKey, colorScheme) }
        val rightSwipeAction = remember(rightSwipeKey, colorScheme) { SwipeActionHelper.resolveActionItem(rightSwipeKey, colorScheme) }

    var avatarCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var rowCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val recordAvatarClick: () -> Unit = {
        avatarCoords?.let { coords ->
            val center = coords.boundsInRoot().center
            val rootSize = coords.findRootCoordinates().size
            com.modiprincekr.thedialer.view.theme.SettingsClickTracker.recordTap(
                center.x, center.y, rootSize.width.toFloat(), rootSize.height.toFloat()
            )
        } ?: rowCoords?.let { coords ->
            val bounds = coords.boundsInRoot()
            val rootSize = coords.findRootCoordinates().size
            com.modiprincekr.thedialer.view.theme.SettingsClickTracker.recordTap(
                bounds.left + 38f, bounds.center.y, rootSize.width.toFloat(), rootSize.height.toFloat()
            )
        } ?: com.modiprincekr.thedialer.view.theme.SettingsClickTracker.recordNormalized(0.12f, 0.5f)
    }

    val handleSwipeAction: (String) -> Unit = { actionKey ->
        val primaryNumber = prefs.getContactDefaultNumber(contact.id)?.takeIf { it in contact.phoneNumbers }
        val numToCall = primaryNumber ?: contact.phoneNumbers.firstOrNull().orEmpty()
        when (actionKey) {
            "call", "call_back" -> {
                if (numToCall.isNotBlank()) makeCall(context, numToCall)
            }
            "send_text" -> {
                if (numToCall.isNotBlank()) {
                    try {
                        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$numToCall"))
                        context.startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
            "delete", "delete_contact" -> {
                showDeleteConfirm = true
            }
            "select" -> onSelectMode()
            "view_contact" -> {
                recordAvatarClick()
                navigator.navigate(ContactDetailsScreenDestination(contactId = contact.id))
            }
            "edit_contact" -> {
                navigator.navigate(ContactEditScreenDestination(contactId = contact.id))
            }
            "copy_number" -> {
                if (numToCall.isNotBlank()) {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("phone_number", numToCall))
                    Toast.makeText(context, "Number copied", Toast.LENGTH_SHORT).show()
                }
            }
            "share", "share_contact" -> {
                val shareText = if (numToCall.isNotBlank()) "${contact.name}: $numToCall" else contact.name
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, shareText)
                }
                context.startActivity(Intent.createChooser(intent, "Share contact"))
            }
            "toggle_favorite" -> contactsVM.toggleFavorite(contact)
            "block_contact" -> {
                val number = contact.phoneNumbers.firstOrNull()
                if (!number.isNullOrBlank()) {
                    val isBlocked = BlockedNumbersManager.isBlocked(context, prefs, number)
                    BlockedNumbersManager.toggle(context, prefs, number)
                    Toast.makeText(
                        context,
                        if (isBlocked) "Contact unblocked" else "Contact blocked",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            "call_chat_via" -> showCallChatViaPicker = true
            "search_truecaller" -> {
                if (numToCall.isNotBlank()) {
                    val isLaunched = com.modiprincekr.thedialer.controller.util.openTruecaller(context, numToCall)
                    if (!isLaunched) {
                        Toast.makeText(context, "Truecaller is not installed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            "fake_call" -> showFakeCallSheet = true
            "move_contact" -> showMoveDialog = true
        }
    }

    Box(modifier = Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale }) {
        SwipeableItemContainer(
            leftAction = leftSwipeAction,
            rightAction = rightSwipeAction,
            onSwipeLeft = { handleSwipeAction(leftSwipeKey) },
            onSwipeRight = { handleSwipeAction(rightSwipeKey) },
            enabled = !selectionMode,
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { coords -> rowCoords = coords }
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {
                            if (selectionMode) {
                                onSelectToggle()
                            } else {
                                if (prefs.getBoolean(PreferenceManager.KEY_APP_HAPTICS, true)) {
                                    performAppHaptic(
                                        context,
                                        prefs.getString(PreferenceManager.KEY_APP_HAPTICS_STRENGTH, "light") ?: "light",
                                        prefs.getFloat(PreferenceManager.KEY_HAPTICS_CUSTOM_INTENSITY, 0.5f)
                                    )
                                }
                                recordAvatarClick()
                                navigator.navigate(ContactDetailsScreenDestination(contactId = contact.id))
                            }
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            showMenu = true
                        }
                    )
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showAvatarsInContacts) {
                    ExpressiveAvatar(
                        name = headline,
                        photoUri = contact.photoUri,
                        size = 48.dp,
                        modifier = Modifier
                            .size(48.dp)
                            .onGloballyPositioned { coords -> avatarCoords = coords }
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = headline,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    val primaryNumber = remember(settingsVer, contact.id, contact.phoneNumbers) {
                        prefs.getContactDefaultNumber(contact.id)?.takeIf { it in contact.phoneNumbers }
                    }
                    val numberToDisplay = primaryNumber ?: contact.phoneNumbers.firstOrNull()
                    if (!numberToDisplay.isNullOrEmpty()) {
                        Text(
                            text = numberToDisplay,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = selectionMode,
            enter = fadeIn(tween(200)) + expandHorizontally(tween(200)),
            exit  = fadeOut(tween(300)) + shrinkHorizontally(tween(300)),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onSelectToggle() },
                modifier = Modifier.padding(end = 8.dp)
            )
        }

        if (showMenu && !selectionMode) {
            val hasNumber = !contact.phoneNumbers.firstOrNull().isNullOrEmpty()
            val contactNumberBlocked = remember(settingsVer, hasNumber, contact.phoneNumbers) {
                hasNumber && BlockedNumbersManager.isBlocked(context, prefs, contact.phoneNumbers.firstOrNull())
            }
            val hasWhatsApp = remember(context) { isAnyPackageInstalled(context, WHATSAPP_PACKAGES) }
            val hasTelegram = remember(context) { isTelegramInstalled(context) }
            val hasGoogleMeet = remember(context) { isGoogleMeetInstalled(context) }
            val hasTruecaller = remember(context) { isTruecallerInstalled(context) }
            val hasAnySocialApp = hasWhatsApp || hasTelegram || hasGoogleMeet || hasTruecaller

            val contactContextMenuKeys = remember(settingsVer, hasNumber, fakeCallInContextMenu, contact.isFavorite, hasAnySocialApp) {
                com.modiprincekr.thedialer.controller.util.ContextMenuPrefs.resolvedKeys(
                    prefs,
                    com.modiprincekr.thedialer.controller.util.ContextMenuPrefs.SECTION_CONTACTS,
                    listOf("select", "call", "view_contact", "edit_contact", "copy_number", "share_contact", "call_chat_via", "send_text", "move_contact", "toggle_favorite", "block_contact", "fake_call", "delete_contact")
                ).filter { key ->
                    when (key) {
                        "call" -> hasNumber
                        "copy_number" -> hasNumber
                        "block_contact" -> hasNumber
                        "fake_call" -> fakeCallInContextMenu
                        "call_chat_via" -> hasNumber && hasAnySocialApp
                        "send_text" -> hasNumber
                        else -> true
                    }
                }
            }

            RivoDropdownMenu(
                expanded         = showMenu && !selectionMode,
                onDismissRequest = { showMenu = false }
            ) {
            fun groupOf(key: String) = when (key) {
                "select" -> 0
                "call", "view_contact", "edit_contact", "copy_number", "share_contact", "call_chat_via", "send_text" -> 1
                "move_contact", "toggle_favorite", "block_contact", "fake_call" -> 2
                "delete_contact" -> 3
                else -> 1
            }
            var previousGroup: Int? = null
            contactContextMenuKeys.forEach { key ->
                val group = groupOf(key)
                if (previousGroup != null && group != previousGroup) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    )
                }
                previousGroup = group
                when (key) {
                    "select" -> RivoDropdownMenuItem(
                        text     = "Select",
                        icon     = Icons.Default.CheckBox,
                        iconTint = Color(0xFF9C27B0),
                        onClick  = {
                            showMenu = false
                            onSelectMode()
                        }
                    )
                    "call" -> {
                        val hasTwoSims = remember(settingsVer) {
                            prefs.getActiveSimCount() >= 2 || run {
                                val tm = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                                try { (tm?.callCapablePhoneAccounts?.size ?: 0) >= 2 } catch (_: Throwable) { false }
                            }
                        }
                        val primaryNumber = remember(settingsVer, contact.id, contact.phoneNumbers) {
                            prefs.getContactDefaultNumber(contact.id)?.takeIf { it in contact.phoneNumbers }
                        }
                        val numToCall = primaryNumber ?: contact.phoneNumbers.firstOrNull().orEmpty()

                        val sim1Color = remember(settingsVer) { Color(prefs.getInt(PreferenceManager.KEY_SIM1_COLOR, PreferenceManager.DEFAULT_SIM1_COLOR)) }
                        val sim2Color = remember(settingsVer) { Color(prefs.getInt(PreferenceManager.KEY_SIM2_COLOR, PreferenceManager.DEFAULT_SIM2_COLOR)) }
                        val tm = remember(context) { context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager }
                        val accounts = try { tm?.callCapablePhoneAccounts } catch (_: Throwable) { null } ?: emptyList()
                        val account1 = getPhoneAccountForSimSlot(context, accounts, 0)
                        val account2 = getPhoneAccountForSimSlot(context, accounts, 1)

                        RivoDropdownMenuItem(
                            text     = "Call",
                            icon     = Icons.Default.Call,
                            iconTint = Color(0xFF4CAF50),
                            onClick  = {
                                showMenu = false
                                if (numToCall.isNotBlank()) {
                                    makeCall(context, numToCall)
                                }
                            },
                            trailingContent = if (hasTwoSims && numToCall.isNotBlank()) {
                                {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            onClick = {
                                                showMenu = false
                                                makeCall(context, numToCall, account1)
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            modifier = Modifier.size(width = 36.dp, height = 32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                SimSlotBadge(slot = 0)
                                            }
                                        }
                                        Surface(
                                            onClick = {
                                                showMenu = false
                                                makeCall(context, numToCall, account2)
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            modifier = Modifier.size(width = 36.dp, height = 32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                SimSlotBadge(slot = 1)
                                            }
                                        }
                                    }
                                }
                            } else null
                        )
                    }
                    "view_contact" -> RivoDropdownMenuItem(
                        text     = "View contact",
                        icon     = Icons.Default.Person,
                        iconTint = Color(0xFF2196F3),
                        onClick  = {
                            showMenu = false
                            recordAvatarClick()
                            navigator.navigate(ContactDetailsScreenDestination(contactId = contact.id))
                        }
                    )
                    "edit_contact" -> RivoDropdownMenuItem(
                        text     = "Edit contact",
                        icon     = Icons.Default.Edit,
                        iconTint = Color(0xFF9C27B0),
                        onClick  = {
                            showMenu = false
                            navigator.navigate(ContactEditScreenDestination(contactId = contact.id))
                        }
                    )
                    "copy_number" -> RivoDropdownMenuItem(
                        text     = "Copy number",
                        icon     = Icons.Default.ContentCopy,
                        iconTint = Color(0xFF009688),
                        onClick  = {
                            showMenu = false
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val primaryNum = prefs.getContactDefaultNumber(contact.id)?.takeIf { it in contact.phoneNumbers }
                            val numToCopy = primaryNum ?: contact.phoneNumbers.firstOrNull() ?: ""
                            clipboard.setPrimaryClip(ClipData.newPlainText("Phone number", numToCopy))
                            Toast.makeText(context, "Number copied", Toast.LENGTH_SHORT).show()
                        }
                    )
                    "call_chat_via" -> RivoDropdownMenuItem(
                        text     = "Call/Chat Via",
                        icon     = Icons.AutoMirrored.Filled.Chat,
                        iconTint = Color(0xFF00BFA5),
                        onClick  = {
                            showMenu = false
                            showCallChatViaPicker = true
                        }
                    )
                    "send_text" -> RivoDropdownMenuItem(
                        text     = "Send text",
                        icon     = Icons.AutoMirrored.Filled.Message,
                        iconTint = Color(0xFF009688),
                        onClick  = {
                            showMenu = false
                            val primaryNum = prefs.getContactDefaultNumber(contact.id)?.takeIf { it in contact.phoneNumbers }
                            val numToSend = primaryNum ?: contact.phoneNumbers.firstOrNull() ?: ""
                            if (numToSend.isNotBlank()) {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:$numToSend"))
                                context.startActivity(intent)
                            }
                        }
                    )
                    "share_contact" -> RivoDropdownMenuItem(
                        text     = "Share contact",
                        icon     = Icons.Default.Share,
                        iconTint = Color(0xFFFF9800),
                        onClick  = {
                            showMenu = false
                            val hideDuplicates = prefs.getBoolean(PreferenceManager.KEY_HIDE_DUPLICATE_NUMBERS_IN_CONTACT, true)
                            val numbersToShare = if (hideDuplicates) deduplicatePhoneNumbers(contact.phoneNumbers) else contact.phoneNumbers
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "${contact.name}\n${numbersToShare.joinToString(", ")}")
                            }
                            context.startActivity(Intent.createChooser(intent, "Share contact"))
                        }
                    )
                    "toggle_favorite" -> RivoDropdownMenuItem(
                        text     = if (contact.isFavorite) "Remove from Favourites" else "Add to Favourites",
                        icon     = Icons.Default.Favorite,
                        iconTint = if (contact.isFavorite) Color(0xFFF44336) else Color(0xFFE91E63),
                        isDestructive = contact.isFavorite,
                        onClick  = {
                            showMenu = false
                            contactsVM.toggleFavorite(contact)
                        }
                    )
                    "move_contact" -> RivoDropdownMenuItem(
                        text     = "Move contact",
                        icon     = Icons.Default.DriveFileMove,
                        iconTint = Color(0xFF00897B),
                        onClick  = {
                            showMenu = false
                            showMoveDialog = true
                        }
                    )
                    "block_contact" -> RivoDropdownMenuItem(
                        text     = if (contactNumberBlocked) "Unblock contact" else "Block contact",
                        icon     = if (contactNumberBlocked) Icons.Default.RemoveCircleOutline else Icons.Default.Block,
                        iconTint = if (contactNumberBlocked) Color(0xFF4CAF50) else Color(0xFFFF9800),
                        isDestructive = false,
                        onClick  = {
                            showMenu = false
                            val number = contact.phoneNumbers.firstOrNull()
                            if (!number.isNullOrBlank()) {
                                BlockedNumbersManager.toggle(context, prefs, number)
                                Toast.makeText(
                                    context,
                                    if (contactNumberBlocked) "Contact unblocked" else "Contact blocked",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    )
                    "fake_call" -> RivoDropdownMenuItem(
                        text     = "Fake Call",
                        icon     = Icons.Outlined.PhoneCallback,
                        iconTint = MaterialTheme.colorScheme.primary,
                        onClick  = {
                            showMenu = false
                            showFakeCallSheet = true
                        }
                    )
                    "delete_contact" -> RivoDropdownMenuItem(
                        text     = "Delete contact",
                        icon     = Icons.Default.Delete,
                        iconTint = Color(0xFFF44336),
                        isDestructive = true,
                        onClick  = {
                            showMenu = false
                            showDeleteConfirm = true
                        }
                    )
                }
            }
        }
        }
    }

    val hideDuplicatesInContact = remember(settingsVer) { prefs.getBoolean(PreferenceManager.KEY_HIDE_DUPLICATE_NUMBERS_IN_CONTACT, true) }
    val displayContactNumbers = remember(contact.phoneNumbers, hideDuplicatesInContact) {
        val raw = contact.phoneNumbers.filter { it.isNotBlank() }
        if (hideDuplicatesInContact) deduplicatePhoneNumbers(raw) else raw
    }

    CallChatViaOverlay(
        phoneNumber = displayContactNumbers.firstOrNull(),
        phoneNumbers = displayContactNumbers,
        showPicker = showCallChatViaPicker,
        onPickerDismiss = { showCallChatViaPicker = false },
        showGoogleMeet = true
    )
} // end AZListContent

@Composable
fun AlphabetSideBar(
    alphabet: List<Char>,
    selectedChar: Char? = null,
    selectedCharProvider: (() -> Char?)? = null,
    modifier: Modifier = Modifier,
    onLetterSelected: (Char) -> Unit,
    onDragEnd: () -> Unit
) {
    var columnHeight by remember { mutableStateOf(0) }

    Surface(
        modifier = modifier
            .width(24.dp)
            .wrapContentHeight()
            .onGloballyPositioned { columnHeight = it.size.height }
            .pointerInput(alphabet) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val pickLetter: (Float) -> Unit = { y ->
                        if (columnHeight > 0 && alphabet.isNotEmpty()) {
                            val itemHeight = columnHeight.toFloat() / alphabet.size
                            val index = (y / itemHeight).toInt().coerceIn(0, alphabet.lastIndex)
                            alphabet.getOrNull(index)?.let { onLetterSelected(it) }
                        }
                    }
                    pickLetter(down.position.y)
                    try {
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            if (!change.pressed) break
                            pickLetter(change.position.y)
                            change.consume()
                        }
                    } finally {
                        onDragEnd()
                    }
                }
            },
        color = Color.Transparent,
        shape = RoundedCornerShape(12.dp)
    ) {
        val activeChar = selectedCharProvider?.invoke() ?: selectedChar
        Column(
            modifier = Modifier.padding(vertical = 8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            alphabet.forEach { char ->
                val isSelected = char == activeChar
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = char.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

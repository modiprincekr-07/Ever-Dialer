package com.modiprincekr.thedialer

val APP_NAME = "The Dialer"
// Sourced from app/build.gradle's defaultConfig.versionName — never hardcode it here,
// BuildConfig.VERSION_NAME is regenerated from Gradle on every build.
val APP_VERSION = BuildConfig.VERSION_NAME
val BUILD_NUMBER = "20261103"
val PATREON_URL = "https://www.patreon.com/c/GrinchDev"
val DISCORD_URL = "https://discord.gg/NtEvU3726e"
val GITHUB_URL = "https://github.com/hari161008/Ever-Dialer"
val TELEGRAM_SUPPORT_URL = "https://t.me/EverlastingAndroidTweak"
val TELEGRAM_CHANNEL_URL = "https://t.me/CoolAppStore"
val EVERLASTING_TWEAK_URL = "https://hari161008.github.io/Website-For-Everlasting-Android-Tweak/Ratings%20Reviews/Ratings%20and%20Reviews%20v3.html"
val TELEGRAM_DEV_URL = "https://t.me/hariprabhu1008"
val GITHUB_RELEASES_URL = "https://github.com/hari161008/Ever-Dialer/releases"
val GITHUB_API_RELEASES = "https://api.github.com/repos/hari161008/Ever-Dialer/releases/latest"
val GITHUB_API_RELEASES_LIST = "https://api.github.com/repos/hari161008/Ever-Dialer/releases"
val DONATE_URL = "https://hariprabhu.com/Ever-Dialer/#donate"
val GITHUB_SPONSORS_URL = "https://github.com/sponsors/hari161008"
val RATINGS_REVIEWS_URL = "https://hariprabhu.com/Ever-Dialer"
val MORE_APPS_URL = "https://hariprabhu.com"

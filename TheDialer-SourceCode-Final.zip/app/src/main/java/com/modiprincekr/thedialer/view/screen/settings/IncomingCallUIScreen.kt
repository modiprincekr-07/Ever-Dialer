package com.modiprincekr.thedialer.view.screen.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.modiprincekr.thedialer.controller.util.PreferenceManager
import com.modiprincekr.thedialer.view.components.RivoAnimatedSection
import com.modiprincekr.thedialer.view.components.RivoExpressiveCard
import com.modiprincekr.thedialer.view.components.RivoListItem
import com.modiprincekr.thedialer.view.components.RivoSwitchListItem
import com.modiprincekr.thedialer.view.components.rivoHeadingColor
import com.modiprincekr.thedialer.view.components.settingsSearchHighlight
import com.modiprincekr.thedialer.view.theme.SettingsTransitionStyle
import com.modiprincekr.thedialer.view.theme.settingsMotionBlur
import com.ramcosta.composedestinations.annotation.Destination
import com.ramcosta.composedestinations.annotation.RootGraph
import com.ramcosta.composedestinations.generated.destinations.CustomBackgroundPickerScreenDestination
import com.ramcosta.composedestinations.generated.destinations.DefaultMessageAppScreenDestination
import com.ramcosta.composedestinations.navigation.DestinationsNavigator
import org.koin.compose.koinInject

@OptIn(ExperimentalMaterial3Api::class)
@Destination<RootGraph>(style = SettingsTransitionStyle::class)
@Composable
fun IncomingCallUIScreen(navigator: DestinationsNavigator, highlightKey: String? = null) {
    val prefs: PreferenceManager = koinInject()
    val settingsVersion by prefs.settingsChanged.collectAsState()
    var highlightedKey by remember { mutableStateOf(highlightKey) }
    var showFullScreenCallUIOnAnyApps by remember {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS, false))
    }
    var showIncomingMuteButton by remember {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_INCOMING_SHOW_MUTE_BUTTON, false))
    }

    val incomingBgType = remember(settingsVersion) {
        prefs.getString(PreferenceManager.KEY_INCOMING_BG_TYPE, "none") ?: "none"
    }
    var showContactPfp by remember {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_INCOMING_SHOW_CONTACT_PFP, true))
    }
    var showForNoPfp by remember(settingsVersion) {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_INCOMING_CUSTOM_PFP_SHOW_FOR_NO_PFP, true))
    }
    var showPhoneNumber by remember {
        mutableStateOf(prefs.getBoolean(PreferenceManager.KEY_INCOMING_SHOW_PHONE_NUMBER, true))
    }

    val bgLabel = when (incomingBgType) {
        "wallpaper" -> "Device Wallpaper"
        "picture"   -> "Custom Picture"
        "video"     -> "Custom Video"
        else        -> "None (Default)"
    }

    val messageAppLabel = when (prefs.getString(PreferenceManager.KEY_DEFAULT_MESSAGE_APP, "calling_card")) {
        "calling_card" -> "Calling Card"
        "whatsapp"     -> "WhatsApp"
        "telegram"     -> "Telegram"
        "ask"          -> "Always ask"
        else           -> "Messages / SMS"
    }

    Scaffold(
        modifier = Modifier.settingsMotionBlur(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            com.modiprincekr.thedialer.view.components.SettingsPillTopAppBar(
                title = "Incoming Call UI",
                onBackClick = { navigator.navigateUp() }
            )
        },
        containerColor = MaterialTheme.colorScheme.surface
    ) { padding ->
        val navBarBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        Column(
            modifier = Modifier
                .padding(top = padding.calculateTopPadding())
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 16.dp + navBarBottom),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            com.modiprincekr.thedialer.view.components.SettingsSearchEntryPoint(navigator = navigator)

            // ── Show Full screen call UI on any apps ───────────────
            RivoAnimatedSection(delayMs = 0L) {
                Column {
                    Text(
                        "Full Screen Display",
                        style = MaterialTheme.typography.labelLarge,
                        color = rivoHeadingColor(),
                        modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                    )
                    RivoExpressiveCard {
                        RivoSwitchListItem(
                            headline = "Show Full screen call UI on any apps",
                            supporting = "Open full screen incoming call UI over any app when a call rings",
                            leadingIcon = Icons.Default.Call,
                            iconContainerColor = Color(0xFF4CAF50),
                            checked = showFullScreenCallUIOnAnyApps,
                            onCheckedChange = {
                                showFullScreenCallUIOnAnyApps = it
                                prefs.setBoolean(PreferenceManager.KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS, it)
                            },
                            modifier = Modifier.settingsSearchHighlight("show_fullscreen_call_ui_on_any_apps", highlightedKey) { highlightedKey = null }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                        RivoSwitchListItem(
                            headline = "Show Mute button",
                            supporting = "Show a button to silence ringtone during incoming calls",
                            leadingIcon = Icons.Default.VolumeOff,
                            iconContainerColor = Color(0xFFFF9800),
                            checked = showIncomingMuteButton,
                            onCheckedChange = {
                                showIncomingMuteButton = it
                                prefs.setBoolean(PreferenceManager.KEY_INCOMING_SHOW_MUTE_BUTTON, it)
                            },
                            modifier = Modifier.settingsSearchHighlight("incoming_show_mute_button", highlightedKey) { highlightedKey = null }
                        )
                    }
                }
            }

            // ── Custom Background & Contact Photo ───────────────
            RivoAnimatedSection(delayMs = 25L) {
                Column {
                    Text(
                        "Appearance & Background",
                        style = MaterialTheme.typography.labelLarge,
                        color = rivoHeadingColor(),
                        modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                    )
                    RivoExpressiveCard {
                        val currentAnswerStyle = remember(settingsVersion) {
                            prefs.getString(PreferenceManager.KEY_INCOMING_ANSWER_STYLE, PreferenceManager.ANSWER_STYLE_MODERN)
                                ?: PreferenceManager.ANSWER_STYLE_MODERN
                        }
                        val answerStyleLabel = when (currentAnswerStyle) {
                            PreferenceManager.ANSWER_STYLE_CLASSIC -> "Google classic"
                            PreferenceManager.ANSWER_STYLE_CALLING_CARD -> "Full Screen Calling Card"
                            else -> "Google modern style"
                        }

                        RivoListItem(
                            headline = "Answer style",
                            supporting = "Currently: $answerStyleLabel",
                            leadingIcon = Icons.Outlined.SwipeVertical,
                            iconContainerColor = Color(0xFF4CAF50),
                            trailingIcon = Icons.Default.ChevronRight,
                            modifier = Modifier.settingsSearchHighlight("incoming_answer_style", highlightedKey) { highlightedKey = null },
                            onClick = { navigator.navigate(com.ramcosta.composedestinations.generated.destinations.AnswerStyleScreenDestination) }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                        RivoListItem(
                            headline = "Background And Contact PFP Customisation",
                            supporting = "Currently: $bgLabel",
                            leadingIcon = Icons.Outlined.Wallpaper,
                            iconContainerColor = Color(0xFF9C27B0),
                            trailingIcon = Icons.Default.ChevronRight,
                            modifier = Modifier.settingsSearchHighlight("incoming_custom_background", highlightedKey) { highlightedKey = null },
                            onClick = { navigator.navigate(CustomBackgroundPickerScreenDestination(isIncoming = true)) }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                        RivoSwitchListItem(
                            headline = "Show Contact PFP",
                            supporting = "Display the caller's avatar photo over the incoming call screen",
                            leadingIcon = Icons.Outlined.AccountCircle,
                            iconContainerColor = Color(0xFF00BCD4),
                            checked = showContactPfp,
                            onCheckedChange = {
                                showContactPfp = it
                                prefs.setBoolean(PreferenceManager.KEY_INCOMING_SHOW_CONTACT_PFP, it)
                            },
                            modifier = Modifier.settingsSearchHighlight("incoming_show_contact_pfp", highlightedKey) { highlightedKey = null }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                        com.modiprincekr.thedialer.view.components.RivoCheckboxListItem(
                            headline = "Show PFP for non-contacts or non-PFP contacts",
                            supporting = "Display custom contact PFP or default avatar for callers without a contact photo",
                            leadingIcon = Icons.Outlined.Face,
                            iconContainerColor = Color(0xFF4CAF50),
                            checked = showForNoPfp,
                            onCheckedChange = {
                                showForNoPfp = it
                                prefs.setBoolean(PreferenceManager.KEY_INCOMING_CUSTOM_PFP_SHOW_FOR_NO_PFP, it)
                            },
                            modifier = Modifier.settingsSearchHighlight("incoming_custom_pfp_show_for_no_pfp", highlightedKey) { highlightedKey = null }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                        RivoSwitchListItem(
                            headline = "Show Phone Number",
                            supporting = "Display the caller's phone number on the incoming call screen",
                            leadingIcon = Icons.Outlined.Call,
                            iconContainerColor = Color(0xFF4CAF50),
                            checked = showPhoneNumber,
                            onCheckedChange = {
                                showPhoneNumber = it
                                prefs.setBoolean(PreferenceManager.KEY_INCOMING_SHOW_PHONE_NUMBER, it)
                            },
                            modifier = Modifier.settingsSearchHighlight("incoming_show_phone_number", highlightedKey) { highlightedKey = null }
                        )
                    }
                }
            }

            RivoAnimatedSection(delayMs = 40L) {
                    Column {
                        Text(
                            "Quick Actions",
                            style = MaterialTheme.typography.labelLarge,
                            color = rivoHeadingColor(),
                            modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                        )
                        RivoExpressiveCard {
                            // ── Default Message → separate page ───────────────────
                            RivoListItem(
                                headline = "Default Message",
                                supporting = "Currently: $messageAppLabel",
                                leadingIcon = Icons.Default.Send,
                                iconContainerColor = Color(0xFF29B6F6),
                                trailingIcon = Icons.Default.ChevronRight,
                                modifier = Modifier.settingsSearchHighlight("default_message_link", highlightedKey) { highlightedKey = null },
                                onClick = { navigator.navigate(DefaultMessageAppScreenDestination) }
                            )
                        }
                    }
            }

            RivoAnimatedSection(delayMs = 60L) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                Icons.Outlined.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                "Choose which app the Message quick action opens on the " +
                                    "incoming call screen.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
            }
        }
    }
}


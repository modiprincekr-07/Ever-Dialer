package com.modiprincekr.thedialer.controller.util

import android.content.Context
import android.content.SharedPreferences
import com.modiprincekr.thedialer.modal.data.SmsFilterTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferenceManager(context: Context) {
    private val appContext = context.applicationContext
    val context: Context get() = appContext
    private val prefs: SharedPreferences =
        context.getSharedPreferences("rivo_prefs", Context.MODE_PRIVATE)

    /** Number of currently active SIM subscriptions (0, 1, 2+). Never throws. */
    fun getActiveSimCount(): Int {
        return try {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.LOLLIPOP_MR1) return 1
            if (androidx.core.content.ContextCompat.checkSelfPermission(
                    appContext, android.Manifest.permission.READ_PHONE_STATE
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return 1
            val sm = appContext.getSystemService(android.telephony.SubscriptionManager::class.java)
            val list = if (android.os.Build.VERSION_CODES.N <= android.os.Build.VERSION.SDK_INT) {
                sm?.activeSubscriptionInfoList
            } else {
                @Suppress("DEPRECATION")
                android.telephony.SubscriptionManager.from(appContext).activeSubscriptionInfoList
            }
            list?.size ?: 1
        } catch (_: Exception) { 1 }
    }

    /** "Show SIM badges in call logs" should only default to on for dual-SIM (or more)
     *  devices — on a single-SIM device the badge is pure clutter since every entry
     *  would show the same "SIM 1" chip. */
    fun getShowSimsInCallLogsDefault(): Boolean = getActiveSimCount() >= 2

    /** Default-SIM-for-calling behavior should only default to "always ask" on
     *  dual-SIM (or more) devices. On a single-SIM device there is nothing to ask —
     *  default straight to that one SIM so every call just goes out immediately. */
    fun getDefaultSimAskEveryTimeDefault(): Boolean = getActiveSimCount() >= 2

    /** Default value for the "default_sim" pref (0 = ask every time, 1 = SIM 1, 2 = SIM 2).
     *  On a single-SIM device there's nothing to ask about, so default straight to that
     *  one SIM instead of nagging with an "Ask every time" dialog on every call. */
    fun getDefaultSimIndexDefault(): Int = if (getActiveSimCount() == 1) 1 else 0

    private val _settingsChanged = MutableStateFlow(0)
    val settingsChanged: StateFlow<Int> = _settingsChanged.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _settingsChanged.value += 1
    }

    init { prefs.registerOnSharedPreferenceChangeListener(listener) }

    fun getBoolean(key: String, defaultValue: Boolean) = prefs.getBoolean(key, defaultValue)
    fun setBoolean(key: String, value: Boolean)        { prefs.edit().putBoolean(key, value).apply(); _settingsChanged.value += 1 }
    fun getString(key: String, defaultValue: String?)  = prefs.getString(key, defaultValue)
    fun setString(key: String, value: String?)         { prefs.edit().putString(key, value).apply(); _settingsChanged.value += 1 }
    fun getInt(key: String, defaultValue: Int)         = prefs.getInt(key, defaultValue)
    fun setInt(key: String, value: Int)                { prefs.edit().putInt(key, value).apply(); _settingsChanged.value += 1 }
    fun getFloat(key: String, defaultValue: Float)     = prefs.getFloat(key, defaultValue)
    fun setFloat(key: String, value: Float)            { prefs.edit().putFloat(key, value).apply(); _settingsChanged.value += 1 }
    fun getLong(key: String, defaultValue: Long)       = prefs.getLong(key, defaultValue)
    fun setLong(key: String, value: Long)              { prefs.edit().putLong(key, value).apply(); _settingsChanged.value += 1 }
    fun remove(key: String)                            { prefs.edit().remove(key).apply(); _settingsChanged.value += 1 }
    fun contains(key: String): Boolean                 = prefs.contains(key)
    fun getAllKeys(): Set<String>                      = prefs.all.keys
    fun notifyChanged()                                { _settingsChanged.value += 1 }

    fun getContactGifBackground(contactKey: String?): String? {
        if (contactKey.isNullOrBlank()) return null
        return getString("contact_${contactKey}_gif_bg", null)
    }

    fun setContactGifBackground(contactKey: String, uri: String?) {
        if (uri.isNullOrBlank()) {
            remove("contact_${contactKey}_gif_bg")
        } else {
            setString("contact_${contactKey}_gif_bg", uri)
        }
    }

    fun getRingHapticCustomSequence(): com.modiprincekr.thedialer.haptics.CustomHapticSequence {
        val raw = getString(KEY_RING_HAPTIC_CUSTOM_SEQUENCE, "")
        if (raw.isNullOrBlank()) return com.modiprincekr.thedialer.haptics.CustomHapticSequence()
        return try {
            val beats = raw.split(";").mapNotNull { token ->
                val parts = token.split(":")
                if (parts.size == 2) {
                    val ms = parts[0].toLongOrNull()
                    val amp = parts[1].toIntOrNull()
                    if (ms != null && amp != null) com.modiprincekr.thedialer.haptics.HapticBeat(ms, amp) else null
                } else null
            }
            com.modiprincekr.thedialer.haptics.CustomHapticSequence(beats)
        } catch (_: Exception) {
            com.modiprincekr.thedialer.haptics.CustomHapticSequence()
        }
    }

    fun setRingHapticCustomSequence(seq: com.modiprincekr.thedialer.haptics.CustomHapticSequence) {
        val raw = seq.beats.joinToString(";") { "${it.offsetMs}:${it.amplitude}" }
        setString(KEY_RING_HAPTIC_CUSTOM_SEQUENCE, raw)
    }
    /** Returns true if an incoming call from [phoneNumber] should be gated behind biometric. */
    fun shouldGateCallWithBiometric(phoneNumber: String?): Boolean {
        if (!getBoolean(KEY_BIOMETRICS_CALL_LOCK, false)) return false
        if ((getString(KEY_BIOMETRICS_TYPE, "") ?: "").isEmpty()) return false
        val mode = getString(KEY_BIOMETRICS_CALL_LOCK_MODE, "all") ?: "all"
        if (mode == "all") return true
        if (phoneNumber.isNullOrBlank()) return mode == "skip_specified"
        val stored = getString(KEY_BIOMETRICS_CALL_LOCK_NUMBERS, "") ?: ""
        if (stored.isBlank()) return mode == "skip_specified"
        val incoming = phoneNumber.filter { it.isDigit() }.takeLast(10)
        val match = stored.split(",").any { raw ->
            val n = raw.trim().filter { it.isDigit() }.takeLast(10)
            n.isNotEmpty() && (incoming.endsWith(n) || n.endsWith(incoming))
        }
        return if (mode == "specified") match else !match
    }

    fun isPatternVisible(): Boolean = getBoolean(KEY_BIOMETRICS_PATTERN_VISIBLE, true)

    fun getBiometricsBackupType(): String {
        val stored = getString(KEY_BIOMETRICS_BACKUP_TYPE, "") ?: ""
        if (stored == "pattern" && (getString(KEY_BIOMETRICS_PATTERN, "") ?: "").isNotEmpty()) return "pattern"
        if (stored == "password" && (getString(KEY_BIOMETRICS_PASSWORD, "") ?: "").isNotEmpty()) return "password"
        if (stored == "pin" && (getString(KEY_BIOMETRICS_PIN, "") ?: "").isNotEmpty()) return "pin"

        if ((getString(KEY_BIOMETRICS_PATTERN, "") ?: "").isNotEmpty()) return "pattern"
        if ((getString(KEY_BIOMETRICS_PASSWORD, "") ?: "").isNotEmpty()) return "password"
        if ((getString(KEY_BIOMETRICS_PIN, "") ?: "").isNotEmpty()) return "pin"
        return "pin"
    }

    fun getContactSimChoice(contactKey: String, fallbackNumber: String? = null): String {
        val choice = getString(KEY_CONTACT_SIM_CHOICE_PREFIX + contactKey, SIM_CHOICE_SETTINGS) ?: SIM_CHOICE_SETTINGS
        if (choice != SIM_CHOICE_SETTINGS) return choice
        if (!fallbackNumber.isNullOrBlank() && fallbackNumber != contactKey) {
            val numChoice = getString(KEY_CONTACT_SIM_CHOICE_PREFIX + fallbackNumber, SIM_CHOICE_SETTINGS) ?: SIM_CHOICE_SETTINGS
            if (numChoice != SIM_CHOICE_SETTINGS) return numChoice
        }
        return SIM_CHOICE_SETTINGS
    }

    fun setContactSimChoice(contactKey: String, choice: String) =
        setString(KEY_CONTACT_SIM_CHOICE_PREFIX + contactKey, choice)

    fun getDefaultSwipeAction(section: String, direction: String): String = "none"

    fun getSwipeAction(section: String, direction: String): String {
        if (section == "sms") {
            val key = if (direction == "left") KEY_SMS_SWIPE_LEFT_ACTION else KEY_SMS_SWIPE_RIGHT_ACTION
            return getString(key, "none") ?: "none"
        }
        return getString("swipe_action_${section}_${direction}", getDefaultSwipeAction(section, direction)) ?: getDefaultSwipeAction(section, direction)
    }

    fun setSwipeAction(section: String, direction: String, action: String) {
        if (section == "sms") {
            val key = if (direction == "left") KEY_SMS_SWIPE_LEFT_ACTION else KEY_SMS_SWIPE_RIGHT_ACTION
            setString(key, action)
        }
        setString("swipe_action_${section}_${direction}", action)
    }

    /** Per-contact "Choose Default Number" preference (Contact Info, just below "Choose Sim") for
     *  contacts saved with 2+ phone numbers. When set to one of the contact's numbers, the header
     *  call button calls that number directly instead of prompting with the number picker every
     *  time; also used to resolve which number to use for WhatsApp/Telegram/Google Meet quick
     *  actions when the contact has multiple numbers. [contactKey] matches [getContactSimChoice]'s
     *  keying. Returns null when unset (meaning "ask every time", the previous behavior). */
    fun getContactDefaultNumber(contactKey: String): String? =
        getString(KEY_CONTACT_DEFAULT_NUMBER_PREFIX + contactKey, null)

    fun setContactDefaultNumber(contactKey: String, number: String?) =
        setString(KEY_CONTACT_DEFAULT_NUMBER_PREFIX + contactKey, number)

    fun getSpeedDialNumber(digit: String): String? =
        getString(KEY_SPEED_DIAL_PREFIX + digit, null)?.ifBlank { null }

    fun getSpeedDialName(digit: String): String? =
        getString(KEY_SPEED_DIAL_NAME_PREFIX + digit, null)?.ifBlank { null }

    fun setSpeedDial(digit: String, number: String?, name: String? = null) {
        setString(KEY_SPEED_DIAL_PREFIX + digit, number?.trim()?.ifBlank { null })
        setString(KEY_SPEED_DIAL_NAME_PREFIX + digit, name?.trim()?.ifBlank { null })
    }

    fun removeSpeedDial(digit: String) {
        remove(KEY_SPEED_DIAL_PREFIX + digit)
        remove(KEY_SPEED_DIAL_NAME_PREFIX + digit)
    }

    fun clearAllSpeedDials() {
        (1..9).forEach { digit ->
            removeSpeedDial(digit.toString())
        }
    }

    fun getVoicemailNumber(context: Context? = null): String? {
        val custom = getSpeedDialNumber("1")
        if (!custom.isNullOrBlank()) return custom
        if (context != null) {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager
            val carrierVm = try { telephonyManager?.voiceMailNumber } catch (_: Throwable) { null }
            if (!carrierVm.isNullOrBlank()) return carrierVm
        }
        return null
    }

    fun setVoicemailNumber(number: String?) {
        setSpeedDial("1", number, "Voicemail")
    }

    fun getSelectedUssdCountry(context: Context): String =
        com.modiprincekr.thedialer.controller.UssdRepository.getSelectedCountry(context, this)

    fun setSelectedUssdCountry(countryCode: String) {
        setString(KEY_USSD_COUNTRY, countryCode.uppercase())
    }

    fun getCustomUssdCodes(): List<com.modiprincekr.thedialer.controller.UssdCodeItem> {
        val json = getString(KEY_USSD_CUSTOM_CODES, "[]") ?: "[]"
        return try {
            val array = org.json.JSONArray(json)
            val list = mutableListOf<com.modiprincekr.thedialer.controller.UssdCodeItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    com.modiprincekr.thedialer.controller.UssdCodeItem(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        title = obj.getString("title"),
                        code = obj.getString("code"),
                        category = com.modiprincekr.thedialer.controller.UssdCategory.CUSTOM,
                        countryCode = obj.optString("countryCode").takeIf { !it.isNullOrBlank() },
                        brand = obj.optString("brand").takeIf { !it.isNullOrBlank() },
                        isCustom = true,
                        description = obj.optString("description").takeIf { !it.isNullOrBlank() }
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustomUssdCodes(list: List<com.modiprincekr.thedialer.controller.UssdCodeItem>) {
        val array = org.json.JSONArray()
        list.forEach { item ->
            val obj = org.json.JSONObject()
            obj.put("id", item.id)
            obj.put("title", item.title)
            obj.put("code", item.code)
            if (item.countryCode != null) obj.put("countryCode", item.countryCode)
            if (item.brand != null) obj.put("brand", item.brand)
            if (item.description != null) obj.put("description", item.description)
            array.put(obj)
        }
        setString(KEY_USSD_CUSTOM_CODES, array.toString())
    }

    fun addCustomUssdCode(title: String, code: String, description: String? = null): com.modiprincekr.thedialer.controller.UssdCodeItem {
        val current = getCustomUssdCodes().toMutableList()
        val newItem = com.modiprincekr.thedialer.controller.UssdCodeItem(
            id = java.util.UUID.randomUUID().toString(),
            title = title.trim(),
            code = code.trim(),
            category = com.modiprincekr.thedialer.controller.UssdCategory.CUSTOM,
            isCustom = true,
            description = description?.trim()?.ifBlank { null }
        )
        current.add(0, newItem)
        saveCustomUssdCodes(current)
        return newItem
    }

    fun updateCustomUssdCode(id: String, title: String, code: String, description: String? = null) {
        val current = getCustomUssdCodes().map {
            if (it.id == id) it.copy(title = title.trim(), code = code.trim(), description = description?.trim()?.ifBlank { null })
            else it
        }
        saveCustomUssdCodes(current)
    }

    fun deleteCustomUssdCode(id: String) {
        val current = getCustomUssdCodes().filter { it.id != id }
        saveCustomUssdCodes(current)
    }

    fun getPinnedSmsThreads(): Set<Long> =
        getString(KEY_PINNED_SMS_THREADS, "")?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()

    fun isSmsThreadPinned(threadId: Long): Boolean =
        getPinnedSmsThreads().contains(threadId)

    fun setSmsThreadPinned(threadId: Long, pinned: Boolean) {
        val current = getPinnedSmsThreads().toMutableSet()
        if (pinned) current.add(threadId) else current.remove(threadId)
        setString(KEY_PINNED_SMS_THREADS, current.joinToString(","))
    }

    fun getPinnedSmsMessages(): Set<Long> =
        getString(KEY_PINNED_SMS_MESSAGES, "")?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()

    fun isSmsMessagePinned(messageId: Long): Boolean =
        getPinnedSmsMessages().contains(messageId)

    fun setSmsMessagePinned(messageId: Long, pinned: Boolean) {
        val current = getPinnedSmsMessages().toMutableSet()
        if (pinned) current.add(messageId) else current.remove(messageId)
        setString(KEY_PINNED_SMS_MESSAGES, current.joinToString(","))
    }

    fun getStarredSmsMessages(): Set<Long> =
        getString(KEY_STARRED_SMS_MESSAGES, "")?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()

    fun isSmsMessageStarred(messageId: Long): Boolean =
        getStarredSmsMessages().contains(messageId)

    fun setSmsMessageStarred(messageId: Long, starred: Boolean) {
        val current = getStarredSmsMessages().toMutableSet()
        if (starred) current.add(messageId) else current.remove(messageId)
        setString(KEY_STARRED_SMS_MESSAGES, current.joinToString(","))
    }

    fun getMutedSmsAddresses(): Set<String> =
        getString(KEY_MUTED_SMS_ADDRESSES, "")?.split(",")?.map { it.trim().lowercase() }?.filter { it.isNotBlank() }?.toSet() ?: emptySet()

    fun isSmsMuted(address: String): Boolean {
        if (address.isBlank()) return false
        val muted = getMutedSmsAddresses()
        val clean = address.trim().lowercase()
        return muted.any { it == clean || numbersLikelyMatch(it, clean) }
    }

    fun setSmsMuted(address: String, muted: Boolean) {
        val clean = address.trim().lowercase()
        if (clean.isBlank()) return
        val current = getMutedSmsAddresses().toMutableSet()
        if (muted) current.add(clean) else current.removeIf { it == clean || numbersLikelyMatch(it, clean) }
        setString(KEY_MUTED_SMS_ADDRESSES, current.joinToString(","))
    }

    fun getBlockerEngine(): String =
        getString(KEY_BLOCKER_ENGINE, BLOCKER_ENGINE_EVER_DIALER) ?: BLOCKER_ENGINE_EVER_DIALER

    fun setBlockerEngine(engine: String) =
        setString(KEY_BLOCKER_ENGINE, engine)

    fun isEverDialerBlocker(): Boolean =
        getBlockerEngine() == BLOCKER_ENGINE_EVER_DIALER

    fun getSmsCategoryOrder(): List<String> {
        val raw = getString(KEY_SMS_CATEGORY_ORDER, null)
        if (raw.isNullOrBlank()) return DEFAULT_SMS_CATEGORY_ORDER
        return raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
    }

    fun setSmsCategoryOrder(order: List<String>) {
        setString(KEY_SMS_CATEGORY_ORDER, order.joinToString(","))
    }

    fun getHiddenSmsCategories(): Set<String> {
        val raw = getString(KEY_SMS_CATEGORY_HIDDEN, null) ?: return emptySet()
        return raw.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }

    fun setSmsCategoryHidden(categoryId: String, hidden: Boolean) {
        val current = getHiddenSmsCategories().toMutableSet()
        if (hidden) current.add(categoryId) else current.remove(categoryId)
        setString(KEY_SMS_CATEGORY_HIDDEN, current.joinToString(","))
    }

    fun getCustomSmsCategories(): List<SmsCustomCategory> {
        val raw = getString(KEY_SMS_CUSTOM_CATEGORIES, null) ?: return emptyList()
        return try {
            val array = org.json.JSONArray(raw)
            val list = mutableListOf<SmsCustomCategory>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.optString("id")
                val name = obj.optString("name")
                val phonesArray = obj.optJSONArray("contactPhones")
                val phones = mutableListOf<String>()
                if (phonesArray != null) {
                    for (j in 0 until phonesArray.length()) {
                        phones.add(phonesArray.getString(j))
                    }
                }
                if (id.isNotBlank() && name.isNotBlank()) {
                    list.add(SmsCustomCategory(id, name, phones))
                }
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustomSmsCategory(category: SmsCustomCategory) {
        val current = getCustomSmsCategories().toMutableList()
        val idx = current.indexOfFirst { it.id == category.id }
        if (idx >= 0) {
            current[idx] = category
        } else {
            current.add(category)
            val order = getSmsCategoryOrder().toMutableList()
            if (!order.contains(category.id)) {
                order.add(category.id)
                setSmsCategoryOrder(order)
            }
        }
        val array = org.json.JSONArray()
        for (cat in current) {
            val obj = org.json.JSONObject()
            obj.put("id", cat.id)
            obj.put("name", cat.name)
            val phonesArray = org.json.JSONArray()
            for (phone in cat.contactPhones) {
                phonesArray.put(phone)
            }
            obj.put("contactPhones", phonesArray)
            array.put(obj)
        }
        setString(KEY_SMS_CUSTOM_CATEGORIES, array.toString())
    }

    fun deleteCustomSmsCategory(categoryId: String) {
        val current = getCustomSmsCategories().filterNot { it.id == categoryId }
        val array = org.json.JSONArray()
        for (cat in current) {
            val obj = org.json.JSONObject()
            obj.put("id", cat.id)
            obj.put("name", cat.name)
            val phonesArray = org.json.JSONArray()
            for (phone in cat.contactPhones) {
                phonesArray.put(phone)
            }
            obj.put("contactPhones", phonesArray)
            array.put(obj)
        }
        setString(KEY_SMS_CUSTOM_CATEGORIES, array.toString())
        val order = getSmsCategoryOrder().filterNot { it == categoryId }
        setSmsCategoryOrder(order)
        setSmsCategoryHidden(categoryId, false)
        if (getDefaultSmsCategory() == categoryId) {
            setDefaultSmsCategory("all")
        }
    }

    fun getDefaultSmsCategory(): String =
        getString(KEY_DEFAULT_SMS_CATEGORY, "all") ?: "all"

    fun setDefaultSmsCategory(id: String) {
        setString(KEY_DEFAULT_SMS_CATEGORY, id)
    }

    fun getAllSmsCategories(): List<SmsCategoryItem> {
        val custom = getCustomSmsCategories().associateBy { it.id }
        val builtin = mapOf(
            "all" to "All",
            "favourites" to "Favourites",
            "starred" to "Starred",
            "contacts" to "Contacts",
            "unknown" to "Unknown",
            "otp" to "OTP"
        )
        val order = getSmsCategoryOrder()
        val result = mutableListOf<SmsCategoryItem>()
        for (id in order) {
            if (custom.containsKey(id)) {
                val c = custom[id]!!
                result.add(SmsCategoryItem(c.id, c.name, isCustom = true, contactPhones = c.contactPhones))
            } else if (builtin.containsKey(id)) {
                result.add(SmsCategoryItem(id, builtin[id]!!, isCustom = false))
            }
        }
        for ((id, name) in builtin) {
            if (result.none { it.id == id }) {
                result.add(SmsCategoryItem(id, name, isCustom = false))
            }
        }
        for ((id, c) in custom) {
            if (result.none { it.id == id }) {
                result.add(SmsCategoryItem(c.id, c.name, isCustom = true, contactPhones = c.contactPhones))
            }
        }
        return result
    }

    fun resetSmsCategoriesToDefault() {
        setSmsCategoryOrder(DEFAULT_SMS_CATEGORY_ORDER)
        setString(KEY_SMS_CATEGORY_HIDDEN, "")
        setDefaultSmsCategory("all")
    }

    fun getCallCategoryOrder(): List<String> {
        val raw = getString(KEY_CALL_CATEGORY_ORDER, null)
        if (raw.isNullOrBlank()) return DEFAULT_CALL_CATEGORY_ORDER
        return raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
    }

    fun setCallCategoryOrder(order: List<String>) {
        setString(KEY_CALL_CATEGORY_ORDER, order.joinToString(","))
    }

    fun getHiddenCallCategories(): Set<String> {
        val raw = getString(KEY_CALL_CATEGORY_HIDDEN, null) ?: return emptySet()
        return raw.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }

    fun setCallCategoryHidden(categoryId: String, hidden: Boolean) {
        val current = getHiddenCallCategories().toMutableSet()
        if (hidden) current.add(categoryId) else current.remove(categoryId)
        setString(KEY_CALL_CATEGORY_HIDDEN, current.joinToString(","))
    }

    fun getCustomCallCategories(): List<CallCustomCategory> {
        val raw = getString(KEY_CALL_CUSTOM_CATEGORIES, null) ?: return emptyList()
        return try {
            val array = org.json.JSONArray(raw)
            val list = mutableListOf<CallCustomCategory>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.optString("id")
                val name = obj.optString("name")
                val phonesArray = obj.optJSONArray("contactPhones")
                val phones = mutableListOf<String>()
                if (phonesArray != null) {
                    for (j in 0 until phonesArray.length()) {
                        phones.add(phonesArray.getString(j))
                    }
                }
                if (id.isNotBlank() && name.isNotBlank()) {
                    list.add(CallCustomCategory(id, name, phones))
                }
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustomCallCategory(category: CallCustomCategory) {
        val current = getCustomCallCategories().toMutableList()
        val idx = current.indexOfFirst { it.id == category.id }
        if (idx >= 0) {
            current[idx] = category
        } else {
            current.add(category)
            val order = getCallCategoryOrder().toMutableList()
            if (!order.contains(category.id)) {
                order.add(category.id)
                setCallCategoryOrder(order)
            }
        }
        val array = org.json.JSONArray()
        for (cat in current) {
            val obj = org.json.JSONObject()
            obj.put("id", cat.id)
            obj.put("name", cat.name)
            val phonesArray = org.json.JSONArray()
            for (phone in cat.contactPhones) {
                phonesArray.put(phone)
            }
            obj.put("contactPhones", phonesArray)
            array.put(obj)
        }
        setString(KEY_CALL_CUSTOM_CATEGORIES, array.toString())
    }

    fun deleteCustomCallCategory(categoryId: String) {
        val current = getCustomCallCategories().filterNot { it.id == categoryId }
        val array = org.json.JSONArray()
        for (cat in current) {
            val obj = org.json.JSONObject()
            obj.put("id", cat.id)
            obj.put("name", cat.name)
            val phonesArray = org.json.JSONArray()
            for (phone in cat.contactPhones) {
                phonesArray.put(phone)
            }
            obj.put("contactPhones", phonesArray)
            array.put(obj)
        }
        setString(KEY_CALL_CUSTOM_CATEGORIES, array.toString())
        val order = getCallCategoryOrder().filterNot { it == categoryId }
        setCallCategoryOrder(order)
        setCallCategoryHidden(categoryId, false)
        if (getDefaultCallCategory() == categoryId) {
            setDefaultCallCategory("all")
        }
    }

    fun getDefaultCallCategory(): String =
        getString(KEY_DEFAULT_CALL_CATEGORY, "all") ?: "all"

    fun setDefaultCallCategory(id: String) {
        setString(KEY_DEFAULT_CALL_CATEGORY, id)
    }

    fun getAllCallCategories(): List<CallCategoryItem> {
        val custom = getCustomCallCategories().associateBy { it.id }
        val builtin = mapOf(
            "all" to "All",
            "favourites" to "Favourites",
            "contacts" to "Contacts",
            "unknown" to "Unknown",
            "missed" to "Missed",
            "incoming" to "Incoming",
            "outgoing" to "Outgoing",
            "whatsapp" to "WhatsApp",
            "alternate" to "Alternate"
        )
        val order = getCallCategoryOrder()
        val result = mutableListOf<CallCategoryItem>()
        for (id in order) {
            if (custom.containsKey(id)) {
                val c = custom[id]!!
                result.add(CallCategoryItem(c.id, c.name, isCustom = true, contactPhones = c.contactPhones))
            } else if (builtin.containsKey(id)) {
                result.add(CallCategoryItem(id, builtin[id]!!, isCustom = false))
            }
        }
        for ((id, name) in builtin) {
            if (result.none { it.id == id }) {
                result.add(CallCategoryItem(id, name, isCustom = false))
            }
        }
        for ((id, c) in custom) {
            if (result.none { it.id == id }) {
                result.add(CallCategoryItem(c.id, c.name, isCustom = true, contactPhones = c.contactPhones))
            }
        }
        return result
    }

    fun resetCallCategoriesToDefault() {
        setCallCategoryOrder(DEFAULT_CALL_CATEGORY_ORDER)
        setString(KEY_CALL_CATEGORY_HIDDEN, "")
        setDefaultCallCategory("all")
    }

    fun isNotifyUpdatesEnabled(): Boolean = getBoolean(KEY_NOTIFY_UPDATES_ENABLED, false)
    fun getNotifyUpdatesValue(): Int = getInt(KEY_NOTIFY_UPDATES_VALUE, 6).coerceAtLeast(1)
    fun getNotifyUpdatesUnit(): String = getString(KEY_NOTIFY_UPDATES_UNIT, "hours") ?: "hours"



    /** Returns the user-configured tab order (Settings > Appearance > Tab Sections) as an
     *  ordered list of tab keys (e.g. "favorites", "calls", "contacts", "recordings", "notes").
     *  This is the single source of truth for tab ordering — both the bottom nav bar and the
     *  page-switching transition logic derive their order from this, so reordering tabs in
     *  settings never gets out of sync with the slide-animation direction on the main screen. */
    fun getTabOrder(): List<String> = parseTabOrder(getString(KEY_TAB_ORDER, null))

    fun getSmsFilterOrder(): List<SmsFilterTab> =
        SmsFilterTab.parseOrder(getString(KEY_SMS_FILTER_ORDER, null))

    fun setSmsFilterOrder(order: List<SmsFilterTab>) =
        setString(KEY_SMS_FILTER_ORDER, SmsFilterTab.serializeOrder(order))

    fun getSmsSelectedFilter(): SmsFilterTab {
        val id = getString(KEY_SMS_SELECTED_FILTER, SmsFilterTab.ALL.id) ?: SmsFilterTab.ALL.id
        return SmsFilterTab.fromId(id)
    }

    fun setSmsSelectedFilter(tab: SmsFilterTab) =
        setString(KEY_SMS_SELECTED_FILTER, tab.id)

    fun getContactInfoOrder(): List<String> = parseContactInfoOrder(getString(KEY_CONTACT_INFO_ORDER, null))

    fun getMaterialTheme(): String =
        getString(KEY_MATERIAL_THEME, MATERIAL_THEME_YOU) ?: MATERIAL_THEME_YOU

    fun setMaterialTheme(theme: String) =
        setString(KEY_MATERIAL_THEME, theme)

    fun getAnimationStyle(): String =
        getString(KEY_ANIMATION_STYLE, ANIMATION_STYLE_ZOOM) ?: ANIMATION_STYLE_ZOOM

    fun setAnimationStyle(style: String) =
        setString(KEY_ANIMATION_STYLE, style)

    fun getSaturatedModesSet(): Set<String> {
        val raw = getString(KEY_SATURATED_MODES, DEFAULT_SATURATED_MODES) ?: DEFAULT_SATURATED_MODES
        return raw.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
    }

    fun getSaturatedTarget(): String =
        getString(KEY_SATURATED_TARGET, SATURATED_TARGET_CONTAINER) ?: SATURATED_TARGET_CONTAINER

    fun setSaturatedTarget(target: String) =
        setString(KEY_SATURATED_TARGET, target)

    fun isSaturatedForTheme(isDark: Boolean): Boolean {
        if (!getBoolean(KEY_SATURATED_COLORS, false)) return false
        val modes = getSaturatedModesSet()
        val themeMode = getString(KEY_THEME_MODE, "auto") ?: "auto"
        val effectiveMode = when (themeMode) {
            "white" -> "white"
            "black" -> "black"
            "light" -> "light"
            "dark" -> "dark"
            "auto_bw" -> if (isDark) "black" else "white"
            else -> if (isDark) "dark" else "light"
        }
        return modes.contains(effectiveMode)
    }

    fun getSolidIconsStyle(isDark: Boolean): String {
        val saturated = getBoolean(KEY_SATURATED_COLORS, false)
        val defaultDark = if (saturated) SOLID_ICONS_STYLE_BRIGHT else SOLID_ICONS_STYLE_DIM
        val defaultLight = SOLID_ICONS_STYLE_DIM
        return if (isDark) {
            getString(KEY_SOLID_ICONS_DARK, defaultDark) ?: defaultDark
        } else {
            getString(KEY_SOLID_ICONS_LIGHT, defaultLight) ?: defaultLight
        }
    }

    fun getSaturationLevel(isDark: Boolean): Float {
        val defaultLevel = getFloat(KEY_SATURATION_LEVEL, 1.0f)
        return if (isDark) {
            getFloat(KEY_SATURATION_LEVEL_DARK, defaultLevel)
        } else {
            getFloat(KEY_SATURATION_LEVEL_LIGHT, defaultLevel)
        }
    }

    fun getContactGroups(): List<com.modiprincekr.thedialer.modal.data.ContactGroup> {
        val raw = getString(KEY_CONTACT_GROUPS, null) ?: return emptyList()
        return try {
            val jsonArray = org.json.JSONArray(raw)
            val list = mutableListOf<com.modiprincekr.thedialer.modal.data.ContactGroup>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val id = obj.optString("id", java.util.UUID.randomUUID().toString())
                val name = obj.optString("name", "")
                val accountType = if (obj.has("accountType")) obj.optString("accountType").ifBlank { null } else null
                val accountName = if (obj.has("accountName")) obj.optString("accountName").ifBlank { null } else null
                val targetLabel = if (obj.has("targetLabel")) obj.optString("targetLabel").ifBlank { null } else null
                val contactsArray = obj.optJSONArray("contactIds")
                val contactIds = mutableListOf<String>()
                if (contactsArray != null) {
                    for (j in 0 until contactsArray.length()) {
                        contactIds.add(contactsArray.getString(j))
                    }
                }
                if (name.isNotBlank()) {
                    list.add(
                        com.modiprincekr.thedialer.modal.data.ContactGroup(
                            id = id,
                            name = name,
                            contactIds = contactIds,
                            accountType = accountType,
                            accountName = accountName,
                            targetLabel = targetLabel
                        )
                    )
                }
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveContactGroups(groups: List<com.modiprincekr.thedialer.modal.data.ContactGroup>) {
        val jsonArray = org.json.JSONArray()
        for (g in groups) {
            val obj = org.json.JSONObject()
            obj.put("id", g.id)
            obj.put("name", g.name)
            if (g.accountType != null) obj.put("accountType", g.accountType)
            if (g.accountName != null) obj.put("accountName", g.accountName)
            if (g.targetLabel != null) obj.put("targetLabel", g.targetLabel)
            val contactsArray = org.json.JSONArray()
            for (cId in g.contactIds) {
                contactsArray.put(cId)
            }
            obj.put("contactIds", contactsArray)
            jsonArray.put(obj)
        }
        setString(KEY_CONTACT_GROUPS, jsonArray.toString())
    }

    fun addContactGroup(group: com.modiprincekr.thedialer.modal.data.ContactGroup) {
        val current = getContactGroups().toMutableList()
        val existingIndex = current.indexOfFirst { it.id == group.id }
        if (existingIndex >= 0) {
            current[existingIndex] = group
        } else {
            current.add(group)
        }
        saveContactGroups(current)

        val order = getContactsDisplayOrder().toMutableList()
        val groupKey = "group_${group.id}"
        if (groupKey !in order) {
            order.add(groupKey)
            setContactsDisplayOrder(order)
        }
    }

    fun deleteContactGroup(groupId: String) {
        val current = getContactGroups().filterNot { it.id == groupId }
        saveContactGroups(current)

        val order = getContactsDisplayOrder().filterNot { it == "group_$groupId" }
        setContactsDisplayOrder(order)
    }

    fun getContactsDisplayOrder(): List<String> {
        val raw = getString(KEY_CONTACTS_DISPLAY_ORDER, null)
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(",").filter { it.isNotBlank() }
    }

    fun setContactsDisplayOrder(order: List<String>) {
        setString(KEY_CONTACTS_DISPLAY_ORDER, order.joinToString(","))
    }

    fun getHiddenContactGroupIds(): Set<String> {
        val raw = getString(KEY_HIDDEN_CONTACT_GROUPS, null) ?: return emptySet()
        return raw.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }

    fun setContactGroupHidden(groupId: String, hidden: Boolean) {
        val current = getHiddenContactGroupIds().toMutableSet()
        if (hidden) current.add(groupId) else current.remove(groupId)
        setString(KEY_HIDDEN_CONTACT_GROUPS, current.joinToString(","))
    }

    fun getAppLanguage(): String = getString(KEY_APP_LANGUAGE, LANGUAGE_SYSTEM) ?: LANGUAGE_SYSTEM
    fun setAppLanguage(lang: String) = setString(KEY_APP_LANGUAGE, lang)

    fun getLiquidGlassDefaultConfig(elementKey: String): LiquidGlassElementConfig {
        val defaultBlur = when (elementKey) {
            KEY_LG_DROPDOWN_MENU -> 6f
            KEY_LG_CONTACTS_FAB, KEY_LG_RECENTS_FAB -> 2f
            else -> 2f
        }
        val defaultRefractionHeight = when (elementKey) {
            KEY_LG_BOTTOM_NAV, KEY_LG_CONTACTS_FAB, KEY_LG_RECENTS_FAB -> 23f
            KEY_LG_DROPDOWN_MENU -> 40f
            else -> 18f
        }
        val defaultRefractionAmount = when (elementKey) {
            KEY_LG_BOTTOM_NAV, KEY_LG_CONTACTS_FAB, KEY_LG_RECENTS_FAB -> 64f
            KEY_LG_DROPDOWN_MENU -> 248f
            KEY_LG_DIALPAD_CALL_BUTTON -> 52f
            else -> 48f
        }
        val defaultSaturation = when (elementKey) {
            KEY_LG_BOTTOM_NAV, KEY_LG_DROPDOWN_MENU, KEY_LG_CONTACTS_FAB, KEY_LG_RECENTS_FAB -> 1.4f
            KEY_LG_DIALPAD_CALL_BUTTON -> 1.3f
            else -> 1.0f
        }
        val defaultBrightness = when (elementKey) {
            KEY_LG_DROPDOWN_MENU -> -0.13f
            else -> 0f
        }
        return LiquidGlassElementConfig(
            blurRadiusDp = defaultBlur,
            refractionHeightDp = defaultRefractionHeight,
            refractionAmountDp = defaultRefractionAmount,
            chromaticAberration = false,
            depthEffect = false,
            saturation = defaultSaturation,
            brightness = defaultBrightness
        )
    }

    fun getLiquidGlassConfig(elementKey: String): LiquidGlassElementConfig {
        val def = getLiquidGlassDefaultConfig(elementKey)
        val rawBrightness = getFloat("${elementKey}_brightness", def.brightness)
        val brightness = if ((elementKey == KEY_LG_CONTACTS_FAB || elementKey == KEY_LG_RECENTS_FAB) && rawBrightness == -0.15f) {
            def.brightness
        } else {
            rawBrightness
        }
        val rawBlur = getFloat("${elementKey}_blur", def.blurRadiusDp)
        val blurRadiusDp = if ((elementKey == KEY_LG_CONTACTS_FAB || elementKey == KEY_LG_RECENTS_FAB) && rawBlur == 0f) {
            def.blurRadiusDp
        } else {
            rawBlur
        }
        val rawSat = getFloat("${elementKey}_saturation", def.saturation)
        val saturation = if ((elementKey == KEY_LG_CONTACTS_FAB || elementKey == KEY_LG_RECENTS_FAB) && rawSat == 1.0f) {
            def.saturation
        } else {
            rawSat
        }
        return LiquidGlassElementConfig(
            blurRadiusDp = blurRadiusDp,
            refractionHeightDp = getFloat("${elementKey}_refraction_h", def.refractionHeightDp),
            refractionAmountDp = getFloat("${elementKey}_refraction_a", def.refractionAmountDp),
            chromaticAberration = getBoolean("${elementKey}_chromatic", def.chromaticAberration),
            depthEffect = getBoolean("${elementKey}_depth", def.depthEffect),
            saturation = saturation,
            brightness = brightness
        )
    }

    fun setLiquidGlassConfig(elementKey: String, config: LiquidGlassElementConfig) {
        setFloat("${elementKey}_blur", config.blurRadiusDp)
        setFloat("${elementKey}_refraction_h", config.refractionHeightDp)
        setFloat("${elementKey}_refraction_a", config.refractionAmountDp)
        setBoolean("${elementKey}_chromatic", config.chromaticAberration)
        setBoolean("${elementKey}_depth", config.depthEffect)
        setFloat("${elementKey}_saturation", config.saturation)
        setFloat("${elementKey}_brightness", config.brightness)
    }

    fun resetLiquidGlassConfig(elementKey: String) {
        remove("${elementKey}_blur")
        remove("${elementKey}_refraction_h")
        remove("${elementKey}_refraction_a")
        remove("${elementKey}_chromatic")
        remove("${elementKey}_depth")
        remove("${elementKey}_saturation")
        remove("${elementKey}_brightness")
    }

    fun getBlurDefaultConfig(elementKey: String): BlurElementConfig {
        return BlurElementConfig(
            blurRadiusDp = 25f,
            saturation = 1.3f
        )
    }

    fun getBlurConfig(elementKey: String): BlurElementConfig {
        val def = getBlurDefaultConfig(elementKey)
        return BlurElementConfig(
            blurRadiusDp = getFloat("${elementKey}_blur_radius", def.blurRadiusDp),
            saturation = getFloat("${elementKey}_blur_sat", def.saturation)
        )
    }

    fun setBlurConfig(elementKey: String, config: BlurElementConfig) {
        setFloat("${elementKey}_blur_radius", config.blurRadiusDp)
        setFloat("${elementKey}_blur_sat", config.saturation)
    }

    fun resetBlurConfig(elementKey: String) {
        remove("${elementKey}_blur_radius")
        remove("${elementKey}_blur_sat")
    }

    // ── Auto Backup Configuration Helpers ─────────────────────────────────
    fun isAutoBackupEnabled(): Boolean = getBoolean(KEY_AUTO_BACKUP_ENABLED, false)
    fun setAutoBackupEnabled(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ENABLED, enabled)

    fun getAutoBackupFolderUri(): String? = getString(KEY_AUTO_BACKUP_FOLDER_URI, null)
    fun setAutoBackupFolderUri(uri: String?) = setString(KEY_AUTO_BACKUP_FOLDER_URI, uri)

    fun getAutoBackupIntervalValue(): Int = getInt(KEY_AUTO_BACKUP_INTERVAL_VALUE, 2)
    fun setAutoBackupIntervalValue(value: Int) = setInt(KEY_AUTO_BACKUP_INTERVAL_VALUE, value)

    fun getAutoBackupIntervalUnit(): String = getString(KEY_AUTO_BACKUP_INTERVAL_UNIT, "hours") ?: "hours"
    fun setAutoBackupIntervalUnit(unit: String) = setString(KEY_AUTO_BACKUP_INTERVAL_UNIT, unit)

    fun isAutoBackupItemSettings(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_SETTINGS, true)
    fun setAutoBackupItemSettings(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_SETTINGS, enabled)

    fun isAutoBackupItemLiquidGlass(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_LIQUID_GLASS, true)
    fun setAutoBackupItemLiquidGlass(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_LIQUID_GLASS, enabled)

    fun isAutoBackupItemCallingCards(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_CALLING_CARDS, true)
    fun setAutoBackupItemCallingCards(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_CALLING_CARDS, enabled)

    fun isAutoBackupItemNotes(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_NOTES, true)
    fun setAutoBackupItemNotes(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_NOTES, enabled)

    fun isAutoBackupItemGroups(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_GROUPS, false)
    fun setAutoBackupItemGroups(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_GROUPS, enabled)

    fun isAutoBackupItemRecordings(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_RECORDINGS, true)
    fun setAutoBackupItemRecordings(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_RECORDINGS, enabled)

    fun isAutoBackupItemContacts(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_CONTACTS, false)
    fun setAutoBackupItemContacts(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_CONTACTS, enabled)

    fun isAutoBackupItemCallLogs(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_CALL_LOGS, false)
    fun setAutoBackupItemCallLogs(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_CALL_LOGS, enabled)

    fun isAutoBackupItemSms(): Boolean = getBoolean(KEY_AUTO_BACKUP_ITEMS_SMS, false)
    fun setAutoBackupItemSms(enabled: Boolean) = setBoolean(KEY_AUTO_BACKUP_ITEMS_SMS, enabled)

    fun isAutoDeleteBackupsTimeEnabled(): Boolean = getBoolean(KEY_AUTO_DELETE_BACKUPS_TIME_ENABLED, false)
    fun setAutoDeleteBackupsTimeEnabled(enabled: Boolean) = setBoolean(KEY_AUTO_DELETE_BACKUPS_TIME_ENABLED, enabled)

    fun getAutoDeleteBackupsTimeValue(): Int = getInt(KEY_AUTO_DELETE_BACKUPS_TIME_VALUE, 7)
    fun setAutoDeleteBackupsTimeValue(value: Int) = setInt(KEY_AUTO_DELETE_BACKUPS_TIME_VALUE, value)

    fun getAutoDeleteBackupsTimeUnit(): String = getString(KEY_AUTO_DELETE_BACKUPS_TIME_UNIT, "days") ?: "days"
    fun setAutoDeleteBackupsTimeUnit(unit: String) = setString(KEY_AUTO_DELETE_BACKUPS_TIME_UNIT, unit)

    fun isAutoDeleteBackupsCountEnabled(): Boolean = getBoolean(KEY_AUTO_DELETE_BACKUPS_COUNT_ENABLED, false)
    fun setAutoDeleteBackupsCountEnabled(enabled: Boolean) = setBoolean(KEY_AUTO_DELETE_BACKUPS_COUNT_ENABLED, enabled)

    fun getAutoDeleteBackupsCountValue(): Int = getInt(KEY_AUTO_DELETE_BACKUPS_COUNT_VALUE, 5)
    fun setAutoDeleteBackupsCountValue(value: Int) = setInt(KEY_AUTO_DELETE_BACKUPS_COUNT_VALUE, value)

    fun getSelectedPfpShape(): String = getString(KEY_CONTACT_INFO_PFP_SHAPE, "circle") ?: "circle"
    fun setSelectedPfpShape(shape: String) = setString(KEY_CONTACT_INFO_PFP_SHAPE, shape)

    fun isAnimatePfpShapeRotation(): Boolean = getBoolean(KEY_CONTACT_INFO_PFP_SHAPE_ANIMATE, true)
    fun setAnimatePfpShapeRotation(animate: Boolean) = setBoolean(KEY_CONTACT_INFO_PFP_SHAPE_ANIMATE, animate)

    companion object {
        const val KEY_APP_LANGUAGE = "app_language"
        const val LANGUAGE_SYSTEM = "system"
        const val LANGUAGE_ENGLISH = "en"
        const val LANGUAGE_ARABIC = "ar"
        const val LANGUAGE_HINDI = "hi"
        const val LANGUAGE_TAMIL = "ta"

        const val KEY_HIDDEN_CONTACT_GROUPS = "hidden_contact_groups"
        const val KEY_GROUPS_SORT_ORDER = "groups_sort_order"
        const val ITEM_ALL_CONTACTS = "all_contacts"
        const val ITEM_CONTACT_GROUPS = "contact_groups"
        const val KEY_CONTACT_GROUPS = "contact_groups"
        const val KEY_CONTACTS_DISPLAY_ORDER = "contacts_display_order"

        /** Parses a raw comma-separated tab-order preference string into an ordered list of
         *  valid tab keys, falling back to [DEFAULT_TAB_ORDER] and appending any tab keys
         *  missing from a stale/older saved order (so newly-added tabs always show up). */
        fun parseTabOrder(raw: String?): List<String> {
            val fallback = DEFAULT_TAB_ORDER.split(",")
                .filter { it != "recordings" || com.coolappstore.everdialer.by.svhp.feature.AppFeatures.isCallRecorderAvailable }
            if (raw.isNullOrBlank()) return fallback
            val parsed = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            val merged = parsed.toMutableList()
            fallback.forEach { key -> if (key !in merged) merged.add(key) }
            return merged.filter { it in fallback }
        }

        const val DEFAULT_CALL_UI_ORDER = "today,incoming,missed,outgoing,call_time,contacts,groups"
        const val KEY_CALL_UI_ORDER = "call_ui_order"

        /** Parses a raw comma-separated call-ui element order preference string into an ordered list
         *  of valid card keys, falling back to [DEFAULT_CALL_UI_ORDER]. */
        fun parseCallUIOrder(raw: String?): List<String> {
            val fallback = DEFAULT_CALL_UI_ORDER.split(",")
            if (raw.isNullOrBlank()) return fallback
            val parsed = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            val merged = parsed.toMutableList()
            if (!merged.contains("incoming")) {
                val todayIdx = merged.indexOf("today")
                if (todayIdx != -1) {
                    merged.add(todayIdx + 1, "incoming")
                } else {
                    merged.add(0, "incoming")
                }
            }
            fallback.forEach { key -> if (key !in merged) merged.add(key) }
            return merged.filter { it in fallback }
        }

        const val KEY_CONTACT_INFO_SHOW_QUICK_ACTIONS         = "contact_info_show_quick_actions"
        const val KEY_CONTACT_INFO_SHOW_CONTACT_INFO          = "contact_info_show_contact_info"
        const val KEY_CONTACT_INFO_SHOW_SOCIAL                = "contact_info_show_social"
        const val KEY_CONTACT_INFO_SHOW_DESCRIPTION           = "contact_info_show_description"
        const val KEY_CONTACT_INFO_SHOW_NOTES                 = "contact_info_show_notes"
        const val KEY_CONTACT_INFO_SHOW_EVENTS                = "contact_info_show_events"
        const val KEY_CONTACT_INFO_SHOW_RECENT_ACTIVITY       = "contact_info_show_recent_activity"
        const val KEY_CONTACT_INFO_SHOW_CHOOSE_SIM            = "contact_info_show_choose_sim"
        const val KEY_CONTACT_INFO_SHOW_CALLING_BACKGROUNDS   = "contact_info_show_calling_backgrounds"
        const val KEY_CONTACT_INFO_SHOW_ADVANCED_PFP          = "contact_info_show_advanced_pfp"
        const val KEY_CONTACT_INFO_SHOW_RINGTONE              = "contact_info_show_ringtone"
        const val KEY_CONTACT_INFO_SHOW_CHOOSE_DEFAULT_NUMBER = "contact_info_show_choose_default_number"
        const val KEY_CONTACT_INFO_SHOW_SAVED_IN              = "contact_info_show_saved_in"
        const val KEY_CONTACT_INFO_SHOW_CONTACT_INFO_SETTINGS = "contact_info_show_contact_info_settings"
        const val KEY_CONTACT_INFO_ORDER                      = "contact_info_order"
        const val DEFAULT_CONTACT_INFO_ORDER                  = "quick_actions,contact_info,social,description,notes,events,recent_activity,choose_sim,calling_backgrounds,ringtone,choose_default_number,saved_in,contact_info_settings"

        fun parseContactInfoOrder(raw: String?): List<String> {
            val fallback = DEFAULT_CONTACT_INFO_ORDER.split(",")
            if (raw.isNullOrBlank()) return fallback
            val parsed = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            val merged = parsed.toMutableList()
            fallback.forEach { key -> if (key !in merged) merged.add(key) }
            return merged.filter { it in fallback }
        }

        const val KEY_DEFAULT_SIM           = "default_sim"
        // Contact Info → "Choose Sim" — per-contact override of which SIM is used to call that
        // specific contact. Key is prefixed per contact (id for saved contacts, raw phone number
        // for unsaved ones) so every contact can remember its own choice independently.
        const val KEY_CONTACT_SIM_CHOICE_PREFIX = "contact_sim_choice_"
        // Contact Info → "Choose Default Number" — per-contact override of which saved number is
        // used by default when the contact has 2+ numbers. Same per-contact keying as
        // KEY_CONTACT_SIM_CHOICE_PREFIX. Unset (null) means "ask every time".
        const val KEY_CONTACT_DEFAULT_NUMBER_PREFIX = "contact_default_number_"
        // Global "SIM used in the last call placed from the app" (1 = SIM 1, 2 = SIM 2, 0 = none
        // yet), written every time a call is placed on a specific SIM. Backs the "Choose the last
        // used SIM in previous call" per-contact option.
        const val KEY_LAST_USED_SIM_GLOBAL  = "last_used_sim_global"
        const val SIM_CHOICE_SETTINGS           = "settings"
        const val SIM_CHOICE_ASK                = "ask"
        const val SIM_CHOICE_SIM1               = "sim1"
        const val SIM_CHOICE_SIM2               = "sim2"
        const val SIM_CHOICE_CALL_LOG           = "call_log"
        const val SIM_CHOICE_LAST_FOR_CONTACT   = "last_for_contact"
        const val SIM_CHOICE_LAST_IN_CALL       = "last_in_call"
        const val KEY_DEFAULT_SPEAKER_ROUTE     = "default_speaker_route"
        const val KEY_DEFAULT_MIC_ROUTE         = "default_mic_route"
        const val KEY_USE_PREVIOUS_CALL_AUDIO_CONFIG = "use_previous_call_audio_config"
        const val KEY_LAST_USED_SPEAKER_ROUTE   = "last_used_speaker_route"
        const val KEY_LAST_USED_MIC_ROUTE       = "last_used_mic_route"
        const val SPEAKER_ROUTE_EXTERNAL        = "external"
        const val SPEAKER_ROUTE_EAR             = "ear_speaker"
        const val SPEAKER_ROUTE_SPEAKER         = "speaker"
        const val MIC_ROUTE_EXTERNAL            = "external"
        const val MIC_ROUTE_SYSTEM              = "system"
        const val KEY_DYNAMIC_COLORS        = "dynamic_colors"
        const val KEY_AMOLED_MODE           = "amoled_mode"
        const val KEY_SOLID_ICONS           = "solid_icons"
        const val KEY_SOLID_ICONS_DYNAMIC   = "solid_icons_dynamic"
        const val KEY_SOLID_ICONS_LIGHT     = "solid_icons_light"
        const val KEY_SOLID_ICONS_DARK      = "solid_icons_dark"
        const val SOLID_ICONS_STYLE_BRIGHT  = "bright"
        const val SOLID_ICONS_STYLE_DIM     = "dim"
        const val KEY_CIRCLE_ICONS          = "circle_icons"
        const val KEY_SHOW_AVATARS_CALLS    = "show_avatars_calls"
        const val KEY_SHOW_AVATARS_CONTACTS = "show_avatars_contacts"
        const val KEY_CONTACTS_SORT_BY      = "contacts_sort_by"
        const val KEY_CONTACTS_SORT_ASCENDING = "contacts_sort_ascending"
        const val KEY_FAVORITES_SORT_BY     = "favorites_sort_by"
        const val KEY_FAVORITES_SORT_ASCENDING = "favorites_sort_ascending"
        const val KEY_SHOW_FIRST_LETTER     = "show_first_letter"
        const val KEY_COLORFUL_AVATARS      = "colorful_avatars"
        const val KEY_SHOW_PICTURE          = "show_picture"
        const val KEY_ICON_ONLY_NAV         = "icon_only_nav"
        const val KEY_DTMF_TONE             = "dtmf_tone"
        const val KEY_DIALPAD_TONE_STYLE    = "dialpad_tone_style" // "standard" | "piano" | "water_drop" | "mechanical" | "scifi"
        const val KEY_DIALPAD_VIBRATION     = "dialpad_vibration"
        const val KEY_SPEED_DIAL            = "speed_dial"
        const val KEY_T9_DIALING            = "t9_dialing"
        const val KEY_BLOCK_UNKNOWN         = "block_unknown_callers"
        const val KEY_BLOCK_HIDDEN          = "block_hidden_callers"
        const val KEY_OPEN_DIALPAD_DEFAULT  = "open_dialpad_default"
        const val KEY_DIALPAD_CIRCLE_BUTTONS = "dialpad_circle_buttons"
        const val KEY_HIDE_RATE_AND_REVIEW  = "hide_rate_and_review"
        const val KEY_RATE_REVIEW_HIDDEN_SECRET = "rate_review_hidden_secret"
        // Written by the bundled Ever Call Recorder module (:recorder) directly into this same
        // "rivo_prefs" file — see AppPreferences.isShowRecordingMenuBelowUpdatesEnabled().
        const val KEY_SHOW_RECORDING_MENU_BELOW_UPDATES = "show_recording_menu_below_updates"
        const val KEY_APP_HAPTICS              = "app_haptics_enabled"
        const val KEY_APP_HAPTICS_STRENGTH     = "app_haptics_strength"
        const val KEY_HAPTICS_CUSTOM_INTENSITY = "haptics_custom_intensity"
        const val KEY_HAPTIC_TOUCH_ONLY        = "haptic_trigger_touch_screen_only"
        const val KEY_RING_HAPTIC_ENABLED      = "ring_haptic_enabled"
        const val KEY_RING_HAPTIC_PATTERN      = "ring_haptic_pattern"
        const val KEY_RING_HAPTIC_INTENSITY    = "ring_haptic_intensity"
        const val KEY_RING_HAPTIC_CUSTOM_SEQUENCE = "ring_haptic_custom_sequence"
        const val KEY_RING_HAPTIC_AUTO         = "ring_haptic_auto"
        const val KEY_RING_HAPTIC_AUTO_SENSITIVITY = "ring_haptic_auto_sensitivity"
        const val KEY_RING_HAPTIC_AUTO_STRENGTH = "ring_haptic_auto_strength"
        const val KEY_RING_HAPTIC_FORCE_TOUCH_ROUTING = "ring_haptic_force_touch_routing"
        const val KEY_NOTES_ENABLED         = "notes_enabled"
        // When true (default), the app's Notes section and the call recording notes
        // (inside Ever Call Recorder's recording playback screen) are kept as two
        // independent notes sections. When false, they're merged: a contact's Notes
        // card also surfaces any notes attached to that contact's call recordings.
        const val KEY_INTEGRATE_NOTES       = "integrate_notes_section"
        const val KEY_DELETE_NOTES_WITH_RECORDING = "delete_notes_with_recording"
        const val KEY_CUSTOM_FONT_PATH      = "custom_font_path"
        const val KEY_CUSTOM_FONT_SIZE      = "custom_font_size"
        const val KEY_DISPLAY_SCALE         = "display_scale"
        const val KEY_FONT_HEIGHT_SCALE     = "font_height_scale"
        const val KEY_FONT_WIDTH_SCALE      = "font_width_scale"
        const val KEY_FONT_WEIGHT_OVERRIDE  = "font_weight_override"
        const val KEY_FONT_ORIENTATION      = "font_orientation"
        const val KEY_FONT_ROUNDNESS        = "font_roundness"
        const val KEY_CORNER_RADIUS         = "corner_radius"
        const val KEY_THEME_MODE            = "theme_mode"
        const val KEY_SATURATED_COLORS      = "saturated_colors"
        const val KEY_SATURATED_TARGET      = "saturated_target"
        const val SATURATED_TARGET_CONTAINER = "container"
        const val SATURATED_TARGET_BACKGROUND = "background"
        const val KEY_SATURATED_MODES       = "saturated_modes"
        const val DEFAULT_SATURATED_MODES   = "light,dark,white,black"
        const val KEY_SATURATION_LEVEL      = "saturation_level"
        const val KEY_SATURATION_LEVEL_LIGHT = "saturation_level_light"
        const val KEY_SATURATION_LEVEL_DARK  = "saturation_level_dark"
        const val KEY_BLOCKED_CONTACTS      = "blocked_contacts"
        const val KEY_SHOW_BLOCKED_CALLS_IN_CALL_LOGS = "show_blocked_calls_in_call_logs"
        const val KEY_BLOCKER_ENGINE        = "blocker_engine"
        const val BLOCKER_ENGINE_EVER_DIALER = "ever_dialer"
        const val BLOCKER_ENGINE_SYSTEM     = "system"
        const val KEY_SHOW_INCOMING_CALL_UI = "show_incoming_call_ui"
        const val KEY_SHOW_CALLER_UI        = "show_caller_ui"
        const val KEY_SHOW_FULL_SCREEN_INCOMING_ON_ANY_APPS = "show_fullscreen_call_ui_on_any_apps"
        const val KEY_INCOMING_SHOW_MUTE_BUTTON             = "incoming_show_mute_button"
        const val KEY_SHOW_ONGOING_CALL_UI_WHEN_ANSWERED    = "show_ongoing_call_ui_when_answered"
        const val KEY_SHOW_ONGOING_CALL_UI_ON_LOCKSCREEN_WHEN_ANSWERED = "show_ongoing_call_ui_on_lockscreen_when_answered"
        const val KEY_SILENCE_UNKNOWN       = "silence_unknown_callers"
        const val KEY_PROXIMITY_BG          = "proximity_sensor_bg"
        /** When enabled, screen-off during calls requires BOTH the proximity sensor reading
         *  "near" AND the device orientation matching an ear-held pose (same inclination
         *  check used by Raise to Answer), instead of relying on proximity alone. This avoids
         *  false screen-offs on phones whose proximity sensor misfires — e.g. while using the
         *  earpiece speaker and swiping down the status bar. */
        const val KEY_PROXIMITY_ORIENTATION_BG = "proximity_orientation_bg"
        /** Degrees of tilt away from lying flat required before the device counts as
         *  "slanted" (held up) for KEY_PROXIMITY_ORIENTATION_BG. Higher = less sensitive,
         *  requires a more vertical, closer-to-the-ear angle before the screen turns off. */
        const val KEY_PROXIMITY_ORIENTATION_SLANT_THRESHOLD = "proximity_orientation_slant_threshold"
        const val DEFAULT_PROXIMITY_ORIENTATION_SLANT_THRESHOLD = 70f
        const val KEY_SCROLL_HAPTICS        = "scroll_haptics_enabled"
        const val KEY_SCROLL_CM_PER_HAPTIC  = "scroll_cm_per_haptic"   // cm scrolled before each haptic tick
        const val KEY_SCROLL_HAPTICS_PER_CM = "scroll_haptics_per_cm"  // haptic ticks per cm
        const val KEY_SCROLL_HAPTIC_STRENGTH = "scroll_haptic_strength" // vibration amplitude 1–255
        const val KEY_HAPTICS_STRENGTH      = "app_haptics_strength"
        const val KEY_CALL_UI_SHOW_TODAY    = "call_ui_show_today"
        const val KEY_CALL_UI_SHOW_INCOMING = "call_ui_show_incoming"
        const val KEY_CALL_UI_SHOW_MISSED   = "call_ui_show_missed"
        const val KEY_CALL_UI_SHOW_OUTGOING = "call_ui_show_outgoing"
        const val KEY_CALL_UI_SHOW_CALL_TIME = "call_ui_show_call_time"
        const val KEY_CALL_UI_SHOW_CONTACTS  = "call_ui_show_contacts"
        const val KEY_CALL_UI_SHOW_GROUPS    = "call_ui_show_groups"
        const val KEY_AUTO_UPDATE_CHECK     = "auto_update_check"
        const val KEY_NOTIFY_UPDATES_ENABLED = "notify_updates_enabled"
        const val KEY_NOTIFY_UPDATES_VALUE   = "notify_updates_value"
        const val KEY_NOTIFY_UPDATES_UNIT    = "notify_updates_unit"
        const val KEY_LAST_NOTIFIED_UPDATE_VERSION = "last_notified_update_version"
        const val KEY_SCROLL_INDICATION     = "scroll_indication"
        const val KEY_PILL_NAV              = "pill_style_nav"
        const val KEY_SLIDE_TO_OPEN         = "slide_to_open"
        const val KEY_GROUP_CALLS_BY_LATEST = "group_calls_by_latest"
        const val KEY_SHOW_SIMS_IN_CALL_LOGS = "show_sims_in_call_logs"
        const val KEY_SHOW_TOTAL_CALLS_MADE = "show_total_calls_made"
        // Dialpad Memory — on by default. When on, whatever digits are typed into the Dialpad
        // stay there after the sheet is closed or a call is placed, so reopening the Dialpad
        // shows the same number again. When off, the Dialpad is wiped in both of those cases.
        const val KEY_DIALPAD_MEMORY        = "dialpad_memory"
        // Show Call Logs in Dialpad Search List — on by default. When on, recent call logs are
        // shown in the dialpad search list when nothing has been typed/searched yet.
        const val KEY_SHOW_CALL_LOGS_IN_DIALPAD_SEARCH_LIST = "show_call_logs_in_dialpad_search_list"
        // Show Numbers in Call Logs — on by default. When on, contact phone numbers are shown
        // below their names in call logs. When off, numbers are hidden for known contacts.
        const val KEY_SHOW_NUMBERS_IN_CALL_LOGS = "show_numbers_in_call_logs"
        // Auto Delete Unknown No in call log — off by default. When on, call log entries from
        // numbers that aren't saved contacts get auto-deleted once older than the configured
        // threshold. Only applies going forward from the moment it's turned on (see
        // KEY_AUTO_DELETE_UNKNOWN_CALLS_ENABLED_AT) so existing history is never touched.
        const val KEY_AUTO_DELETE_UNKNOWN_CALLS_ENABLED = "auto_delete_unknown_calls_enabled"
        // Threshold amount, paired with KEY_AUTO_DELETE_UNKNOWN_CALLS_UNIT ("hours"/"days").
        const val KEY_AUTO_DELETE_UNKNOWN_CALLS_VALUE = "auto_delete_unknown_calls_value"
        const val KEY_AUTO_DELETE_UNKNOWN_CALLS_UNIT = "auto_delete_unknown_calls_unit"
        // Timestamp (epoch millis) the feature was last turned on. Only unknown-number call log
        // entries whose call date is at/after this point are eligible for auto-deletion, so
        // entries that already existed before the feature was enabled are never deleted by it.
        const val KEY_AUTO_DELETE_UNKNOWN_CALLS_ENABLED_AT = "auto_delete_unknown_calls_enabled_at"
        // Call Time Format in call logs — false = 12-hour (default), true = 24-hour
        const val KEY_CALL_TIME_FORMAT_24H  = "call_time_format_24h"
        // Talk Time in call logs — false = off (default), true = on
        const val KEY_SHOW_TALK_TIME_IN_CALL_LOGS = "show_talk_time_in_call_logs"
        // Missed Call Duration in call logs — false = off (default), true = on
        const val KEY_SHOW_MISSED_CALL_DURATION = "show_missed_call_duration_in_call_logs"
        // Auto reset missed call duration
        const val KEY_AUTO_RESET_MISSED_CALL_DURATION_ENABLED = "auto_reset_missed_call_duration_enabled"
        const val KEY_AUTO_RESET_MISSED_CALL_DURATION_VALUE = "auto_reset_missed_call_duration_value"
        const val KEY_AUTO_RESET_MISSED_CALL_DURATION_UNIT = "auto_reset_missed_call_duration_unit"
        const val KEY_AUTO_RESET_MISSED_CALL_DURATION_LAST_RESET = "auto_reset_missed_call_duration_last_reset"
        // Whether the ongoing-call screen smoothly slides away when a call ends. Default true;
        // when false, the call screen should close immediately instead.
        const val KEY_HANGUP_ANIMATION      = "hangup_animation"
        const val KEY_FIRST_LAUNCH_DONE     = "first_launch_done"
        // Hangup button width fraction (0.4f .. 1.0f)
        const val KEY_HANGUP_WIDTH          = "hangup_button_width"
        // Container height scale factor for ongoing call screen (0.70f .. 1.40f)
        const val KEY_ONGOING_CONTAINER_HEIGHT = "ongoing_container_height"
        // Feature Buttons — ongoing call screen button customization
        // Comma-separated ordered list of button ids (see CallButtonPrefs.ALL_IDS)
        const val KEY_CALL_BUTTONS_ORDER    = "call_buttons_order"
        // Comma-separated list of button ids that are hidden from the call screen
        const val KEY_CALL_BUTTONS_DISABLED = "call_buttons_disabled"
        // Freeform layout — when true, Feature Buttons can be dragged and dropped to any
        // position on the preview/call screen instead of snapping into the fixed 3-per-row
        // grid. Off by default (unticked).
        const val KEY_CALL_BUTTONS_FREEFORM = "call_buttons_freeform"
        // Freeform positions — JSON-encoded map of button id -> {x, y} as fractions (0f..1f)
        // of the available preview/call area, only used while KEY_CALL_BUTTONS_FREEFORM is on.
        const val KEY_CALL_BUTTONS_FREEFORM_POSITIONS = "call_buttons_freeform_positions"
        // Whether the text label is shown below each Feature Button / Hang Up icon on the
        // ongoing call screen. On (ticked) by default.
        const val KEY_CALL_BUTTONS_SHOW_NAMES = "call_buttons_show_names"
        // Element Size — scale factor (0.75f .. 1.5f) applied to each Feature Button / Hang Up
        // icon's size on the ongoing call screen. 1.0f (100%) by default.
        const val KEY_CALL_BUTTONS_ELEMENT_SIZE = "call_buttons_element_size"
        // Dialer role popup shown after welcome
        const val KEY_DIALER_POPUP_SHOWN    = "dialer_popup_shown"
        const val KEY_TELEGRAM_SHOWN        = "telegram_shown"
        const val KEY_MATERIAL_THEME        = "material_theme"
        const val MATERIAL_THEME_YOU        = "material_you"
        const val MATERIAL_THEME_EXPRESSIVE = "material_expressive"

        const val KEY_ANIMATION_STYLE       = "animation_style"
        const val ANIMATION_STYLE_ZOOM      = "zoom"
        const val ANIMATION_STYLE_CARDS     = "cards"
        const val ANIMATION_STYLE_WINDOWS_PHONE = "windows_phone"
        const val KEY_MOTION_BLUR_ANIMATION = "motion_blur_animation_enabled"
        const val KEY_PREDICTIVE_BACK_GESTURE = "predictive_back_gesture_enabled"
        const val KEY_SCROLL_ANIMATION      = "scroll_animation_enabled"
        const val KEY_POCKET_MODE_PREVENTION = "pocket_mode_prevention"
        const val KEY_DIRECT_CALL_ON_TAP     = "direct_call_on_tap"
        const val KEY_CONTACTS_DISPLAY_ACCOUNTS = "contacts_display_accounts"
        const val KEY_LIQUID_GLASS              = "liquid_glass_ui"
        const val KEY_LG_BOTTOM_NAV            = "lg_bottom_nav"
        const val KEY_LG_DROPDOWN_MENU         = "lg_dropdown_menu"
        const val KEY_LG_DIALPAD_CALL_BUTTON   = "lg_dialpad_call_button"
        const val KEY_LG_CONTACTS_FAB          = "lg_contacts_fab"
        const val KEY_LG_RECENTS_FAB           = "lg_recents_fab"
        const val KEY_BLUR_EFFECTS            = "blur_effects_ui"
        // Material Blur effect elements
        const val KEY_BLUR_BOTTOM_NAV          = "blur_bottom_nav"
        const val KEY_BLUR_DROPDOWN_MENU       = "blur_dropdown_menu"
        const val KEY_BLUR_DIALPAD_CALL_BUTTON = "blur_dialpad_call_button"
        const val KEY_BLUR_CONTACTS_FAB        = "blur_contacts_fab"
        const val KEY_BLUR_RECENTS_FAB         = "blur_recents_fab"

        // ── Auto Backup Configuration ───────────────────────────────────────
        const val KEY_AUTO_BACKUP_ENABLED              = "auto_backup_enabled"
        const val KEY_AUTO_BACKUP_FOLDER_URI           = "auto_backup_folder_uri"
        const val KEY_AUTO_BACKUP_INTERVAL_VALUE       = "auto_backup_interval_value" // default: 2
        const val KEY_AUTO_BACKUP_INTERVAL_UNIT        = "auto_backup_interval_unit"  // default: "hours"
        const val KEY_AUTO_BACKUP_ITEMS_SETTINGS       = "auto_backup_items_settings"
        const val KEY_AUTO_BACKUP_ITEMS_LIQUID_GLASS   = "auto_backup_items_liquid_glass"
        const val KEY_AUTO_BACKUP_ITEMS_CALLING_CARDS  = "auto_backup_items_calling_cards"
        const val KEY_AUTO_BACKUP_ITEMS_NOTES          = "auto_backup_items_notes"
        const val KEY_AUTO_BACKUP_ITEMS_GROUPS         = "auto_backup_items_groups"
        const val KEY_AUTO_BACKUP_ITEMS_RECORDINGS     = "auto_backup_items_recordings"
        const val KEY_AUTO_BACKUP_ITEMS_CONTACTS       = "auto_backup_items_contacts"
        const val KEY_AUTO_BACKUP_ITEMS_CALL_LOGS      = "auto_backup_items_call_logs"
        const val KEY_AUTO_BACKUP_ITEMS_SMS            = "auto_backup_items_sms"

        // Auto Delete Backups Configuration
        const val KEY_AUTO_DELETE_BACKUPS_TIME_ENABLED = "auto_delete_backups_time_enabled"
        const val KEY_AUTO_DELETE_BACKUPS_TIME_VALUE   = "auto_delete_backups_time_value" // default: 7
        const val KEY_AUTO_DELETE_BACKUPS_TIME_UNIT    = "auto_delete_backups_time_unit"  // default: "days"
        const val KEY_AUTO_DELETE_BACKUPS_COUNT_ENABLED = "auto_delete_backups_count_enabled"
        const val KEY_AUTO_DELETE_BACKUPS_COUNT_VALUE   = "auto_delete_backups_count_value" // default: 5
        const val KEY_DEFAULT_TAB              = "default_tab"
        const val KEY_AUTO_SPEAKER             = "auto_speaker"
        const val KEY_FAVORITES_ORDER          = "favorites_order"
        const val KEY_FLOATING_CALL            = "floating_ongoing_call"
        // Tab Sections visibility
        const val KEY_TAB_SHOW_FAVORITES       = "tab_show_favorites"
        const val KEY_TAB_SHOW_CALLS           = "tab_show_calls"
        const val KEY_TAB_SHOW_CONTACTS        = "tab_show_contacts"
        const val KEY_TAB_SHOW_SMS             = "tab_show_sms"
        const val KEY_TAB_SHOW_GROUPS          = "tab_show_groups"
        const val KEY_TAB_SHOW_RECORDINGS      = "tab_show_recordings"
        const val KEY_TAB_SHOW_NOTES           = "tab_show_notes"
        const val KEY_TAB_SHOW_ALTERNATE       = "tab_show_alternate"
        const val KEY_TAB_SHOW_DIALPAD         = "tab_show_dialpad"
        // Comma-separated list of tab keys (favorites, calls, contacts, sms, groups, recordings, notes, alternate, dialpad)
        // describing the order tabs appear in the bottom navigation bar.
        const val KEY_TAB_ORDER                = "tab_order"
        const val KEY_MISSED_CALL_RESET_TIME   = "missed_call_reset_time"
        const val KEY_NEW_CALL_LOGS_LOGIC      = "new_call_logs_logic"
        const val KEY_NEW_CONTACTS_LOGIC       = "new_contacts_logic"
        const val DEFAULT_TAB_ORDER            = "favorites,calls,contacts,sms,groups,recordings,notes,alternate,dialpad"
        // Passwords & Security / Biometrics
        const val KEY_BIOMETRICS_TYPE          = "biometrics_type"         // "system" | "pin" | "password" | "pattern" | ""
        const val KEY_BIOMETRICS_PIN           = "biometrics_pin"
        const val KEY_BIOMETRICS_PASSWORD      = "biometrics_password"
        const val KEY_BIOMETRICS_PATTERN       = "biometrics_pattern"
        const val KEY_BIOMETRICS_PATTERN_VISIBLE = "biometrics_pattern_visible"
        const val KEY_BIOMETRICS_BACKUP_TYPE   = "biometrics_backup_type" // "pin" | "pattern" | "password"
        const val KEY_BIOMETRICS_APP_LOCK      = "biometrics_app_lock"
        const val KEY_BIOMETRICS_CALL_LOCK     = "biometrics_call_lock"
        const val KEY_BIOMETRICS_CALL_LOCK_MODE    = "biometrics_call_lock_mode"    // "all" | "specified" | "skip_specified"
        const val KEY_BIOMETRICS_CALL_LOCK_NUMBERS = "biometrics_call_lock_numbers" // comma-separated phone numbers
        // Raise to Answer
        const val KEY_RAISE_TO_ANSWER_ENABLED      = "raise_to_answer_enabled"
        const val KEY_RAISE_TO_ANSWER_ANY_ANGLE    = "raise_to_answer_any_angle"
        const val KEY_RAISE_TO_ANSWER_DECLINE_FLIP = "raise_to_answer_decline_flip"
        const val KEY_RAISE_TO_ANSWER_BEEP         = "raise_to_answer_beep"
        const val KEY_RAISE_TO_ANSWER_VIBRATE      = "raise_to_answer_vibrate"
        // Rain Mode
        const val KEY_RAIN_MODE_ENABLED            = "rain_mode_enabled"
        const val KEY_RAIN_MODE_VIBRATE            = "rain_mode_vibrate"
        const val KEY_RAIN_MODE_SEQUENCE           = "rain_mode_sequence"
        const val KEY_RAIN_MODE_TIMEOUT_MS         = "rain_mode_timeout_ms"
        const val KEY_RAIN_MODE_SHAKE_INTENSITY     = "rain_mode_shake_intensity"      // Float, 0f..1f (default 0.5f)
        const val KEY_RAIN_MODE_INCOMING_ACTION    = "rain_mode_incoming_action"     // "answer" | "decline"
        const val KEY_RAIN_MODE_END_ACTIVE_CALL    = "rain_mode_end_active_call"     // Boolean, default true
        const val DEFAULT_RAIN_MODE_SEQUENCE       = "UDUD"
        const val DEFAULT_RAIN_MODE_TIMEOUT_MS     = 2000
        const val DEFAULT_RAIN_MODE_SHAKE_INTENSITY = 0.5f
        const val DEFAULT_RAIN_MODE_INCOMING_ACTION = "answer"
        // Auto Redial
        const val KEY_AUTO_REDIAL_ENABLED      = "auto_redial_enabled"
        // Updates — version tag of the APK currently sitting in Downloads (if any)
        const val KEY_DOWNLOADED_UPDATE_VERSION = "downloaded_update_version"
        // Fake Call — JSON-encoded list of scheduled fake calls
        const val KEY_FAKE_CALLS                = "fake_calls"
        // Fake Call — show a "Fake Call" entry in the dialpad's long-press context menu
        const val KEY_FAKE_CALL_IN_CONTEXT_MENU = "fake_call_in_context_menu"
        // Fake Call — remembers the last-used time/timer/day settings (everything except
        // name and number) so creating a new fake call starts from what was used last,
        // instead of always resetting to hardcoded defaults.
        const val KEY_FAKE_CALL_LAST_MODE          = "fake_call_last_mode"          // "clock" | "timer"
        const val KEY_FAKE_CALL_LAST_HOUR           = "fake_call_last_hour"
        const val KEY_FAKE_CALL_LAST_MINUTE         = "fake_call_last_minute"
        const val KEY_FAKE_CALL_LAST_DAYS           = "fake_call_last_days"         // comma-separated Calendar.DAY_OF_WEEK ints
        const val KEY_FAKE_CALL_LAST_TIMER_AMOUNT   = "fake_call_last_timer_amount"
        const val KEY_FAKE_CALL_LAST_TIMER_UNIT     = "fake_call_last_timer_unit"   // "seconds" | "minutes"
        // Default Message app for the incoming-call screen's Message quick action.
        // Values: "calling_card" (default), "sms", "whatsapp", "telegram", "ask"
        const val KEY_DEFAULT_MESSAGE_APP = "default_message_app"
        const val KEY_APP_NAME_PRESET = "app_name_preset"

        const val KEY_CONTACTS_HIDER_CODE             = "contacts_hider_code"              // numeric secret code string
        const val KEY_CONTACTS_HIDER_IDS              = "contacts_hider_ids"               // comma-separated contact IDs
        const val KEY_CONTACTS_HIDER_HIDE_NAMES       = "contacts_hider_hide_names"        // bool
        const val KEY_CONTACTS_HIDER_HIDE_MENU        = "contacts_hider_hide_menu"         // bool
        const val KEY_CONTACTS_HIDER_HIDE_IN_CONTACTS = "contacts_hider_hide_in_contacts" // bool, default false
        const val KEY_CONTACTS_HIDER_HIDE_EVERYWHERE  = "contacts_hider_hide_everywhere"  // bool, default false
        const val KEY_CONTACTS_HIDER_BACKED_UP_DATA   = "contacts_hider_backed_up_data"   // json map of backed-up contacts

        // Search filter (Dialpad / Calls / Contacts / Favourites search bars) — the "Filter"
        // button beside the search bar. All four default to true (checked) so search behaves
        // as broadly as possible until the user deliberately narrows it down. Persisted here
        // (rather than in-memory) so the chosen filter survives the app being closed and
        // reopened.
        const val KEY_SEARCH_FILTER_CONTACTS        = "search_filter_contacts"
        const val KEY_SEARCH_FILTER_NON_CONTACTS    = "search_filter_non_contacts"
        const val KEY_SEARCH_FILTER_SMS             = "search_filter_sms"
        const val KEY_SEARCH_FILTER_RECORDINGS      = "search_filter_recordings"
        const val KEY_SEARCH_FILTER_GROUPS          = "search_filter_groups"
        const val KEY_SEARCH_FILTER_CONTACT_NOTES   = "search_filter_contact_notes"
        const val KEY_SEARCH_FILTER_RECORDING_NOTES = "search_filter_recording_notes"
        const val KEY_SEARCH_FILTER_SETTINGS        = "search_filter_settings"
        const val KEY_SEARCH_FILTER_ORDER           = "search_filter_order"

        const val KEY_SMS_ENABLED                   = "sms_enabled"
        const val KEY_SMS_CHAT_TEXT_SIZE            = "sms_chat_text_size"
        const val DEFAULT_SMS_CHAT_TEXT_SIZE        = 16f

        // Quik SMS Settings Keys
        const val KEY_SMS_UNREAD_AT_TOP             = "sms_unread_at_top"
        const val KEY_SMS_SEND_DELAY_SECONDS        = "sms_send_delay_seconds" // 0, 3, 5, 10
        const val KEY_SMS_DELIVERY_REPORTS          = "sms_delivery_reports"
        const val KEY_SMS_SIGNATURE                 = "sms_signature"
        const val KEY_SMS_SIGNATURE_ENABLED         = "sms_signature_enabled"
        const val KEY_SMS_STRIP_UNICODE             = "sms_strip_unicode"
        const val KEY_SMS_MOBILE_ONLY               = "sms_mobile_only"
        const val KEY_SMS_LONG_AS_MMS               = "sms_long_as_mms"
        const val KEY_SMS_MAX_MMS_SIZE              = "sms_max_mms_size" // "100KB", "200KB", "300KB", "600KB", "1MB", "2MB"
        const val KEY_SMS_DISABLE_SCREENSHOTS       = "sms_disable_screenshots"
        const val KEY_SMS_AUTO_COLOR_AVATARS        = "sms_auto_color_avatars"
        const val KEY_SMS_SHOW_AVATAR               = "sms_show_avatar"
        const val KEY_SMS_SHOW_STT                  = "sms_show_stt"
        const val KEY_SMS_SWIPE_RIGHT_ACTION        = "sms_swipe_right_action" // "call", "read", "delete", "none" (default: "none")
        const val KEY_SMS_SWIPE_LEFT_ACTION         = "sms_swipe_left_action" // "delete", "read", "none" (default: "none")
        const val KEY_SMS_SELECTED_FILTER          = "sms_selected_filter" // "all", "contacts", "unknown"
        const val KEY_SMS_FILTER_ORDER             = "sms_filter_order"
        const val KEY_SMS_LAUNCHER_ICON_ENABLED     = "sms_launcher_icon_enabled"
        const val KEY_SMS_LAUNCHER_APP_NAME         = "sms_launcher_app_name"
        const val KEY_SMS_SELECTED_APP_ICON         = "sms_selected_app_icon"
        const val KEY_PINNED_SMS_THREADS            = "pinned_sms_threads"
        const val KEY_PINNED_SMS_MESSAGES           = "pinned_sms_messages"
        const val KEY_STARRED_SMS_MESSAGES          = "starred_sms_messages"
        const val KEY_MUTED_SMS_ADDRESSES           = "muted_sms_addresses"
        const val KEY_SCHEDULED_SMS                 = "scheduled_sms_list"
        const val KEY_SMS_FLOATING_BUBBLE           = "sms_floating_bubble"

        const val KEY_APP_OPEN_COUNT                = "app_open_count"
        const val KEY_LAST_APP_VERSION              = "last_app_version"
        const val KEY_DONATE_POPUP_SHOWN_INSTALL    = "donate_popup_shown_install"

        const val KEY_FLOATING_CALL_POS_PORTRAIT_X  = "floating_call_pos_portrait_x"
        const val KEY_FLOATING_CALL_POS_PORTRAIT_Y  = "floating_call_pos_portrait_y"
        const val KEY_FLOATING_CALL_POS_LANDSCAPE_X = "floating_call_pos_landscape_x"
        const val KEY_FLOATING_CALL_POS_LANDSCAPE_Y = "floating_call_pos_landscape_y"

        const val KEY_HIDE_DUPLICATE_NUMBERS_IN_CONTACT = "hide_duplicate_numbers_in_contact"
        const val KEY_NAME_NON_CONTACTS_AS_UNKNOWN  = "name_non_contacts_as_unknown"

        // Custom Call Backgrounds (Incoming & Ongoing)
        const val KEY_INCOMING_BG_TYPE          = "incoming_bg_type"         // "none" | "wallpaper" | "picture" | "video"
        const val KEY_INCOMING_BG_PATH          = "incoming_bg_path"
        const val KEY_INCOMING_BG_ZOOM          = "incoming_bg_zoom"
        const val KEY_INCOMING_BG_PAN_X         = "incoming_bg_pan_x"
        const val KEY_INCOMING_BG_PAN_Y         = "incoming_bg_pan_y"
        const val KEY_INCOMING_BG_DIM           = "incoming_bg_dim"
        const val KEY_INCOMING_BG_BLUR          = "incoming_bg_blur"
        const val KEY_INCOMING_BG_VIDEO_SPEED   = "incoming_bg_video_speed"
        const val KEY_INCOMING_SHOW_CONTACT_PFP = "incoming_show_contact_pfp"
        const val KEY_INCOMING_SHOW_PHONE_NUMBER = "incoming_show_phone_number"
        const val KEY_INCOMING_FONT_COLOR_MODE  = "incoming_font_color_mode" // "default" | "custom"
        const val KEY_INCOMING_FONT_COLOR       = "incoming_font_color"      // Int ARGB
        const val KEY_INCOMING_FONT_SHADOW      = "incoming_font_shadow"     // Boolean, default false
        const val KEY_INCOMING_FONT_SIZE_SCALE  = "incoming_font_size_scale" // Float, default 1.0f (0.7f..1.5f)
        const val KEY_INCOMING_ELEMENTS_THEME   = "incoming_elements_theme"  // "auto" | "light" | "dark"
        const val KEY_INCOMING_AUTO_REFRESH_WALLPAPER = "incoming_auto_refresh_wallpaper"
        const val KEY_INCOMING_ANSWER_STYLE    = "incoming_answer_style"   // "google_modern" | "google_classic" | "full_screen_calling_card"
        const val ANSWER_STYLE_MODERN           = "google_modern"
        const val ANSWER_STYLE_CLASSIC          = "google_classic"
        const val ANSWER_STYLE_CALLING_CARD     = "full_screen_calling_card"

        const val KEY_ONGOING_BG_TYPE           = "ongoing_bg_type"          // "none" | "wallpaper" | "picture" | "video"
        const val KEY_ONGOING_BG_PATH           = "ongoing_bg_path"
        const val KEY_ONGOING_BG_ZOOM           = "ongoing_bg_zoom"
        const val KEY_ONGOING_BG_PAN_X          = "ongoing_bg_pan_x"
        const val KEY_ONGOING_BG_PAN_Y          = "ongoing_bg_pan_y"
        const val KEY_ONGOING_BG_DIM            = "ongoing_bg_dim"
        const val KEY_ONGOING_BG_BLUR           = "ongoing_bg_blur"
        const val KEY_ONGOING_BG_VIDEO_SPEED    = "ongoing_bg_video_speed"
        const val KEY_ONGOING_SHOW_CONTACT_PFP  = "ongoing_show_contact_pfp"
        const val KEY_ONGOING_SHOW_PHONE_NUMBER = "ongoing_show_phone_number"
        const val KEY_ONGOING_FONT_COLOR_MODE   = "ongoing_font_color_mode"  // "default" | "custom"
        const val KEY_ONGOING_FONT_COLOR        = "ongoing_font_color"       // Int ARGB
        const val KEY_ONGOING_FONT_SHADOW       = "ongoing_font_shadow"      // Boolean, default false
        const val KEY_ONGOING_FONT_SIZE_SCALE   = "ongoing_font_size_scale"  // Float, default 1.0f (0.7f..1.5f)
        const val KEY_ONGOING_AUTO_REFRESH_WALLPAPER  = "ongoing_auto_refresh_wallpaper"

        // Custom Contact PFP (Incoming & Ongoing)
        const val KEY_INCOMING_CUSTOM_PFP_TYPE              = "incoming_custom_pfp_type"         // "none" | "wallpaper" | "picture" | "video"
        const val KEY_INCOMING_CUSTOM_PFP_PATH              = "incoming_custom_pfp_path"
        const val KEY_INCOMING_CUSTOM_PFP_ZOOM              = "incoming_custom_pfp_zoom"
        const val KEY_INCOMING_CUSTOM_PFP_PAN_X             = "incoming_custom_pfp_pan_x"
        const val KEY_INCOMING_CUSTOM_PFP_PAN_Y             = "incoming_custom_pfp_pan_y"
        const val KEY_INCOMING_CUSTOM_PFP_DIM               = "incoming_custom_pfp_dim"
        const val KEY_INCOMING_CUSTOM_PFP_BLUR              = "incoming_custom_pfp_blur"
        const val KEY_INCOMING_CUSTOM_PFP_VIDEO_SPEED       = "incoming_custom_pfp_video_speed"
        const val KEY_INCOMING_CUSTOM_PFP_OVERRIDE_EXISTING = "incoming_custom_pfp_override_existing"
        const val KEY_INCOMING_CUSTOM_PFP_EXCEPT_PFP        = "incoming_custom_pfp_except_pfp"
        const val KEY_INCOMING_CUSTOM_PFP_SHOW_FOR_NO_PFP   = "incoming_custom_pfp_show_for_no_pfp"
        const val KEY_INCOMING_CUSTOM_PFP_SIZE              = "incoming_custom_pfp_size"         // Float 0.1f..1.0f, default 0.5f (50%)
        const val KEY_INCOMING_CUSTOM_PFP_SHAPE             = "incoming_custom_pfp_shape"        // "circle" | "square"

        const val KEY_ONGOING_CUSTOM_PFP_TYPE               = "ongoing_custom_pfp_type"          // "none" | "wallpaper" | "picture" | "video"
        const val KEY_ONGOING_CUSTOM_PFP_PATH               = "ongoing_custom_pfp_path"
        const val KEY_ONGOING_CUSTOM_PFP_ZOOM               = "ongoing_custom_pfp_zoom"
        const val KEY_ONGOING_CUSTOM_PFP_PAN_X              = "ongoing_custom_pfp_pan_x"
        const val KEY_ONGOING_CUSTOM_PFP_PAN_Y              = "ongoing_custom_pfp_pan_y"
        const val KEY_ONGOING_CUSTOM_PFP_DIM                = "ongoing_custom_pfp_dim"
        const val KEY_ONGOING_CUSTOM_PFP_BLUR               = "ongoing_custom_pfp_blur"
        const val KEY_ONGOING_CUSTOM_PFP_VIDEO_SPEED        = "ongoing_custom_pfp_video_speed"
        const val KEY_ONGOING_CUSTOM_PFP_OVERRIDE_EXISTING  = "ongoing_custom_pfp_override_existing"
        const val KEY_ONGOING_CUSTOM_PFP_EXCEPT_PFP         = "ongoing_custom_pfp_except_pfp"
        const val KEY_ONGOING_CUSTOM_PFP_SHOW_FOR_NO_PFP    = "ongoing_custom_pfp_show_for_no_pfp"
        const val KEY_ONGOING_CUSTOM_PFP_SIZE               = "ongoing_custom_pfp_size"          // Float 0.1f..1.0f, default 0.5f (50%)
        const val KEY_ONGOING_CUSTOM_PFP_SHAPE              = "ongoing_custom_pfp_shape"         // "circle" | "square"

        // Contact Info PFP Customization (Size & Shape)
        const val KEY_CONTACT_INFO_PFP_SIZE                 = "contact_info_pfp_size"            // Float 0.1f..1.0f, default 0.60f (60%)
        const val KEY_CONTACT_INFO_PFP_SHAPE                = "contact_info_pfp_shape"           // "circle" | "square" | expressive shape key, default "circle"
        const val KEY_CONTACT_INFO_PFP_SHAPE_ANIMATE        = "contact_info_pfp_shape_animate"   // Boolean, default true

        // Volume DND — toggle system DND via volume button sequence using Accessibility
        const val KEY_VOLUME_DND_ENABLED           = "volume_dnd_enabled"
        const val KEY_VOLUME_DND_SEQUENCE          = "volume_dnd_sequence"
        const val KEY_VOLUME_DND_LOCK_SCREEN_ONLY  = "volume_dnd_lock_screen_only"
        const val KEY_VOLUME_DND_TIMEOUT_MS        = "volume_dnd_timeout_ms"
        const val DEFAULT_VOLUME_DND_SEQUENCE      = "UUDD"
        const val DEFAULT_VOLUME_DND_TIMEOUT_MS    = 600

        // Favorites display mode (grid vs list)
        const val KEY_FAVORITES_IN_LIST            = "favorites_in_list"

        // Missed Call Notification — false = off, true = on (default on)
        const val KEY_MISSED_CALL_NOTIFICATION      = "missed_call_notification"
        const val KEY_MISSED_CALL_NOTIFICATION_PROVIDER = "missed_call_notification_provider"
        const val MISSED_CALL_PROVIDER_SYSTEM       = "system"
        const val MISSED_CALL_PROVIDER_EVER_DIALER  = "ever_dialer"

        // Missed Call Popup (display over other apps)
        const val KEY_MISSED_CALL_POPUP_ENABLED    = "missed_call_popup_enabled"
        const val KEY_ALWAYS_SHOW_MISSED_CALL_POPUP_AFTER_CALL_END = "always_show_missed_call_popup_after_call_end"
        const val KEY_MISSED_CALL_QUICK_REPLY_1    = "missed_call_quick_reply_1"
        const val KEY_MISSED_CALL_QUICK_REPLY_2    = "missed_call_quick_reply_2"
        const val KEY_MISSED_CALL_QUICK_REPLY_3    = "missed_call_quick_reply_3"
        const val KEY_MISSED_CALL_CUSTOM_FIRST     = "missed_call_custom_first"

        const val DEFAULT_MISSED_CALL_REPLY_1      = "Call me back?"
        const val DEFAULT_MISSED_CALL_REPLY_2      = "Sorry I'm busy"
        const val DEFAULT_MISSED_CALL_REPLY_3      = "I'll call you later"

        // Show SIM buttons instead of dial button in dialpad
        const val KEY_SHOW_SIM_BUTTONS_IN_DIALPAD  = "show_sim_buttons_in_dialpad"
        const val KEY_SIM1_COLOR                   = "sim1_color"
        const val KEY_SIM2_COLOR                   = "sim2_color"
        const val DEFAULT_SIM1_COLOR               = 0xFF2E7D32.toInt() // Green
        const val DEFAULT_SIM2_COLOR               = 0xFFC62828.toInt() // Red

        // Use SIM based on call logs history on any call
        const val KEY_USE_SIM_FROM_CALL_LOG       = "use_sim_from_call_log"

        // Confirm placing a call
        const val KEY_CONFIRM_PLACING_CALL         = "confirm_placing_call"

        // Speed Dial (Keys 2-9)
        const val KEY_SPEED_DIAL_PREFIX            = "speed_dial_"
        const val KEY_SPEED_DIAL_NAME_PREFIX       = "speed_dial_name_"

        // USSD & Secret Codes
        const val KEY_USSD_COUNTRY                 = "ussd_selected_country"
        const val KEY_USSD_CUSTOM_CODES            = "ussd_custom_codes_json"

        // PC Connect & Bluetooth PC Sync
        const val KEY_PC_SYNC_FAVOURITES           = "pc_sync_favourites"
        const val KEY_PC_SYNC_CALL_LOGS            = "pc_sync_call_logs"
        const val KEY_PC_SYNC_CONTACTS             = "pc_sync_contacts"
        const val KEY_PC_SYNC_SMS                  = "pc_sync_sms"
        const val KEY_PC_SYNC_NOTES                = "pc_sync_notes"
        const val KEY_PC_SYNC_CONTACT_PFP          = "pc_sync_contact_pfp"
        const val KEY_PC_SYNC_DYNAMIC_COLORS       = "pc_sync_dynamic_colors"
        const val KEY_PC_SYNC_BLUETOOTH_ENABLED    = "pc_sync_bluetooth_enabled"
        const val KEY_PC_SYNC_SHOW_NOTIFICATION   = "pc_sync_show_notification"

        // SMS Categories
        const val KEY_SMS_CATEGORY_ORDER           = "sms_category_order"
        const val KEY_SMS_CATEGORY_HIDDEN          = "sms_category_hidden"
        const val KEY_SMS_CUSTOM_CATEGORIES        = "sms_custom_categories"
        const val KEY_DEFAULT_SMS_CATEGORY         = "default_sms_category"
        val DEFAULT_SMS_CATEGORY_ORDER             = listOf("all", "favourites", "starred", "contacts", "unknown", "otp")

        // Call Categories
        const val KEY_CALL_CATEGORY_ORDER          = "call_category_order"
        const val KEY_CALL_CATEGORY_HIDDEN         = "call_category_hidden"
        const val KEY_CALL_CUSTOM_CATEGORIES       = "call_custom_categories"
        const val KEY_DEFAULT_CALL_CATEGORY        = "default_call_category"
        val DEFAULT_CALL_CATEGORY_ORDER            = listOf("all", "favourites", "contacts", "unknown", "missed", "incoming", "outgoing", "whatsapp", "alternate")

        // WhatsApp Calls
        const val KEY_SHOW_WHATSAPP_CALLS          = "show_whatsapp_calls"
    }
}

data class SmsCustomCategory(
    val id: String,
    val name: String,
    val contactPhones: List<String> = emptyList()
)

data class SmsCategoryItem(
    val id: String,
    val name: String,
    val isCustom: Boolean,
    val contactPhones: List<String> = emptyList()
)

data class CallCustomCategory(
    val id: String,
    val name: String,
    val contactPhones: List<String> = emptyList()
)

data class CallCategoryItem(
    val id: String,
    val name: String,
    val isCustom: Boolean,
    val contactPhones: List<String> = emptyList()
)

data class LiquidGlassElementConfig(
    val blurRadiusDp: Float,
    val refractionHeightDp: Float,
    val refractionAmountDp: Float,
    val chromaticAberration: Boolean,
    val depthEffect: Boolean,
    val saturation: Float,
    val brightness: Float
)

data class BlurElementConfig(
    val blurRadiusDp: Float,
    val saturation: Float
)
